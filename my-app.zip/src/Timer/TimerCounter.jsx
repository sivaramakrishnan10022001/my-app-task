import React from "react";
import "./TimerCounter.css";

class TimerCounter extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            hours: 0,
            minutes: 0,
            seconds: 0,
            end_hours: this.props.end_hours,
            end_minutes: this.props.end_minutes,
            end_seconds: this.props.end_seconds,
        }
    }
    componentDidMount() {
        let deleted;
        deleted = setInterval(() => {
            if (this.state.end_hours === this.state.hours && this.state.end_minutes === this.state.minutes && this.state.seconds === this.state.end_seconds) {
                this.setState({ seconds: 0, minutes: 0, hours: 0, })
                clearInterval(deleted)
            } else {
                this.setState({ seconds: this.state.seconds + 1 })
            }
            if (this.state.seconds === 60) {
                this.setState({
                    seconds: 0,
                    minutes: this.state.minutes + 1
                })
            }
            else if (this.state.minutes === 60) {
                this.setState({
                    minutes: 0,
                    hours: this.state.hours + 1
                })
            }
        }, 1000)
    }
    render() {
        return (
            <div className="timer_wapper">
                <div className="timer_container">
                    <span className="timer_box">{this.state.hours}</span>:
                    <span className="timer_box">{this.state.minutes}</span>:
                    <span className="timer_box">{this.state.seconds}</span>
                </div>
            </div>
        )
    }
}

export default TimerCounter;