import React from "react";
import "./selectorBox.css";

class SelectorBox extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      colors: [
        "red",
        "silver",
        "gray",
        "black",
        "purple",
        "yellow",
        "lightpink",
        "green",
      ],
      colorsName: [],
      values: "",
      searchValue: '',
      isOpen: false,
      isClearable: true,
      isSearchable: true,
      isDisabled: false,
      isLoading: false,
      isRtl: false,
    };
    this.myRef = React.createRef();
  }

  componentDidMount() {
    this.setState({
      colorsName: this.state.colors,
      values: this.state.colors[0],
    });
  }

  handleClick = (color) => {
    this.myRef.current.value="";
    this.setState({
      searchValue: "",
      values: color,
      colorsName:this.state.colors
    });
  };

  toggleClearable = () => {
    this.setState({ isClearable: !this.state.isClearable });
  };

  toggleSearchable = () => {
    this.setState({ isSearchable: !this.state.isSearchable });
  };

  toggleDisabled = () => {
    this.setState({
      isDisabled: !this.state.isDisabled,
    });
  };

  toggleLoading = () => {
    this.setState({
      isLoading: !this.state.isLoading,
    });
  };

  toggleRtl = () => {
    this.setState({ isRtl: !this.state.isRtl });
  };

  handleChange = (e) => {
    let Input = e.target.value;
    let filteredData = Object.assign([], this.state.colors);
    console.log(filteredData.length, "(1)(2)(1)")
    filteredData = filteredData.filter((item) => {
      if (Input === "") {
        console.log(item, "item(*******")
        return item
      } else {
        return item.toLowerCase().includes(Input.toLowerCase());
      }
    })
    this.setState({
      searchValue: Input,
      colorsName: filteredData,
    })

  };

  render() {
    console.log(this.state.colorsName, "(colorsName__)")
    return (
      <div className="selectorBox_wapper">
        <div className="selectorBox_container">
          <div
            className={`selectorBox_input ${this.state.isDisabled ? "disable_box" : "selectorBox_input"
              } ${this.state.isRtl ? "isRtl" : ""}`}
            onClick={() => {
              this.setState({ isOpen: !this.state.isOpen });
            }}
          >
            <div
              className="inputbox"
              onClick={() => {
                this.setState({ isOpen: !this.state.isOpen });
              }}
            >
              <span className={`${this.state.isSearchable ? "disable" : ""}`}>
                {this.state.values}
              </span>

              <input
                className={` ${this.state.isDisabled
                  ? "disable_box"
                  : this.state.isSearchable
                    ? ""
                    : "disable"
                  } ${this.state.isRtl ? "isRtl" : ""}`}
                type="text"
                ref={this.myRef}
                onChange={(e) => this.handleChange(e)}
                placeholder={this.state.values}
              />
            </div>
            <div className={`icon ${this.state.isRtl ? "isRtl" : ""}`}>
              {this.state.isLoading ? (
                // <div class="circles">
                //   <span class="circle"> </span>
                //   <span class="circle"> </span>
                //   <span class="circle"> </span>
                //   <span class="circle"> </span>
                // </div>
                <div className="circles">
                <div class="dot-loader"></div>
                <div class="dot-loader dot-loader--2"></div>
                <div class="dot-loader dot-loader--3"></div>
               </div>
                
              ) : null}
              {this.state.values !== "" && this.state.isClearable ? (
                <svg
                  className="svg"
                  viewBox="0 0 20 20"
                  onClick={() => {
                    this.setState({ values: "" });
                  }}
                >
                  <path d="M14.348 14.849c-0.469 0.469-1.229 0.469-1.697 0l-2.651-3.030-2.651 3.029c-0.469 0.469-1.229 0.469-1.697 0-0.469-0.469-0.469-1.229 0-1.697l2.758-3.15-2.759-3.152c-0.469-0.469-0.469-1.228 0-1.697s1.228-0.469 1.697 0l2.652 3.031 2.651-3.031c0.469-0.469 1.228-0.469 1.697 0s0.469 1.229 0 1.697l-2.758 3.152 2.758 3.15c0.469 0.469 0.469 1.229 0 1.698z"></path>
                </svg>
              ) : null}
              <svg
                className="svg"
                onClick={() => {
                  this.setState({ isOpen: !this.state.isOpen });
                }}
                viewBox="0 0 20 20"
              >
                <path d="M4.516 7.548c0.436-0.446 1.043-0.481 1.576 0l3.908 3.747 3.908-3.747c0.533-0.481 1.141-0.446 1.574 0 0.436 0.445 0.408 1.197 0 1.615-0.406 0.418-4.695 4.502-4.695 4.502-0.217 0.223-0.502 0.335-0.787 0.335s-0.57-0.112-0.789-0.335c0 0-4.287-4.084-4.695-4.502s-0.436-1.17 0-1.615z"></path>
              </svg>
            </div>
          </div>
          <div className="Checkbox">
            <span>
              <input
                type="checkbox"
                onClick={() => this.toggleClearable()}
                checked={this.state.isClearable}
              />
              Clearable
            </span>
            <span>
              <input
                type="checkbox"
                onClick={() => this.toggleSearchable()}
                checked={this.state.isSearchable}
              />
              Searchable
            </span>
            <span>
              <input
                type="checkbox"
                onClick={() => this.toggleDisabled()}
                checked={this.state.isDisabled}
              />
              Disabled
            </span>
            <span>
              <input
                type="checkbox"
                onClick={() => this.toggleLoading()}
                checked={this.state.isLoading}
              />
              Loading
            </span>
            <span>
              <input
                type="checkbox"
                onClick={() => this.toggleRtl()}
                checked={this.state.isRtl}
              />
              RTL
            </span>
          </div>
          <div
            className={`${this.state.isOpen ? "isOpen" : "isOff"} ${this.state.isRtl ? " isRtl" : ""
              }`}
          >
            {this.state.colorsName.map((color, index) => {
              return (
                <div
                  className={`selectorBox_content ${color === "silver" ? "disable" : ""
                    } ${this.state.isRtl ? "isRtl" : ""}
                  ${color === this.state.values ? "blue" : ""}`}
                  key={index}
                  onClick={() => this.handleClick(color)}
                >
                  <span >
                    {color}
                  </span>
                  
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }
}

export default SelectorBox;
