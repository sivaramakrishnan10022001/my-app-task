import React from "react";
import "./AnimationSelector.css";

class AnimationSelector extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            colors: [
                "red",
                "silver",
                "gray",
                "black",
                "purple",
                "yellow",
                "lightpink",
                "green",
            ],
            storing_color: [],
            colorNames: [],
            popup: false,
            inputValue: '',
        };
        this.myInputRef = React.createRef()
    }

    componentDidMount() {
        this.myInputRef.current.focus();
        let data = Object.assign([], this.state.colors);

        this.setState({
            colorNames: data
        })
    }

    handleClick = () => {
        console.log("is working");
        this.myInputRef.current.focus();
        this.setState({
            popup: !this.state.popup,
        });
    };

    colorClick = (color, index) => {

        let data = this.state.colorNames[index];
        this.state.storing_color.push(data);
        let REMOVE = this.state.colorNames;
        REMOVE.splice(index, 1);

        let deleted_data = this.state.colors;
        deleted_data.splice(index, 1);

        this.setState({
            colors: deleted_data,
        })



        console.log(REMOVE, "REMOVE");
    };

    inputItemDEL = (sColor, sIndex) => {
        let data = this.state.storing_color[sIndex];
        this.state.colorNames.push(data);
        let REMOVE = this.state.storing_color;
        REMOVE.splice(sIndex, 1);

        // let newdata = this.state.storing_color[sIndex];
        this.state.colors.push(sColor);

        this.setState({
            inputItem: !this.state.inputItem,
            inputItem_Index: sIndex,
        })
    };

    FILTER = (e) => {
        let inputValue = e.target.value;
        console.log(inputValue, "inputValue");
        let data = Object.assign([], this.state.colors);
        let newData = Object.assign([], this.state.storing_color);
        data = data.filter((item) => {
            if (inputValue === "") {
                return data
            } else if (inputValue !== "") {
                return item.toLowerCase().startsWith(inputValue.toLowerCase());
            }
        });
        this.setState({
            colorNames: data,
            popup: true
        });
    };

    render() {

        return (
            <div className="AnimationSelector">

                <div className="AnimationSelector_container">
                    <div className="inputBox" onClick={() => this.handleClick()}>
                        <div className="contents">
                            {this.state.storing_color.map((sColor, sIndex) => {
                                return (

                                    <span className={`inputContents`} key={sIndex}>
                                        <span> {sColor}</span>
                                        <span>
                                            <svg
                                                onClick={() => this.inputItemDEL(sColor, sIndex)}
                                                viewBox="0 0 20 20"
                                            >
                                                <path d="M14.348 14.849c-0.469 0.469-1.229 0.469-1.697 0l-2.651-3.030-2.651 3.029c-0.469 0.469-1.229 0.469-1.697 0-0.469-0.469-0.469-1.229 0-1.697l2.758-3.15-2.759-3.152c-0.469-0.469-0.469-1.228 0-1.697s1.228-0.469 1.697 0l2.652 3.031 2.651-3.031c0.469-0.469 1.228-0.469 1.697 0s0.469 1.229 0 1.697l-2.758 3.152 2.758 3.15c0.469 0.469 0.469 1.229 0 1.698z"></path>
                                            </svg>
                                        </span>
                                    </span>
                                );
                            })}
                            <input type="text" ref={this.myInputRef} onChange={(e) => this.FILTER(e)} placeholder={this.state.storing_color === "" ? "" : ""} />

                            {this.state.popup ? (
                                <div className="popup">
                                    {this.state.colorNames.map((color, index) => {
                                        return (
                                            <span
                                                className={`${color === "gray" ? "gray" : ""}`}
                                                onClick={() => this.colorClick(color, index)}
                                                key={index}
                                            >
                                                {color}
                                            </span>
                                        );
                                    })}
                                </div>
                            ) : null}
                        </div>
                        <div className="icon">
                            <svg viewBox="0 0 20 20">
                                <path d="M4.516 7.548c0.436-0.446 1.043-0.481 1.576 0l3.908 3.747 3.908-3.747c0.533-0.481 1.141-0.446 1.574 0 0.436 0.445 0.408 1.197 0 1.615-0.406 0.418-4.695 4.502-4.695 4.502-0.217 0.223-0.502 0.335-0.787 0.335s-0.57-0.112-0.789-0.335c0 0-4.287-4.084-4.695-4.502s-0.436-1.17 0-1.615z"></path>
                            </svg>
                        </div>

                    </div>
                </div>
            </div>
        );
    }
}

export default AnimationSelector;
