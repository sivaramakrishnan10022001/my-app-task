import React from "react";
import "./App.css";
import AccordianFirstTask from "./Accordians/AccordianFirstTask/AccordianFirstTask";
import Accordians from "./Accordians/AccordianSecondsTask/Accordians";
import Stepper from "./StepperCom/Stepper";
import LoadingButton from "./LoadingButton/LoadingButton";
import LoadingAnimationButton from "./LoadingButton/LoadingAnimationButton";
import Table from "./TableCom/BasicTable/Table";
import DataTable from "./TableCom/DataTable/DataTable";
import DenseTable from "./TableCom/DenseTable/DenseTable";
import SortingAndSelecting from "./TableCom/SortingAndSelecting/SortingAndSelecting";
import Customization from "./TableCom/Customization/Customization";
// import Dnd from "./NewFile";
// import DragDrop from "./DragDrop";
// import Test from "./TEST/Test";
// import Testing from "./testings";
import DynamicTableApp from "./TableCom/dynamicTable/dynamicTableApp";
import Animation from "./TableCom/Animation/Animation";
import TestingList from "./TableCom/testinglist/testinglist";
import JavascriptDnd from "./javascriptDnd";
// import Mathematics from "./TEST/mathematics";
import SelectorBox from "./selectorBoxs/selectorBox";
// import FlavorForm from "./testings";
// import AnimationSelector from "./selectorBoxs/AnimationSelectorBox/AnimationSelector";
// import Draggable from "./TEST/TESTINGDDN";
// import DdnApp from "./TEST/DdnApp";
// import Timer from "./CountdownTimer/Timer";
// import CountTimer from "./CountdownTimer/CountTimer";
// import TimerCounter from "./Timer/TimerCounter";
// import TimerCount from "./Timer/TimerCount";
// import TimerTwo from "./CountdownTimer/TimerTwo";
import CountdownTimer from "./newTimer/countdowntimer";
import DragandDrop from "./TEST/DragandDrop";
import { MRangeSlider } from "./slider/MaterialSliders";
// import  Slider from "./slider/Slider";
// import NewSlider from "./slider/NewSlider";

// import MouseEvents from "./TEST/MouseEvents";

import DoubleSlider from "./slider/doubleslider";
// import Funcdoubleslider from "./slider/funcdoubleslider";
import DoubleRangeSlider from "./TEST/TESTINGDDN";
// linechart
import Linechart from "./chartjs/LineChart/linechart";
import AreaChart from "./chartjs/AreaChart/areachart";
import LineChartBoundaries from "./chartjs/AreaChart/linechartboundaries";
import LineChartDatasets from "./chartjs/AreaChart/linechartdatasets";
import InterpolationModes from "./chartjs/AreaChart/interpolationmodes";
import ScriptableOptionsLineChart from "./chartjs/LineChart/ScriptableOptionsLineChart";
import LineChartAnimation from "./chartjs/LineChart/linechartanimation";
// barchart
import BarChart from "./chartjs/barchart/barchart";
import CreatingBarCharts from "./chartjs/barchart/creatingbarcharts";
import Barparsing from "./chartjs/barchart/barparsing";
import DensityChart from "./chartjs/barchart/densitychart";
import BarChartBorderRadius from "./chartjs/barchart/BarChartBorderRadius";
import BarBorderRadius from "./chartjs/barchart/barborderRadius";
import StackedBar from "./chartjs/barchart/StackedBar";
import RadarChart from "./chartjs/RadarChart/radarchart";
import PolarAreaChart from "./chartjs/PolarAreaChart/polarAreachart";
import DoughnutChart from "./chartjs/DoughnutChart/doughnutchart";
import Doughnut from "./chartjs/DoughnutChart/doughnut";
import FloatingBars from "./chartjs/barchart/FloatingBars";
import BarChartHover from "./chartjs/barchart/barcharthover";
// PieChart
import PieChart from "./chartjs/PieChart/piechart";
import PieChartMulti from "./chartjs/PieChart/piechartmulti";

// import HorizontalBarChart from "./chartjs/HorizontalBarChart/horizontalbarchart";
// import HorizontalBar from "./chartjs/HorizontalBarChart/horizontalbar";
// animation
import Delay from "./chartjs/Animations/Delay";
import Drop from "./chartjs/Animations/Drop";
import Loop from "./chartjs/Animations/Loop";
import ProgressiveLine from "./chartjs/Animations/ProgressiveLine";

// Scatter
import Scatter from "./chartjs/scatter/scatter";
// tooltip
import CustomTooltipContent from "./chartjs/Tooltip/CustomTooltipContent";

// 

import LineSegmentStyling from "./chartjs/LineChart/linesegmentstyling";
// import LineChartColor from "./chartjs/LineChart/linechartcolor";
import LineChartApp from "./chartjs/LineChart/LineChartApp";
// import Implementation from "./chartjs/implementation/implementation";
import ImplementationApp from "./chartjs/implementation/implementationApp";
import LineChartUpdate from "./chartjs/LineChart/linechartupdate";
import AnimationLineChart from "./chartjs/implementation/animationlinechart";
import LineIndexAxis from "./chartjs/implementation/lineindexaxis";
import UpdateChartType from "./chartjs/implementation/UpdateChartType";
import Navigation from "./Navigation/navigation";
import ResponsiveNavigation from "./Navigation/ResponsiveNavigation/responsivenavigation";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {

    }
  }
  render() {
    let data = [
      {
        title: "Home",
        active: true,
        viewbox: "0 0 576 512",
        svgpath: "M280.37 148.26L96 300.11V464a16 16 0 0 0 16 16l112.06-.29a16 16 0 0 0 15.92-16V368a16 16 0 0 1 16-16h64a16 16 0 0 1 16 16v95.64a16 16 0 0 0 16 16.05L464 480a16 16 0 0 0 16-16V300L295.67 148.26a12.19 12.19 0 0 0-15.3 0zM571.6 251.47L488 182.56V44.05a12 12 0 0 0-12-12h-56a12 12 0 0 0-12 12v72.61L318.47 43a48 48 0 0 0-61 0L4.34 251.47a12 12 0 0 0-1.6 16.9l25.5 31A12 12 0 0 0 45.15 301l235.22-193.74a12.19 12.19 0 0 1 15.3 0L530.9 301a12 12 0 0 0 16.9-1.6l25.5-31a12 12 0 0 0-1.7-16.93z",
      },
      {
        title: "profile",
        active: false,
        viewbox: "0 0 448 512",
        svgpath: "M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z",
      },
      {
        title: "message",
        viewbox: "0 0 512 512",
        svgpath: "M256 32C114.6 32 0 125.1 0 240c0 47.6 19.9 91.2 52.9 126.3C38 405.7 7 439.1 6.5 439.5c-6.6 7-8.4 17.2-4.6 26S14.4 480 24 480c61.5 0 110-25.7 139.1-46.3C192 442.8 223.2 448 256 448c141.4 0 256-93.1 256-208S397.4 32 256 32zm0 368c-26.7 0-53.1-4.1-78.4-12.1l-22.7-7.2-19.5 13.8c-14.3 10.1-33.9 21.4-57.5 29 7.3-12.1 14.4-25.7 19.9-40.2l10.6-28.1-20.6-21.8C69.7 314.1 48 282.2 48 240c0-88.2 93.3-160 208-160s208 71.8 208 160-93.3 160-208 160z",
      },
      {
        title: "photos",
        active: false,
        viewbox: "0 0 512 512",
        svgpath: "M512 144v288c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V144c0-26.5 21.5-48 48-48h88l12.3-32.9c7-18.7 24.9-31.1 44.9-31.1h125.5c20 0 37.9 12.4 44.9 31.1L376 96h88c26.5 0 48 21.5 48 48zM376 288c0-66.2-53.8-120-120-120s-120 53.8-120 120 53.8 120 120 120 120-53.8 120-120zm-32 0c0 48.5-39.5 88-88 88s-88-39.5-88-88 39.5-88 88-88 88 39.5 88 88z",
      },
      {
        title: "settings",
        active: false,
        viewbox: "0 0 512 512",
        svgpath: "M487.4 315.7l-42.6-24.6c4.3-23.2 4.3-47 0-70.2l42.6-24.6c4.9-2.8 7.1-8.6 5.5-14-11.1-35.6-30-67.8-54.7-94.6-3.8-4.1-10-5.1-14.8-2.3L380.8 110c-17.9-15.4-38.5-27.3-60.8-35.1V25.8c0-5.6-3.9-10.5-9.4-11.7-36.7-8.2-74.3-7.8-109.2 0-5.5 1.2-9.4 6.1-9.4 11.7V75c-22.2 7.9-42.8 19.8-60.8 35.1L88.7 85.5c-4.9-2.8-11-1.9-14.8 2.3-24.7 26.7-43.6 58.9-54.7 94.6-1.7 5.4.6 11.2 5.5 14L67.3 221c-4.3 23.2-4.3 47 0 70.2l-42.6 24.6c-4.9 2.8-7.1 8.6-5.5 14 11.1 35.6 30 67.8 54.7 94.6 3.8 4.1 10 5.1 14.8 2.3l42.6-24.6c17.9 15.4 38.5 27.3 60.8 35.1v49.2c0 5.6 3.9 10.5 9.4 11.7 36.7 8.2 74.3 7.8 109.2 0 5.5-1.2 9.4-6.1 9.4-11.7v-49.2c22.2-7.9 42.8-19.8 60.8-35.1l42.6 24.6c4.9 2.8 11 1.9 14.8-2.3 24.7-26.7 43.6-58.9 54.7-94.6 1.5-5.5-.7-11.3-5.6-14.1zM256 336c-44.1 0-80-35.9-80-80s35.9-80 80-80 80 35.9 80 80-35.9 80-80 80z",
      },
    ]
    return (
      <div className="App">
        <AccordianFirstTask />
        <Accordians />
        <Stepper />
        <LoadingButton />
        <LoadingAnimationButton />
        <Table />
        <DataTable />
        <DenseTable />
        <SortingAndSelecting />
        <Customization />

        {/* - s -- */}
        {/* <Dnd /> */}
        {/* <DragDrop /> */}
        {/* <Testing /> */}
        {/* --stop - */}

        {/* <Test /> */}
        <DynamicTableApp />


        <Animation />
        <TestingList />
        <SelectorBox />


        {/* <AnimationSelector /> */}

        <CountdownTimer className="sample" interval="1:3:0:10" />
        <DragandDrop className="sample" />
        <MRangeSlider requireStepMarks={true} stepSize={10} min={0} max={200} leftRange={30} rightRange={60} showValue={false} />

        {/* -s- */}
        {/* <MRangeSlider requireStepMarks={true} stepSize={10} min={0} max={200} leftRange={30} rightRange={60} showValue={false} /> */}
        {/* <Slider  requireStepMarks={true} stepSize={10}  min={0} max={200} leftRange={30} rightRange={60} /> */}
        {/* stop */}
        {/* <NewSlider min={0} max={200} leftRange={30} rightRange={60} /> */}
        {/* <DdnApp /> */}
        <JavascriptDnd className="sample" />
        {/* <MouseEvents /> */}
        <DoubleSlider className="sample" requireStepMarks={true} stepSize={10} min={0} max={100} value="20-50" />
        {/* <Funcdoubleslider /> */}
        <DoubleRangeSlider requireStepMarks={true} stepSize={10} />
        <Linechart />
        <ScriptableOptionsLineChart />
        <LineChartAnimation />
        <AreaChart />   
        <LineChartBoundaries />
        <LineChartDatasets />
        <InterpolationModes />
        {/* barchart */}
        <BarChart />
        <CreatingBarCharts />
        <Barparsing />
        <DensityChart />
        <BarChartBorderRadius />
        <BarBorderRadius />
        <StackedBar />
        <FloatingBars />
        <BarChartHover />
        {/* pie chart */}
        <PieChart />
        <PieChartMulti />
        <RadarChart />
        <PolarAreaChart />
        {/* <DoughnutChart /> */}
        <Doughnut />
        {/* <HorizontalBarChart /> */}
        {/* <HorizontalBar /> */}
        {/* animation */}
        <Delay />
        <Drop />
        <Loop />
        <ProgressiveLine />
        {/* Scatter */}
        <Scatter />
        {/* tooltip */}
        <CustomTooltipContent />

        {/*  */}

        <LineSegmentStyling />
        {/* <LineChartColor /> */}
        <LineChartApp />
        {/* <Implementation /> */}
        <ImplementationApp />
        <LineChartUpdate />
        <AnimationLineChart />
        <LineIndexAxis />
        <UpdateChartType />
        <Navigation className="sample" data={data} />
        {/* <ResponsiveNavigation /> */}
      </div>
    );
  }
}
export default App;
