import React from 'react';
import "./Stepper.css"


class Stepper extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            StepperData: [
                {
                    number: 1,
                    title: "level 1",
                    line: <span></span>
                },
                {
                    number: 2,
                    title: "level 2",
                    line: <span></span>
                },
                {
                    number: 3,
                    // line: <span></span>,
                    title: "level 3"
                },
                // {
                //     number: 4,
                //     line: <span></span>,
                //     title: "level 4"
                // },
                // {
                //     number: 5,
                //     line: <span></span>,
                //     title: "level 5"
                // },
                // {
                //     number: 6,
                //     line: <span></span>,
                //     title: "level 6"
                // },
               
            ],
            countStep: 0,

        };
    }


    // =======================================================

    nextbuttonClick = () => {
        if (this.state.countStep != this.state.StepperData.length) {
            this.setState({
                countStep: this.state.countStep + 1
            })
        }
    }

    // ========================================================

    backbuttonClick = () => {
        if (this.state.countStep != 0) {
            this.setState({
                countStep: this.state.countStep - 1
            })
        }
    }

    // ======================================================

    finishbuttonClick = () => {
       
        this.setState({
            countStep: 0
        })
    }

    // ====================================================

    render() {
        return (
            <div className="StepperContainer">
                <div className="Stepper">
                    {
                        this.state.StepperData.map((item, index) => {
                            return (
                                <div className="StepperData" key={index} >
                                    <div className="number" >
                                        <h3>
                                            {
                                                this.state.countStep >= item.number ? <i class="fas fa-check"> </i> : item.number
                                            }
                                        </h3>
                                    </div>
                                    <div className="title" > <h3> {item.title} </h3> </div>
                                    <div className='line' >{item.line} </div>
                                </div>


                            );
                        })
                    }
                </div>
                <div className='stepFooter' >
                    <div className='step' >
                        <h3> step {this.state.countStep} </h3>
                       {this.state.StepperData.length === this.state.countStep ? 
                         <h3 className='success'>All steps completed - you're finished</h3>:null} 
                    </div>
                    <div className='stepButton'>
                        {
                            this.state.countStep > 0 ? <button onClick={() => this.backbuttonClick()}>
                                Back </button> : <button className='disableButton' onClick={() => this.backbuttonClick()}> Back </button>
                        }
                        <div className='buttonRight'>
                            {this.state.StepperData.length === this.state.countStep ? <button className='nextButton'
                                onClick={() => this.finishbuttonClick()}> finish
                            </button> : <button className='nextButton'
                                onClick={() => this.nextbuttonClick()}> Next
                            </button>}
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default Stepper;