
import React from "react";
import "./ScriptableOptionsLineChart.css";
import Chart from "../../chartcdn/Chart";

class ScriptableOptionsLineChart extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }
    componentDidMount() {
        let ctx = document.getElementById('scriptable-options-linechart').getContext('2d');

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ["junuary", "february", "march", "apirl", "may", "june", "july", "august", "september", "october", "november", "december"],
                datasets: [
                    {
                        data: [75, 45, 8, 50, 16, 72, 45, 87, 75, 96, 89, 55],
                        pointRotation: 3,
                        pointBorderWidth: 8,
                        borderColor: "#4DC9F6",
                        borderWidth: 3,
                        pointStyle: ["circle", "rect"]
                    }
                ]
            },
            options: {
                plugins: {
                    legend: 'false',
                    tooltip: 'true',
                },
                elements: {
                    line: {
                        fill: 'false',
                        backgroundColor: "#ff00bf",
                        borderColor: "#ff00bf"
                    },
                    point: {
                        backgroundColor: "#ff00bf",
                        hoverBackgroundColor: "00ffff",
                        radius: 10,
                        pointStyle: ["circle", "rect"],
                        hoverRadius: 15,
                    }
                }
            }
        })
    }
    render() {
        return (
            <div className="scriptable-options-linechart">
                <canvas id="scriptable-options-linechart" height="400" width="800"></canvas>
            </div>
        )
    }
}

export default ScriptableOptionsLineChart;