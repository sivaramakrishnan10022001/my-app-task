import React from "react";
import "./linechartcolor.css";
import Chart from "../../chartcdn/Chart";

class LineChartColor extends React.Component {
    constructor() {
        super();
        // this.ctx = document.getElementById('linechartcolor').getContext('2d');


        this.state = {

        }
    }

    componentDidMount() {
        this.setState({
            data: this.props.data,
        }, () => {
            let ctx = document.getElementById('linechartcolor').getContext('2d');
            let chart = new Chart(ctx, {
                type: "line",
                data: this.state.data,
                options: {
                    hover: {
                        mode: 'dataset'
                    },
                }
            })
            
        })
    }

    updateClick = (chart) => {
        this.setState({
            data: this.props.newdata
        })

       
    }


    render() {
        return (

            <div className="linechartcolor-container">
                <canvas id="linechartcolor" height="400" width="800"></canvas>
                <button onClick={() => this.updateClick()} >update</button>
            </div>

        )
    }
}

export default LineChartColor;