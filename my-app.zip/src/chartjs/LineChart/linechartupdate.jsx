import React from "react";
import "./linechartupdate.css";
import Chart from "../../chartcdn/Chart";

class LineChartUpdate extends React.Component {
    constructor(props) {
        super(props);
        this.state = {

        }
        // this.chartRef = React.createRef();
    }


    componentDidMount() {
        // const ctx = this.chartRef.current.getContext("2d");
        let ctx = document.getElementById('linechartupdate').getContext('2d');
        this.mychart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ["Africa", "Asia", "Europe", "Latin America", "North America"],
                datasets: [
                    {
                        label: "update",
                        backgroundColor: 'rgba(255, 99, 132, 1)',
                        borderColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 206, 86, 1)',
                            'rgba(75, 192, 192, 1)',
                            'rgba(153, 102, 255, 1)',
                        ],
                        data: [5, 17, 9, 12, 2],
                        lineTension: 0.2,
                    }
                ]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        })
    }

    lineUpdate = () => {
        this.mychart.data.datasets[0].data = [1, 1, 1, 2, 3];
        this.mychart.update();
    }

    render() {
        return (
            <div className="linechartupdate-wapper">
                <div className="linechartupdate-container">
                    <canvas id="linechartupdate" height="400" width="800"></canvas>
                    <button style={{ padding: '10px 20px', margin: "1rem" }} onClick={() => this.lineUpdate()}>update</button>
                </div>
            </div>
        )
    }
}

export default LineChartUpdate;