import React from "react";
import "./linechart.css";
import { Chart } from "../../chartcdn/Chart";
class Linechart extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }
    componentDidMount() {
        const ctx = document.getElementById('myChart').getContext('2d');
        var xValues = [50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150];
        var yValues = [7, 8, 8, 9, 9, 9, 10, 11, 14, 14, 15];
        new Chart(ctx, {
            type: "line",
            data: {
                labels: xValues,
                datasets: [{
                    fill: false,
                    backgroundColor: "#3c85d3",
                    borderJoinStyle: "miter",
                    borderCapStyle: "bevel",
                    pointStyle: "cricle",
                    borderWidth: 5,
                    pointHitRadius: 1,
                    pointBorderWidth: 5,
                    lineTension: 0.2,
                    // pointBorderWidth: 8,
                    // pointRadius: 3,
                    borderColor: "#81c9eb",
                    pointRadius: 5,
                    order: 0,
                    data: yValues,
                }]
            },
            options: {
                // animations: {
                //     tension: {
                //       duration: 2000,
                //       easing: 'linear',
                //       from: 1,
                //       to: 0,
                //       loop: true
                //     }
                //   },

                legend: { display: true },
                scales: {
                    yAxes: [{ ticks: { min: 6, max: 16 } }],
                }
            }
        });
    }

    render() {
        return (
            <div className="linechart-wapper">
                <canvas id="myChart" width="600" height="300"></canvas>
            </div>
        )
    }

}

export default Linechart;