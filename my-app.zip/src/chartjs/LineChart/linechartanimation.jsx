
import React from "react";
import "./linechartanimation.css"
import Chart from "../../chartcdn/Chart";

class LineChartAnimation extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }
    componentDidMount() {
        let ctx = document.getElementById("linechartanimation").getContext("2d");
        new Chart(ctx, {
            type: "line",
            data: {
                labels: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
                datasets: [
                    {
                        backgroundColor: "#ff638480",
                        borderColor: "#ff6384",
                        borderWidth: 1,
                        fill: true,
                        data: [10, 7, 9, 5, 8, 3, 4, 2, 1, 1]
                    }
                ]
            },
            options: {
                animation: {
                    x: {
                        duration: 5000,
                        from: 0,
                    },
                    y: {
                        duration: 3000,
                        from: 500
                    }
                }
            }
        })
    }
    render() {
        return (
            <div className="linechartanimation-wapper">
                <div className="linechartanimation-container">
                    <canvas id="linechartanimation" height="400" width="800"></canvas>
                </div>
            </div>
        )
    }
}

export default LineChartAnimation;