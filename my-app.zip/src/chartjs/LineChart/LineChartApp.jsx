import React from "react";
import "./linechartcolor.css";
import Chart from "../../chartcdn/Chart";
import LineChartColor from "./linechartcolor";

class LineChartApp extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }
    componentDidMount() {

    }
    render() {
        let data = {
            labels: [1, 2, 3, 4, 5, 6],
            datasets: [
                {
                    label: "Dataset -1",
                    data: [2, 8, 11, 7, 16, 1],
                    backgroundColor: "#b1acd32c",
                    borderColor: "#58508D",
                    pointBackgroundColor: "#58508D",
                    pointBorderColor: "#ffffff",
                    pointRadius: 4.5,
                    pointBorderWidth: 2,
                    borderWidth: 1,
                    fill: true,
                    lineTension: 0.4,
                    hoverBorderColor: "#316494",
                    hoverBackgroundColor: "#b1acd388",
                    pointHoverBackgroundColor: "#316494",
                    pointHoverBorderWidth: 5,
                    hoverBorderWidth: 3,
                   
                },
                {
                    label: "Dataset -2",
                    data: [9, 3, 5, 0, 12, 2],
                    backgroundColor: "#e7524f27",
                    borderColor: "#FF6361",
                    pointBackgroundColor: "#FF6361",
                    pointBorderColor: "#ffffff",
                    pointRadius: 4.5,
                    pointBorderWidth: 2,
                    borderWidth: 1,
                    fill: true,
                    lineTension: 0.4,
                    hoverBorderColor: "#FF6361",
                    hoverBackgroundColor: "#d3424056",
                    pointHoverBackgroundColor: "#d3434085",
                    pointHoverBorderWidth: 5,
                    hoverBorderWidth: 3,
                },
                {
                    label: "Dataset -3",
                    data: [12, 17, 2, 9, 3, 5],
                    backgroundColor: "#bc375425",
                    borderColor: "#BC3754",
                    pointBackgroundColor: "#BC3754",
                    pointBorderColor: "#ffffff",
                    pointRadius: 4.5,
                    pointBorderWidth: 2,
                    borderWidth: 1,
                    fill: true,
                    lineTension: 0.4,
                    hoverBorderColor: "#BC3754",
                    hoverBackgroundColor: "#cc153d4f",
                    pointHoverBackgroundColor: "#BC3754",
                    pointHoverBorderWidth: 5,
                    hoverBorderWidth: 3,
                },
                {
                    label: "Dataset -4",
                    data: [3, 8, 6, 17, 7, 2],
                    backgroundColor: "#f98d0933",
                    borderColor: "#F98E09",
                    pointBackgroundColor: "#F98E09",
                    pointBorderColor: "#ffffff",
                    pointRadius: 4.5,
                    pointBorderWidth: 2,
                    borderWidth: 1,
                    fill: true,
                    lineTension: 0.4,
                    pointHoverBorderWidth: 5,
                    hoverBorderColor: "#F98E09",
                    hoverBackgroundColor: "#f98d095e",
                    pointHoverBackgroundColor: "#F98E09",
                    hoverBorderWidth: 3,
                }
            ]
        }
        let newdata = {
            labels: [1, 2, 3, 4, 5, 6],
            datasets: [
                {
                    label: "Dataset -1",
                    data: [1, 1, 1, 2, 3, 4],
                    backgroundColor: "#b1acd32c",
                    borderColor: "#58508D",
                    pointBackgroundColor: "#58508D",
                    pointBorderColor: "#ffffff",
                    pointRadius: 4.5,
                    pointBorderWidth: 2,
                    borderWidth: 1,
                    fill: true,
                    lineTension: 0.4,
                    hoverBorderColor: "#316494",
                    hoverBackgroundColor: "#b1acd388",
                    pointHoverBackgroundColor: "#316494",
                    pointHoverBorderWidth: 5,
                    hoverBorderWidth: 3,
                },
                {
                    label: "Dataset -2",
                    data: [9, 3, 5, 0, 12, 2],
                    backgroundColor: "#e7524f27",
                    borderColor: "#FF6361",
                    pointBackgroundColor: "#FF6361",
                    pointBorderColor: "#ffffff",
                    pointRadius: 4.5,
                    pointBorderWidth: 2,
                    borderWidth: 1,
                    fill: true,
                    lineTension: 0.4,
                    hoverBorderColor: "#FF6361",
                    hoverBackgroundColor: "#d3424056",
                    pointHoverBackgroundColor: "#d3434085",
                    pointHoverBorderWidth: 5,
                    hoverBorderWidth: 3,
                },
                {
                    label: "Dataset -3",
                    data: [12, 17, 2, 9, 3, 5],
                    backgroundColor: "#bc375425",
                    borderColor: "#BC3754",
                    pointBackgroundColor: "#BC3754",
                    pointBorderColor: "#ffffff",
                    pointRadius: 4.5,
                    pointBorderWidth: 2,
                    borderWidth: 1,
                    fill: true,
                    lineTension: 0.4,
                    hoverBorderColor: "#BC3754",
                    hoverBackgroundColor: "#cc153d4f",
                    pointHoverBackgroundColor: "#BC3754",
                    pointHoverBorderWidth: 5,
                    hoverBorderWidth: 3,
                },
                {
                    label: "Dataset -4",
                    data: [3, 8, 6, 17, 7, 2],
                    backgroundColor: "#f98d0933",
                    borderColor: "#F98E09",
                    pointBackgroundColor: "#F98E09",
                    pointBorderColor: "#ffffff",
                    pointRadius: 4.5,
                    pointBorderWidth: 2,
                    borderWidth: 1,
                    fill: true,
                    lineTension: 0.4,
                    pointHoverBorderWidth: 5,
                    hoverBorderColor: "#F98E09",
                    hoverBackgroundColor: "#f98d095e",
                    pointHoverBackgroundColor: "#F98E09",
                    hoverBorderWidth: 3,
                }
            ]
        }
        return (
            <div className="linechartcolor-wapper">
                <LineChartColor newdata={newdata} data={data} />
            </div>
        )
    }
}

export default LineChartApp;