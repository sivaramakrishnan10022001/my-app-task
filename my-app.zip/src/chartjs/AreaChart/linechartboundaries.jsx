import React from "react";
import "./linechartboundaries.css";
import chart from "../../chartcdn/Chart";

class LineChartBoundaries extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }
    componentDidMount() {
        let ctx = document.getElementById('speedChart').getContext('2d');
        new chart(ctx, {
            type: "line",
            data: {
                labels: ["0s", "10s", "20s", "30s", "40s", "50s", "60s"],
                datasets: [
                    {
                        lable: "car speed (mph)",
                        data: [0, 59, 75, 30, 10, 55, 40],
                        borderColor: "#67a4dd",
                        pointBackgroundColor: "#842beb",
                        pointBorderColor: "#72dfd9",
                        // fill: "start",
                        lineTension: 0.4,
                        // tension:0.3,
                        backgroundColor: "#3b8dda6e",
                        pointRadius: 5,
                        pointHoverRadius: 7,
                        pointBorderWidth: 4,
                        pointStyle: "circle",
                        borderDash: [20, 10, 60, 10],
                        borderDashOffset: 0.0,
                        borderJoinStyle: "miter"
                        // pointHitRadius:50,
                        // cubicInterpolationMode: 'monotone',
                    },
                ]
            },
            options: {
                animations: {
                    tension: {
                        duration: 1500,
                        easing: 'linear',
                        from: 1,
                        to: 0,
                        loop: true
                    }
                },
            }
        })

    }
    render() {
        return (
            <div className="linechartboundaries-wapper">
                <div className="linechartboundaries-container">
                    <canvas id="speedChart" width="800" height="400"></canvas>
                </div>
            </div>
        )
    }

}
export default LineChartBoundaries;