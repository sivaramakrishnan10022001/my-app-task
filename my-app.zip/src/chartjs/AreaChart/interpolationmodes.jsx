import React from "react";
import "./interpolationmodes";
import Chart from "../../chartcdn/Chart";

class InterpolationModes extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }

    componentDidMount() {
        let ctx = document.getElementById('interpolationmodes').getContext('2d');
        const datapoints = [0, 20, 20, 60, 60, 120, NaN, 180, 120, 125, 105, 110, 170];
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
                datasets: [
                    {
                        label: "Cubic interpolation (monotone)",
                        data: datapoints,
                        borderColor: "#57bdec",
                        fill: false,
                        cubicInterpolationMode: 'monotone',
                        tension: 0.4
                    },
                    {
                        label: "Cubic interpolation",
                        data: datapoints,
                        borderColor: "#d81da0",
                        fill: false,
                        tension: 0.4
                    },
                    {
                        label: 'Linear interpolation (default)',
                        data: datapoints,
                        borderColor: '#1dd84c',
                        fill: false
                    }
                ]
            },
            
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Chart.js Line Chart - Cubic interpolation mode'
                    },
                },
                interaction: {
                    intersect: false,
                },
                scales: {
                    x: {
                        display: true,
                        title: {
                            display: true
                        },
                    },
                    y: {
                        display: true,
                        title: {
                            display: true,
                            text: 'Value'
                        },
                        suggestedMin: -10,
                        suggestedMax: 200,
                    }
                }
            }
        })
    }
    render() {
        return (
            <div className="interpolationmodes-wapper">
                <div className="interpolationmodes-container">
                    <canvas id="interpolationmodes" height="450" width="800"></canvas>
                </div>
            </div>
        )
    }
}

export default InterpolationModes;