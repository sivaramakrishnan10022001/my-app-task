import React from "react";
import "./linechartdatasets.css";
import Chart from "../../chartcdn/Chart";

class LineChartDatasets extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }
    componentDidMount() {
        let linechartdatasets = document.getElementById('linechartdatasets');
        const checkSpeed = (ctx, color_a, color_b) => ctx.p0.parsed.y > ctx.p1.parsed.y ? color_a : color_b;
        let dataFirst = {
            label: "Car A - Speed (mph)",
            data: [0, 59, 75, 20, 20, 55, 40],
            borderColor: "#d942dfe7",
            borderDash: [3, 3],
            stepped: "middle",
            pointStyle: "circle",
            pointBorderWidth: 4,
            pointRadius: 5,
            pointBackgroundColor: "#f1c430e7",
        };
        let dataSecond = {
            label: "Car B - Speed (mph)",
            data: [20, 15, 60, 60, 65, 30, 70],
            borderColor: "yellowgreen",
            segment: {
                borderColor: ctx => checkSpeed(ctx, 'orangered', 'yellowgreen'),
            }
        };

        let speedData = {
            labels: ["0s", "10s", "20s", "30s", "40s", "50s", "60s"],
            datasets: [dataFirst, dataSecond]
        };

        let lineChart = new Chart(linechartdatasets, {
            type: "line",
            data: speedData
        });

    }
    render() {
        return (
            <div className="linechartdatasets-wapper">
                <div className="linechartdatasets-container">
                    <canvas id="linechartdatasets" width="600" height="400"></canvas>
                </div>
            </div>
        )
    }
}

export default LineChartDatasets;