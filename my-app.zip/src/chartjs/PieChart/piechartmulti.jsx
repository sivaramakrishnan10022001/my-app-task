
import React from "react";
import "./piechartmulti.css";
import Chart from "../../chartcdn/Chart";

class PieChartMulti extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }


    render() {
        return (
            <div className="piechartmulti-wapper">
                <div className="piechartmulti-container">
                    <canvas id="piechartmulti" height="400" width="800"></canvas>
                </div>
            </div>
        )
    }
}

export default PieChartMulti;