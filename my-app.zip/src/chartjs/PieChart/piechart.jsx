
import React from "react";
import "./piechart.css";
import { Chart } from "../../chartcdn/Chart";

class PieChart extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }

    componentDidMount() {
        new Chart(document.getElementById("pie-chart"), {
            type: 'pie',
            data: {
                labels: ["Africa", "Asia", "Europe", "Latin America", "North America"],
                datasets: [{
                    label: "Population (millions)",
                    backgroundColor: ["#3e95cd", "#8e5ea2", "#3cba9f", "#e8c3b9", "#c45850"],
                    data: [2478, 5267, 734, 784, 433]
                }]
            },
            options: {
                title: {
                    display: true,
                    text: 'Predicted world population (millions) in 2050'
                }
            }
        });
    }

    render() {
        return (
            <div className="piechart-wapper">
                <div className="piechart-container">
                    <canvas id="pie-chart" width="350" height="350"></canvas>
                </div>
            </div>
        )
    }
}

export default PieChart;