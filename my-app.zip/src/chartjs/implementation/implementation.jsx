import React from "react";
import "./implementation.css";
import Chart from "../../chartcdn/Chart";

class Implementation extends React.Component {
    constructor() {
        super();

        this.state = {

        }
    }
    componentDidMount() {
        const ctx = document.getElementById('implementation').getContext('2d');
        const progress = document.getElementById('implementation');
        this.myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
                datasets: [{
                    label: '# of Votes',
                    data: [12, 19, 3, 5, 2, 3],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                plugins: {
                    legend: {
                        display: true,
                        position: "bottom",
                        labels: {
                            boxWidth: 50,
                            color: "wight",
                            font: {
                                size: 24,
                                weight: "bold"
                            }
                        }
                    },
                    tooltip: {
                        cornerRadius: 0,
                        caretSize: 0,
                        padding: 18,
                        backgroundColor: 'black',
                        borderColor: "gray",
                        borderWidth: 1,
                        titleMarginBottom: 4,
                        titleFont: {
                            "weight": "bold",
                            "size": 22
                        }
                    }
                },
                animation: {
                    onProgress: function (animation) {
                        progress.value = animation.currentStep / animation.numSteps;
                    }
                },
                scales: {
                    xAxes: [{
                        stacked: true
                    }],
                    yAxes: [{
                        stacked: true
                    }]
                }
            }
        });
    }

    updateClicked = () => {

        // this.myChart.update();
    }
    render() {
        return (

            <div className="implementation-container">
                <button onClick={this.updateClicked()}>update</button>
                <canvas id="implementation" height="400" width="800"></canvas>
            </div>

        )
    }
}

export default Implementation;