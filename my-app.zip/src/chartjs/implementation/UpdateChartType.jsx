import React from "react";
import "./UpdateChartType.css";
import Chart from "../../chartcdn/Chart";

class UpdateChartType extends React.Component {
    constructor() {
        super();
        this.state = {
            height: '500',
            width: '800',
        }
    }
    componentDidMount() {
        let monthArray = [1, 2, 3, 4, 5, 6, 7];
        let ctx = document.getElementById('UpdateChartType').getContext('2d');
        let config = {
            type: "line",
            data: {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {
                        label: "food order!",
                        fill: false,
                        pointRadius: 7,
                        backgroundColor: 'rgb(190, 99, 255, 0.25)',
                        borderColor: 'rgb(190, 99, 255)',
                        data: [1, 10, 5, 2, 20, 30, 45],

                    },
                    {
                        label: "More , food order!",
                        fill: true,
                        pointRadius: 5,
                        backgroundColor: 'rgba(255, 99, 132, 0.25)',
                        pointBackgroundColor: 'rgba(230, 34, 77, 0.993)',
                        borderColor: 'rgb(255, 99, 132)',
                        data: [20, 30, 15, 12, 21, 30, 40],
                    }
                ]
            },
            options: {
                plugins: {
                    tooltip: {
                        backgroundColor: '#f300b6',
                        titleColor: 'black',
                        titleFont: { weight: 'bold' },
                        padding: 20,
                        titleAlign: 'center',
                        // bodyColor:'#24e84efd',
                        bodyFont: {
                            // font: {
                            size: 16
                            // }
                        },
                        bodyAlign: 'center',
                        titleMarginBottom: 15,
                        bodySpacing: 7,
                        caretPadding: 5,
                        cornerRadius: 2,
                        multiKeyBackground: '#cfdd50fd',
                        boxWidth: 100,
                        displayColors: true,
                        caretSize: 30,
                        boxHeight: 20,
                        // bodyFont: {
                        //     size: 20,
                        // },
                        usePointStyle: true,
                        callbacks: {
                            beforeTitle: (context) => { return 'beforeTitle the title' },
                            title: (context) => { return `month ${context[0].label} month : ${monthArray[context[0].dataIndex]}` },
                            afterTitle: (context) => { return 'afterTitle the title ' },
                            beforeBody: (context) => { return 'beforeBody the title' },
                            afterBody: (context) => { return 'afterBody the title ' },
                            // beforeLabel: (context) => { return 'beforeLable the title' },
                            // afterLabel: (context) => { return 'afterLable the title ' },
                            beforeFooter: (context) => { return 'beforeFooter the title' },
                            footer: () => { return 'footer item' },
                            afterFooter: (context) => { return 'afterFooter the title ' },
                            labelPointStyle: (context) => {
                                return {
                                    pointStyle: 'circle',
                                    rotation: 10
                                }
                            },
                            labelColor: (context) => {
                                return {
                                    borderColor: '#e8e8f1',
                                    backgroundColor: '#00e1ff',
                                    borderWidth: 5,
                                    // borderDash: [2, 2],
                                    borderRadius: 10,
                                };
                            }

                        }
                    }
                },

                maintainAspectRatio: false,
                responsive: true,

                title: {
                    text: 'Dynamically change tooltip background example',
                    display: true
                },

                scales: {
                    y: {
                        ticks: {
                            color: 'green',
                            font: {
                                size: 16,
                                lineHeight: 1,
                                // weight: 'bold',
                                family: 'sans-serif',
                                backdropPadding: 10,
                            }
                        },
                        beginAtZero: true,
                    },
                    x: {
                        ticks: {
                            color: 'green',
                            padding: 0,
                            font: {
                                size: 16,
                                lineHeight: 5,
                            }
                        },
                        beginAtZero: true,
                    }
                },
            }
        }
        this.UpdateChart = new Chart(ctx, config);
    }

    updateChartType = (e) => {
        let configline = {
            type: "line",
            data: {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {
                        label: "food order!",
                        fill: false,
                        pointRadius: 7,
                        backgroundColor: 'rgb(190, 99, 255, 0.25)',
                        borderColor: 'rgb(190, 99, 255)',
                        data: [1, 10, 5, 2, 20, 30, 45],
                    },
                    {
                        label: "More , food order!",
                        fill: true,
                        pointRadius: 5,
                        backgroundColor: 'rgba(255, 99, 132, 0.25)',
                        pointBackgroundColor: 'rgba(230, 34, 77, 0.993)',
                        borderColor: 'rgb(255, 99, 132)',
                        data: [20, 30, 15, 12, 21, 30, 40],
                    }
                ]
            },
            options: {
                scales: {
                    y: {
                        ticks: {
                            color: 'rgba(230, 34, 77, 0.993)',
                            font: {
                                size: 16,
                                lineHeight: 1,
                                weight: 'bold',
                            }
                        },
                        beginAtZero: true,
                    },
                    x: {
                        ticks: {
                            color: 'green',
                            padding: 0,
                            font: {
                                size: 16,
                                lineHeight: 5,
                            }
                        },
                        beginAtZero: true,
                    }
                },
                maintainAspectRatio: false,
                responsive: true,
                tooltip: {
                    // titleColor
                }
            }
        }
        let configbar = {
            type: "bar",
            data: {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {
                        label: "food order!",
                        fill: false,
                        pointRadius: 7,
                        backgroundColor: 'rgb(190, 99, 255, 0.25)',
                        borderColor: 'rgb(190, 99, 255)',
                        data: [1, 10, 5, 2, 20, 30, 45],
                    },
                    {
                        label: "More , food order!",
                        fill: true,
                        pointRadius: 5,
                        backgroundColor: 'rgba(255, 99, 132, 0.25)',
                        pointBackgroundColor: 'rgba(230, 34, 77, 0.993)',
                        borderColor: 'rgb(255, 99, 132)',
                        data: [20, 30, 15, 12, 21, 30, 40],
                    }
                ]
            },
            options: {
                scales: {
                    y: {
                        ticks: {
                            color: 'rgba(230, 34, 77, 0.993)',
                            font: {
                                size: 16,
                                lineHeight: 1,
                                weight: 'bold',
                            }
                        },
                        beginAtZero: true,
                    },
                    x: {
                        ticks: {
                            color: 'green',
                            padding: 0,
                            font: {
                                size: 16,
                                lineHeight: 5,
                            }
                        },
                        beginAtZero: true,
                    }
                },

                maintainAspectRatio: false,
                responsive: true,
            }
        }
        let configdoughnut = {
            type: "doughnut",
            data: {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {
                        label: "food order!",
                        fill: false,
                        pointRadius: 7,
                        backgroundColor: 'rgb(190, 99, 255, 0.25)',
                        borderColor: 'rgb(190, 99, 255)',
                        data: [1, 10, 5, 2, 20, 30, 45],
                    },
                    {
                        label: "More , food order!",
                        fill: true,
                        pointRadius: 5,
                        backgroundColor: 'rgba(255, 99, 132, 0.25)',
                        pointBackgroundColor: 'rgba(230, 34, 77, 0.993)',
                        borderColor: 'rgb(255, 99, 132)',
                        data: [20, 30, 15, 12, 21, 30, 40],
                    }
                ]
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
            }
        }
        let configpie = {
            type: "pie",
            data: {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {
                        label: "food order!",
                        fill: false,
                        pointRadius: 7,
                        backgroundColor: 'rgb(190, 99, 255, 0.25)',
                        borderColor: 'rgb(190, 99, 255)',
                        data: [1, 10, 5, 2, 20, 30, 45],

                    },
                    {
                        label: "More , food order!",
                        fill: true,
                        pointRadius: 5,
                        backgroundColor: 'rgba(255, 99, 132, 0.25)',
                        pointBackgroundColor: 'rgba(230, 34, 77, 0.993)',
                        borderColor: 'rgb(255, 99, 132)',
                        data: [20, 30, 15, 12, 21, 30, 40],
                    }
                ]
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
            }
        }
        let configradar = {
            type: "radar",
            data: {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {
                        label: "food order!",
                        fill: false,
                        pointRadius: 7,
                        backgroundColor: 'rgb(190, 99, 255, 0.25)',
                        borderColor: 'rgb(190, 99, 255)',
                        data: [1, 10, 5, 2, 20, 30, 45],

                    },
                    {
                        label: "More , food order!",
                        fill: true,
                        pointRadius: 5,
                        backgroundColor: 'rgba(255, 99, 132, 0.25)',
                        pointBackgroundColor: 'rgba(230, 34, 77, 0.993)',
                        borderColor: 'rgb(255, 99, 132)',
                        data: [20, 30, 15, 12, 21, 30, 40],
                    }
                ]
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
            }
        }
        let configscatter = {
            type: "scatter",
            data: {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {
                        label: "food order!",
                        fill: false,
                        pointRadius: 7,
                        backgroundColor: 'rgb(190, 99, 255, 0.25)',
                        borderColor: 'rgb(190, 99, 255)',
                        data: [
                            { x: 50, y: 7 },
                            { x: 60, y: 8 },
                            { x: 70, y: 8 },
                            { x: 80, y: 9 },
                            { x: 90, y: 9 },
                            { x: 100, y: 9 },
                            { x: 110, y: 10 },
                            { x: 120, y: 11 },
                            { x: 130, y: 14 },
                            { x: 140, y: 14 },
                            { x: 150, y: 15 }
                        ],

                    },
                    // {
                    //     label: "More , food order!",
                    //     fill: true,
                    //     pointRadius: 5,
                    //     backgroundColor: 'rgba(255, 99, 132, 0.25)',
                    //     pointBackgroundColor: 'rgba(230, 34, 77, 0.993)',
                    //     borderColor: 'rgb(255, 99, 132)',
                    //     data: [20, 30, 15, 12, 21, 30, 40],
                    // }
                ]
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
            }
        }
        let configbubble = {
            type: "bubble",
            data: {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    // {
                    //     label: "food order!",
                    //     fill: false,
                    //     pointRadius: 7,
                    //     backgroundColor: 'rgb(190, 99, 255, 0.25)',
                    //     borderColor: 'rgb(190, 99, 255)',
                    //     data: [1, 10, 5, 2, 20, 30, 45],

                    // },
                    // {
                    //     label: "More , food order!",
                    //     fill: true,
                    //     pointRadius: 5,
                    //     backgroundColor: 'rgba(255, 99, 132, 0.25)',
                    //     pointBackgroundColor: 'rgba(230, 34, 77, 0.993)',
                    //     borderColor: 'rgb(255, 99, 132)',
                    //     data: [20, 30, 15, 12, 21, 30, 40],
                    // }
                    {
                        label: ['Deer Population'],
                        data: [{
                            x: 100,
                            y: 0,
                            r: 10
                        }, {
                            x: 60,
                            y: 30,
                            r: 20
                        }, {
                            x: 40,
                            y: 60,
                            r: 25
                        }, {
                            x: 80,
                            y: 80,
                            r: 50
                        }, {
                            x: 20,
                            y: 30,
                            r: 25
                        }, {
                            x: 0,
                            y: 100,
                            r: 5
                        }],
                        backgroundColor: "#FF9966"
                    }
                ]
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
            }
        }
        let configpolarArea = {
            type: "polarArea",
            data: {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {
                        label: "food order!",
                        fill: false,
                        pointRadius: 7,
                        backgroundColor: 'rgb(190, 99, 255, 0.25)',
                        borderColor: 'rgb(190, 99, 255)',
                        data: [1, 10, 5, 2, 20, 30, 45],

                    },
                    {
                        label: "More , food order!",
                        fill: true,
                        pointRadius: 5,
                        backgroundColor: 'rgba(255, 99, 132, 0.25)',
                        pointBackgroundColor: 'rgba(230, 34, 77, 0.993)',
                        borderColor: 'rgb(255, 99, 132)',
                        data: [20, 30, 15, 12, 21, 30, 40],
                    }
                ]
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
            }
        }
        this.UpdateChart.destroy();
        // this.UpdateChart.config.type = e.target.value;
        if (e.target.value === 'line') {
            this.setState({
                height: '500',
                width: '800'
            })
            let ctx = document.getElementById('UpdateChartType').getContext('2d');
            this.UpdateChart = new Chart(ctx, configline);
        }
        else if (e.target.value === 'bar') {
            this.setState({
                height: '500',
                width: '800'
            })
            let ctx = document.getElementById('UpdateChartType').getContext('2d');
            this.UpdateChart = new Chart(ctx, configbar);
        }
        else if (e.target.value === 'doughnut') {
            this.setState({
                height: '500',
                width: '500',
            })
            let ctx = document.getElementById('UpdateChartType').getContext('2d');
            this.UpdateChart = new Chart(ctx, configdoughnut);
            this.UpdateChart.update();
        }
        else if (e.target.value === 'pie') {
            this.setState({
                height: '500',
                width: '500'
            })
            let ctx = document.getElementById('UpdateChartType').getContext('2d');
            this.UpdateChart = new Chart(ctx, configpie);
        }
        else if (e.target.value === 'radar') {
            this.setState({
                height: '500',
                width: '500'
            })
            let ctx = document.getElementById('UpdateChartType').getContext('2d');
            this.UpdateChart = new Chart(ctx, configradar);
        }
        else if (e.target.value === 'scatter') {
            this.setState({
                height: '500',
                width: '500'
            })
            let ctx = document.getElementById('UpdateChartType').getContext('2d');
            this.UpdateChart = new Chart(ctx, configscatter);
            // this.UpdateChart.update();

        }
        else if (e.target.value === 'bubble') {
            this.setState({
                height: '500',
                width: '800'
            })
            let ctx = document.getElementById('UpdateChartType').getContext('2d');
            this.UpdateChart = new Chart(ctx, configbubble);
            // this.UpdateChart.update();

        }
        else if (e.target.value === 'polarArea') {
            this.setState({
                height: '400',
                width: '500'
            })
            let ctx = document.getElementById('UpdateChartType').getContext('2d');
            this.UpdateChart = new Chart(ctx, configpolarArea);
        }
        this.UpdateChart.update();
    }

    render() {
        return (
            <div className="UpdateChartType-wapper">
                <div className="UpdateChartType-container">
                    <canvas id="UpdateChartType" height={this.state.height} width={this.state.width}></canvas>
                </div>
                <div>
                    <div className="select-style">
                        <select name="chartType" id="chartType" onChange={(e) => this.updateChartType(e)}>
                            <option value="line">Line</option>
                            <option value="bar">Bar</option>
                            <option value="doughnut">Doughnut</option>
                            <option value="pie">Pie</option>
                            <option value="radar">Radar</option>
                            <option value="scatter">Scatter</option>
                            <option value="bubble">Bubble</option>
                            <option value="polarArea">polarArea</option>
                        </select>
                    </div>
                </div>
            </div>
        )
    }
}

export default UpdateChartType;