import React from "react";
import "./animationlinechart.css";
import Chart from "../../chartcdn/Chart";

class AnimationLineChart extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }
    componentDidMount() {
        var ctx = document.getElementById('animationlinechart').getContext('2d');
        var delayBetweenPoints = 10;
        var started = {};
        let allData = [{ x: 1, y: 20 }, { x: 2, y: 30 }, { x: 3, y: 50 }, { x: 4, y: 35 }, { x: 5, y: 45 }, { x: 6, y: 60 }, { x: 7, y: 50 }, { x: 8, y: 65 }, { x: 9, y: 75 }, { x: 10, y: 85 }, { x: 12, y: 75 }, { x: 12, y: 90 }]
        var data = [allData[0]];
        this.chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                datasets: [{
                    label: 'Example Stock Value',
                    borderWidth: 3,
                    pointRadius: 5,
                    pointBorderWidth: 0,
                    borderColor: "#FF6384",
                    pointBackgroundColor: ["#800080", "#00FFFF", "#FFA500", "#C0C0C0", "#FF0000", "#FF00FF",
                        "#0000FF", "#808080", "#FF00FF", "#000000", "#00008B", "#A70D2A"],
                    pointHoverBorderColor: ["#800080", "#00FFFF", "#FFA500", "#C0C0C0", "#FF0000", "#FF00FF",
                        "#0000FF", "#808080", "#FF00FF", "#000000", "#00008B", "#A70D2A"],
                    data: data,
                }]
            },
            options: {

            }
        })

        let count = 1;
        let testInterval = setInterval(() => this.testPopulate(), 1000);
        // let index = ctx.dataIndex;
        this.testPopulate = () => {
            if (count >= 12) {
                clearInterval(testInterval);
            }
            else {
                this.chart.data.datasets[0].data.push(allData[count]);
                this.chart.update();
                count++;
            }
        }
    }

    render() {
        return (
            <div className="animationlinechart-wapper">
                <div className="animationlinechart-cantainer">
                    <canvas id="animationlinechart" height="400" width="800"> </canvas>
                </div>
            </div>
        )
    }
}

export default AnimationLineChart;