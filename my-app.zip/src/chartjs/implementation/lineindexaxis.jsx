import React from "react";
import "./lineindexaxis.css";
import Chart from "../../chartcdn/Chart";

class LineIndexAxis extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }
    componentDidMount() {
        let ctx = document.getElementById('lineindexaxis').getContext('2d');
        var data = [
            { y: 1, x: 12 },
            { y: 3, x: 14 },
            { y: 4, x: 20 },
            { y: 6, x: 13 },
            { y: 9, x: 18 },
        ];
        this.chart = new Chart(ctx, {
            type: 'line',
            data: {
                datasets: [
                    {
                        data: data.map((v) => ({ y: v.y, x: v.x })),
                        borderColor: "red",
                        fill: true,
                        tension: 0.4,
                        backgroundColor: "#e621e641",
                    },
                    {
                        borderColor: "blue",
                        data: data.map((v) => ({ y: v.y, x: 2 * v.x - 1.5 * v.y })),
                        fill: true,
                        backgroundColor: "#e6bb2125",
                        tension: 0.4
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: "y",
                layout: {
                    padding: 16,
                },
                scales: {
                    y: {
                        type: "linear",
                    },
                    x: {
                        type: "linear",
                    },
                },
            }
        })
    }
    render() {
        return (
            <div className="lineindexaxis-wapper">
                <div className="lineindexaxis-container">
                    <canvas id="lineindexaxis" height="400" width="800"></canvas>
                </div>
            </div>
        )
    }
}

export default LineIndexAxis;