import React from "react";
import "./implementation.css";
import Implementation from "./implementation";

class ImplementationApp extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }
    render() {
        return (
            <div className="implementation-wapper">
                <Implementation />
            </div>
        )
    }
}

export default ImplementationApp;