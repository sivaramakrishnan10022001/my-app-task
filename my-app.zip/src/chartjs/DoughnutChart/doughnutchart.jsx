import React from "react";
import "./doughnutchart.css";
import Chart from "../../chartcdn/Chart";

class DoughnutChart extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }
    componentDidMount() {
        let ctx = document.getElementById("doughnut").getContext('2d');

        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ["Africa", "Asia", "Europe", "Latin America", "North America"],
                datasets: [
                    {
                        label: "Population (millions)",
                        backgroundColor: ["#3e95cd", "#8e5ea2", "#3cba9f", "#e8c3b9", "#c45850"],
                        data: [2478, 5267, 734, 784, 433]
                    }
                ]
            },
            options: {
                title: {
                    display: true,
                    text: 'Predicted world population (millions) in 2050'
                }
            }
        });
    }
    render() {
        return (
            <div className="doughnutchart-wapper">
                <div className="doughnutchart-container">
                    <canvas id="doughnut" width="400" height="400"></canvas>
                </div>
            </div>
        )
    }
}

export default DoughnutChart;