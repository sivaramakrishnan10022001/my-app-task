import React from "react";
import "./doughnut.css";
import Chart from "../../chartcdn/Chart";

class Doughnut extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }

    componentDidMount() {
        let ctx = document.getElementById('doughnut').getContext('2d');
        this.mydoughnut = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ["Africa", "Asia", "Europe", "Latin America", "North America"],
                datasets: [
                    {
                        label: 'My First Dataset',
                        data: [300, 100, 50, 50, 50],
                        backgroundColor: [
                            'rgb(255, 99, 132)',
                            'rgb(54, 162, 235)',
                            'rgb(255, 205, 86)',
                            "yellow",
                            "yellow",

                        ],
                        hoverOffset: 40,
                    }
                ]
            }
        })

    }

    render() {

        return (
            <div className="doughnut-wapper">
                <div className="doughnut-container">
                    <canvas id="doughnut" height="250" width="400"></canvas>
                </div>
            </div>
        )
    }
}

export default Doughnut;