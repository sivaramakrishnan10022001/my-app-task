import React from "react";
import "./polarAreachart.css";
import { Chart } from "../../chartcdn/Chart";

class PolarAreaChart extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }

    componentDidMount() {
        new Chart(document.getElementById("polar-chart"), {
            type: 'polarArea',
            data: {
                labels: ["Africa", "Asia", "Europe", "Latin America", "North America"],
                datasets: [
                    {
                        label: "Population (millions)",
                        backgroundColor: ["#3e95cd", "#8e5ea2", "#3cba9f", "#e8c3b9", "#c45850"],
                        data: [2478, 5267, 734, 784, 433]
                    }
                ]
            },
            options: {
                title: {
                    display: true,
                    text: 'Predicted world population (millions) in 2050'
                }
            }
        });
    }
    render() {
        return (
            <div className="polarareachart-wapper">
                <div className="polarAreachart-container">
                    <canvas id="polar-chart" width="350" height="350"></canvas>
                </div>
            </div>
        )
    }
}

export default PolarAreaChart;