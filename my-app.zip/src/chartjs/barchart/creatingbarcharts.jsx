import React from "react";
import "./creatingbarcharts.css";
import { Chart } from "../../chartcdn/Chart";

class CreatingBarCharts extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }
    
    componentDidMount() {
        const densityCanvas = document.getElementById("densityChart");
        let densityData = {
            label: 'Density of Planets (kg/m3)',
            data: [5427, 5243, 5514, 3933, 1326, 687, 1271, 1638]
        };
        new Chart(densityCanvas, {
            type: 'bar',
            data: {
                labels: ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"],
                datasets: [densityData]
            }
        });

    }
    render() {
        return (
            <div className="creatingbarcharts-wapper">
                <div className="creatingbarcharts-container">
                    <canvas id="densityChart" width="600" height="400"></canvas>
                </div>
            </div>
        )
    }
}

export default CreatingBarCharts;