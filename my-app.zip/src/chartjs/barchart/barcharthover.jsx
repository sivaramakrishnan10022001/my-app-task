import React from "react";
import "./barcharthover.css";
import Chart from "../../chartcdn/Chart";

class BarChartHover extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }
    componentDidMount() {
        let ctx = document.getElementById('barcharthover').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"],
                datasets: [
                    {
                        label: "Dataset #1",
                        backgroundColor: "#ff638433",
                        borderColor: '#ff6384',
                        borderWidth: 2,
                        hoverBackgroundColor: "#ff638466",
                        hoverBorderColor: "#ff6384",
                        data: [65, 59, 20, 81, 56, 55, 40],

                    }
                ]
            },
            options: {
                maintainAspectRatio: false,
                scales: {
                    y: {
                        stacked: true,
                        grid: {
                            display: true,
                            color: "#ff638433"
                        }
                    },
                    x: {
                        grid: {
                            display: false,
                        }
                    }
                }
            }
        });

    }
    render() {
        return (
            <div className="barcharthover-wapper">
                <div className="barcharthover-container">
                    <canvas id="barcharthover" height="400" width="800"></canvas>
                </div>
            </div>
        )
    }
}

export default BarChartHover;