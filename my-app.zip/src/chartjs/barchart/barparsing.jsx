import React from "react";
import "./barparsing.css";
import { Chart } from "../../chartcdn/Chart";

class Barparsing extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }
    componentDidMount() {
        const ctx = document.getElementById('canvas').getContext('2d');
        const data = [
            { x: 'Jan', net: 100, cogs: 50, gm: 50 },
            { x: 'Feb', net: 120, cogs: 55, gm: 75 }
        ];

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb'],
                datasets: [{
                    label: 'Net sales',
                    data: data,
                    parsing: {
                        yAxisKey: 'net'
                    }
                }, {
                    label: 'Cost of goods sold',
                    data: data,
                    parsing: {
                        yAxisKey: 'cogs'
                    }
                }, {
                    label: 'Gross margin',
                    data: data,
                    parsing: {
                        yAxisKey: 'gm'
                    }
                }]
            },
        })
    }
    render() {
        return (
            <div className="barparsing-wapper">
                <canvas id="canvas" width="600" height="400"></canvas>
            </div>
        )
    }
}

export default Barparsing;