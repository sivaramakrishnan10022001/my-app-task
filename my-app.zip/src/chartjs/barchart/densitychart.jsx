import React from "react";
import "./densitychart.css";
import chart from "../../chartcdn/Chart";

class DensityChart extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }
    componentDidMount() {
        const densityCanvas = document.getElementById("DensityofPlanets");

        new chart(densityCanvas, {
            type: "bar",
            data: {
                labels: ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"],
                datasets: [
                    {
                        label: "Density of Planets (kg/m3)",
                        data: [5427, 5243, 5514, 3933, 1326, 687, 1271, 1638],
                        backgroundColor: "pink",
                        borderColor: "red",
                        borderWidth: 2,
                        hoverBorderWidth: 2,
                        hoverBackgroundColor: "darkgray",
                        hoverBorderColor: "green",
                        indexAxis: "y",
                        barPercentage: 1.1
                    }
                ]
            }
        });
    }
    render() {
        return (
            <div className="DensityofPlanets-wapper">
                <canvas id="DensityofPlanets" width="600" height="300"></canvas>
            </div>
        )
    }
}

export default DensityChart;