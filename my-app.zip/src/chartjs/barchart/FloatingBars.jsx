import React from "react";
import "./FloatingBars.css";
import Chart from "../../chartcdn/Chart";

class FloatingBars extends React.Component {
    
    constructor() {
        super();
        this.state = {
        }
    }

    componentDidMount() {
        let Canvas = document.getElementById('floatingbars').getContext('2d');
        new Chart(Canvas, {
            type: "bar",
            data: {
                labels: ["junuary", "february", "march", "apirl", "may", "june", "july"],
                datasets: [
                    {
                        label: 'Dataset 1',
                        backgroundColor: "#FF6384",
                        data: [39, 98, 50, -50, 80, -90, -30],
                    },
                    {
                        label: 'Dataset 2',
                        backgroundColor: "#36A2EB",
                        data: [-90, -65, -78, 55, -41, -81, -45],
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Chart.js Floating Bar Chart'
                    }
                }
            }
        })
    }
    render() {
        return (
            <div className="floatingbars-wapper">
                <div className="floatingbars-container">
                    <canvas id="floatingbars" height="450" width="850"></canvas>
                </div>
            </div>
        )
    }
}

export default FloatingBars;