import React from "react";
import "./BarChartBorderRadius.css";
import { Chart } from "../../chartcdn/Chart";


class BarChartBorderRadius extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }
    componentDidMount() {
        let Canvas = document.getElementById('border-radius');
        const borderRadius = 50;
        const borderRadiusAllCorners = {
            topLeft: borderRadius,
            topRight: borderRadius,
            bottomLeft: borderRadius,
            bottomRight: borderRadius
        }

        new Chart(Canvas, {
            type: "bar",
            data: {
                labels: ["Red", "Blue", "Yellow", "Green", "Purple", "Orange"],
                datasets: [
                    {
                        label: "data 1",
                        data: [-12, -25, 13, 10, 25, -9],
                        backgroundColor: "#e6c298",
                        borderWidth: 2,
                        borderColor: "#ce9d65",
                        borderSkipped: false,
                        borderRadius: borderRadiusAllCorners
                    },
                    {
                        label: 'data 2',
                        data: [20, 21, -27, 3, -8, -37],
                        backgroundColor: '#b4b9d8',
                        borderWidth: 2,
                        borderColor: "#8e98da",
                        borderRadius: 5,
                        borderSkipped: false,
                    },


                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Chart.js Bar Chart'
                    }
                }
            },
        })
    }
    render() {
        return (
            <div className="barchart-border-radius-wapper">
                <div>
                    <canvas id="border-radius" height="400" width="750"></canvas>
                </div>
            </div>
        )
    }
}

export default BarChartBorderRadius;