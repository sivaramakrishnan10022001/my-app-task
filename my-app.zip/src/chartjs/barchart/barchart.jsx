import React from "react";
import "./barchart.css";
import chart from "../../chartcdn/Chart";

class BarChart extends React.Component {
    constructor() {
        super();
        this.state = {
        }
    }
    componentDidMount() {
        const ctx = document.getElementById('bar-chart').getContext('2d');
        new chart(ctx, {
            type: "bar",
            data: {
                labels: ["Africa", "Asia", "Europe", "Latin America", "North America"],
                datasets: [
                    {
                        lable: "Population (millions)",
                        backgroundColor: ["#3e95cd", "#8e5ea2", "#3cba9f", "#e8c3b9", "#c45850"],
                        data: [2478, 5267, 734, 784, 433]
                    }
                ],
            },
            options: {
                legend: {
                    display: false,
                },
                title: {
                    display: true,
                    text: 'Predicted world population (millions) in 2050'
                }
            }
        })
    }
    render() {
        return (
            <div className="barchart-wapper">
                <div className="barchart-container">
                    <canvas id="bar-chart" width="600" height="400"></canvas>
                </div>
            </div>
        )
    }
}

export default BarChart;