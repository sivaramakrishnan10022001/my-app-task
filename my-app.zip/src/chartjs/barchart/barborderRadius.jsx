import React from "react";
import "./barborderRadius.css";
import Chart from "../../chartcdn/Chart";

class BarBorderRadius extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }
    componentDidMount() {
        let Canvas = document.getElementById('barborderRadius').getContext('2d');
        const borderRadius = 50;
        const borderRadiusAllCorners = {
            topLeft: borderRadius,
            topRight: borderRadius,
            bottomLeft: borderRadius,
            bottomRight: borderRadius
        }

        new Chart(Canvas, {
            type: "bar",
            data: {
                labels: ["Red", "Blue", "Yellow", "Green", "Purple", "Orange"],
                datasets: [{
                    label: 'data 0',
                    data: [12, 19, 3, 5, 2, 3],
                    backgroundColor: '#bd539d',
                    borderWidth: 0,
                    borderRadius: borderRadiusAllCorners,
                    borderSkipped: false,
                }, {
                    label: 'data 1',
                    data: [20, 5, 10, 15, 12, 13],
                    backgroundColor: '#00ffbf',
                    borderWidth: 0,
                    borderRadius: borderRadiusAllCorners,
                    borderSkipped: false,
                }, {
                    label: 'data 2',
                    data: [20, 0, 30, 0, -5, -10],
                    backgroundColor: '#fc70d2',
                    borderWidth: 0,
                    borderRadius: borderRadiusAllCorners,
                    borderSkipped: false,
                }]
            },
            options: {
                scales: {
                    y: {
                        stacked: true,
                    },
                    x: {
                        stacked: true,
                    }
                }
            }
        })

    }

    render() {
        return (
            <div className="barborder-radius-wapper">
                <div className="barborder-radius-container">
                    <canvas id="barborderRadius" height="400" width="800"></canvas>
                </div>
            </div>
        )
    }
}

export default BarBorderRadius;