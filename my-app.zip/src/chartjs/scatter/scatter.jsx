import React from "react";
import "./scatter.css";
import Chart from "../../chartcdn/Chart";

class Scatter extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }
    componentDidMount() {
        let Canvas = document.getElementById('scatter').getContext('2d');
        var xyValues = [
            { x: 50, y: 7 },
            { x: 60, y: 8 },
            { x: 70, y: 8 },
            { x: 80, y: 9 },
            { x: 90, y: 9 },
            { x: 100, y: 9 },
            { x: 110, y: 10 },
            { x: 120, y: 11 },
            { x: 130, y: 14 },
            { x: 140, y: 14 },
            { x: 150, y: 15 }
        ];

        new Chart(Canvas, {
            type: "scatter",
            data: {
                datasets: [{
                    label:'data',
                    pointRadius: 4,
                    pointBackgroundColor: "#6f1ff1",
                    data: xyValues
                }]
            },
            options: {
                legend: { display: false },
                scales: {
                    xAxes: [{ ticks: { min: 40, max: 160 } }],
                    yAxes: [{ ticks: { min: 6, max: 16 } }],
                }
            }
        })
    }
    render() {
        return (
            <div className="scatter-wapper">
                <div className="scatter-container">
                    <canvas id="scatter" height="400" width="800"></canvas>
                </div>
            </div>
        )
    }
}

export default Scatter;