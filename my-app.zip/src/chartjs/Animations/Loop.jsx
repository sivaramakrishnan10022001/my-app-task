
import React from "react";
import "./Loop.css";
import Chart from "../../chartcdn/Chart";

class Loop extends React.Component {

    constructor() {
        super();
        this.state = {
        }
    }

    componentDidMount() {
        let ctx = document.getElementById('loop').getContext('2d');
        new Chart(ctx, {
            type: "line",
            data: {
                labels: ["junuary", "february", "march", "apirl", "may", "june", "july"],
                datasets: [
                    {
                        label: "Dataset 1",
                        data: [20, 80, 30, 20, 30, 65, 10],
                        borderColor: "#eb672a",
                        pointBorderWidth: 4,
                        tension: 0.4,
                    },
                    {
                        label: "Dataset 2",
                        data: [50, 70, 60, 10, 30, 20, 60],
                        borderColor: "#ff00ea",
                        pointBorderWidth: 4,
                        tension: 0.4,

                    }
                ]
            },
            options: {
                animations: {
                    radius: {
                        duration: 400,
                        easing: 'linear',
                        loop: (context) => context.active
                    }
                },
                hoverRadius: 12,
                hoverBackgroundColor: 'yellow',
                interaction: {
                    mode: 'nearest',
                    intersect: false,
                    axis: 'x'
                },
                plugins: {
                    tooltip: {
                        enabled: false
                    }
                }
            }
        })
    }
    render() {
        return (
            <div className="loop-wapper">
                <div className="loop-container">
                    Loop animation 
                    <canvas id="loop" height="400" width="800"></canvas>
                </div>
            </div>
        )
    }
}

export default Loop;
