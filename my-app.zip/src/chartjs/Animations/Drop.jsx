
import React from "react";
import "./Drop.css";
import Chart from "../../chartcdn/Chart";

class Drop extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }
    componentDidMount() {
        let ctx = document.getElementById('drop').getContext('2d');
        new Chart(ctx, {
            type: "line",
            data: {
                labels: ["junuary", "february", "march", "apirl", "may", "june", "july"],
                datasets: [
                    {
                        label: "Dataset 1",
                        animations: {
                            y: {
                                duration: 2000,
                                delay: 500
                            }
                        },
                        data: [20, 80, 30, 20, 30, 65, 10],
                        borderColor: "#ff00ea",
                        backgroundColor: "#00fff2",
                        fill: 1,
                        tension: 0.5,
                        pointStyle: "circle",
                        borderWidth: 3,
                        pointBorderWidth: 8,

                    },
                    {
                        label: "Dataset 2",
                        data: [50, 70, 60, 10, 30, 20, 60],
                        borderColor: "#eb672a",
                        backgroundColor: "#df3bc9",
                        tension: 0.5,
                        pointStyle: "circle",
                        borderWidth: 4,
                        pointBorderWidth: 8,

                    }
                ]
            }
        })
    }
    render() {
        return (
            <div className="drop-wapper">
                <div className="drop-container">
                    drop animation

                    <canvas id="drop" height="400" width="850"></canvas>
                </div>
            </div>
        )
    }
}

export default Drop;