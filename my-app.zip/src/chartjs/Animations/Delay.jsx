
import React from "react";
import "./Delay.css";
import Chart from "../../chartcdn/Chart";

class Delay extends React.Component {
    constructor() {
        super();
        this.state = {

        }
    }
    componentDidMount() {
        let ctx = document.getElementById('delay').getContext('2d');
        let delayed;
        new Chart(ctx, {
            type: "bar",
            data: {
                labels: ["junuary", "february", "march", "apirl", "may", "june", "july"],
                datasets: [
                    {
                        label: "Dataset 1",
                        data: [18, 23, 51, 32, 22, 33, 13],
                        backgroundColor: "#8a2be2"
                    },
                    {
                        label: 'Dataset 2',
                        data: [52, 23, 13, 32, 23, 11, 32],
                        backgroundColor: "#e22bca"
                    },
                    {
                        label: 'Dataset 3',
                        data: [63, 12, 33, 44, 23, 21, 32],
                        backgroundColor: "#2be27d",
                    },
                ]
            },
            options: {
                animation: {
                    onComplete: () => {
                        delayed = true;
                    },
                    delay: (context) => {
                        let delay = 0;
                        if (context.type === 'data' && context.mode === 'default' && !delayed) {
                            delay = context.dataIndex * 300 + context.datasetIndex * 100;
                        }
                        return delay;
                    },
                },
                scales: {
                    x: {
                        stacked: true,
                    },
                    y: {
                        stacked: true
                    }
                }
            },

        })
    }
    render() {
        return (
            <div className="delay-wapper">
                delay animation
                <div className="delay container">
                    <canvas id="delay" height="400" width="700" ></canvas>
                </div>
            </div>
        )
    }
}

export default Delay;