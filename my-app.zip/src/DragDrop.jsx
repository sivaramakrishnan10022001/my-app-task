import React, { useState, useRef } from 'react';
// import './DragDrop.css';

const DragDrop = () => {
  const dragItem = useRef();
  const dragOverItem = useRef();
  const [list, setList] = useState(['Item 1', 'Item 2', 'Item 3', 'Item 4', 'Item 5', 'Item 6']);
  const dragStart = (e, position) => {
    dragItem.current = position;
    console.log(e.target.innerHTML);
    console.log(dragItem.current, "current-start");
  };
  //   console.log(dragItem,"dragItem")
  //   console.log(dragOverItem,"dragOverItem")

  const dragEnter = (e, position) => {
    dragOverItem.current = position;
    console.log(e.target.innerHTML);
    console.log(dragOverItem, "drag-enter");
  };

  const drop = (e) => {
    const copyListItems = [...list];
    console.log("console-end1", dragItem.current);
    const dragItemContent = copyListItems[dragItem.current];
    console.log("console-end2", dragItemContent);
    copyListItems.splice(dragItem.current, 1);
    copyListItems.splice(dragOverItem.current, 0, dragItemContent);
    dragItem.current = null;
    dragOverItem.current = null;
    setList(copyListItems);
  };

  return (
    <>
      {
        // list &&
        list.map((item, index) => (
          <div style={{ backgroundColor: 'lightblue', margin: '20px 25%', textAlign: 'center', fontSize: '40px' }}
            onDragStart={(e) => dragStart(e, index)}
            onDragEnter={(e) => dragEnter(e, index)}
            onDragEnd={drop}
            key={index}
            draggable>
            {item}
          </div>
        ))}
    </>
  );
};
export default DragDrop;
