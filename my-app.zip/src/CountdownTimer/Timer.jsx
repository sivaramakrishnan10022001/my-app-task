import React, { Component } from 'react'

class Timer extends Component {
    state = {
        minutes: 1,
        seconds: 0,
        // hours: 1,
    }

    componentDidMount() {

        this.myInterval = setInterval(() => {
            const { seconds, minutes, hours } = this.state;
            if (seconds > 0) {
                this.setState(({ seconds }) => ({
                    seconds: seconds - 1
                }))
            }

            if (seconds === 0) {
                if (minutes === 0 && seconds && hours) {
                    clearInterval(this.myInterval)
                }
                else {
                    this.setState(({ minutes }) => ({
                        minutes: minutes - 1,
                        seconds: 59,
                    }))
                }
            }
        }, 1000)
    }
    componentWillUnmount() {
        clearInterval(this.myInterval)
    }

   

    render() {
        const { hours, minutes, seconds } = this.state
        return (
            <div className='Timer_wapper'>
                <div className="Timer_container">
                    <div className="clock">
                        {hours}
                    </div>
                    <div className="clock">
                        {minutes}
                    </div>
                    :
                    <div className='clock'>
                        {seconds}
                    </div>
                </div>
            </div>
        )
    }
}

export default Timer;
