import React from "react";
import "./Test.css";
class Test extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            heading: ["id", "name", "color", "food"],
            // heading: [{ name: "id" }, { name: "name" }, { color: "color" }, { food: "food" }],
            data: [
                { id: 1, name: "siva", color: "blue", food: "fish" },
                { id: 2, name: "raj", color: "black", food: "non veg" },
                { id: 3, name: "kumar", color: "blue", food: "veg" },
                { id: 4, name: "ram", color: "blue", food: "fish" },
            ]
        }
        this.myRef = React.createRef();
        this.refOver = React.createRef();
        this.headingRef = React.createRef();
        this.headingHoverRef = React.createRef();
    }

    headingStart = (e, index) => {
        this.headingRef = index;
        console.log("position", this.headingRef);
        console.log(e.target.innerHTML);
    }

    headingHover = (e, index) => {
        this.headingHoverRef = index;
        console.log("position", this.headingHoverRef);
        console.log(e.target.innerHTML);
    }

    headingEnd = () => {
        let data = [...this.state.heading];
        let copyheading = data[this.headingRef];
        data.splice(this.headingRef, 1);
        data.splice(this.headingHoverRef, 0, copyheading);
        this.headingRef = null;
        this.headingHoverRef = null;
        this.setState({
            heading: data,
        })
    }

    dragStart = (e, position) => {
        this.myRef.current = position;
        console.log(e.target.innerHTML, "start");
    }

    dragenter = (e, position) => {
        this.refOver.current = position;
        console.log(e.target.innerHTML, "hover");

    }

    dragEnd = () => {
        let datas = [...this.state.data];
        let copydata = datas[this.myRef.current];
        console.log("end", copydata);
        datas.splice(this.myRef.current, 1);
        datas.splice(this.refOver.current, 0, copydata);
        this.myRef.current = null;
        this.refOver.current = null;
        this.setState({
            data: datas,
        })
    }

    render() {
        return (
            <div className="Test">
                <table>
                    <thead>
                        <tr>
                            {
                                this.state.heading.map((v, index) => {
                                    return (
                                        <th onDragStart={(e) => this.headingStart(e, index)}
                                            onDragEnter={(e) => this.headingHover(e, index)}
                                            onDragEnd={() => this.headingEnd()}
                                            draggable  >
                                            {v}
                                        </th>
                                    );
                                })
                            }
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.data.map((val, inx) => {
                             
                                return (
                                    <tr key={inx}
                                        onDragStart={(e) => this.dragStart(e, inx)}
                                        onDragEnter={(e) => this.dragenter(e, inx)}
                                        onDragEnd={(e) => this.dragEnd(e)}
                                        draggable >

                                     
                                        {
                                            this.state.heading.map((hval, hinx) => {
                                                return <td>{val[hval]}</td>
                                            })
                                        }
                                    

                                    </tr>
                                );

                            })
                        }
                    </tbody>
                </table>
            </div>
        );
    }
}


export default Test;