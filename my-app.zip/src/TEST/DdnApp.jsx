import React from "react";
import "./DdnApp.css";
import Card2 from "./Card2";

class DdnApp extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            down: false,
            no: 0,
            v: 0.0,
            pos: 1,
            clicked: 0,
            card: [0, 1, 2, 3],
            card1: ["java", "javascript", "c++", "Reactjs"]
        };
        this.changePos = this.changePos.bind(this);
    }

    changePos(i, newPos, oldPos) {
        let arr = this.state.card;
        for (let j = 0; j < 4; j++) {
            if (j != i) {
                if (arr[j] === newPos) {
                    arr[j] = oldPos;
                    arr[i] = newPos;
                }
            }
        }
        this.setState({
            card: arr
        });
    }

    render() {

        // let cards =this.state.items.map((item,i)=>{
        //     return(
        //         <Card2 key={i} title={item.title} item={item.num} y={item.num * 100} handlePos={this.changePos} />
        //     )
        // })

        let cards = this.state.card.map((item, i) => {
            return (
                <Card2 key={i} item={item} y={item * 100} handlePos={this.changePos} />
            );
        });
        return (
            <div className="DdnApp_container">
                <div className="DdnApp">
                    <div className="container">{cards}
                     
                    </div>
                </div>
            </div>

        );
    }
}

export default DdnApp