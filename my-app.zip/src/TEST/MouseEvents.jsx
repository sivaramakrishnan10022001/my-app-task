

import React from "react";
import "./MouseEvents.css";

class MouseEvents extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            datas: ["HTML", "CSS", "JavaScript", "PHP", "MySQL"],
            message: "Mouse Event",
            top: "",
            left: "",
            y:null,
            headingMove: false,
        }
        this.headingRef = React.createRef("");
        // this.headingHoverRef = React.createRef();
    }


    headingDown = (e, position) => {
        this.headingRef = position;
        // console.log(e.clientY)

        // console.log(e.target.id, "event ___ ")
        // console.log(this.headingRef, "headingRef")
// let data =this.state.y -150;
        // let items = document.getElementById(e.target.id);
        // console.log(items, "itemsitemsitems")
        // items.style.top = e.clientY - data+ "px";

        // items.addEventListener('mousemove',(event)=>{
        //    console.log(e.clientY,"t");
        // })
    }

    headingMove = (e) => {
        // console.log(window.event.clientX,"window screen",window.event.clientY)
        // let x = e.clientX;
        let y = e.clientY;
        this.setState({
            y:y,
        })
        // let item = document.getElementById(this.headingRef);
        // item.style.zIndex = "1050";
        // item.style.top = y - 140 + "px";
        //  console.log(item,"item-item=item ")
        // console.log("x", "x", ":", "y", y)
        // console.log(e., "e.clientx")
        // console.log(e.clientY, "e.clientY")
        // document.getElementById(e.target.id).style.left = e.clientX -100+ "px";
        // document.getElementById(e.target.id).style.top = e.clientY - 200 + "px";

    }

    headingUp = () => {

    }
    dragStart = (e) => {
        // console.log("dragStart")
    }
    dragEnter = (e) => {
        // console.log(e.clientY,"dragEnter")
    }
    drop = () => {
        // console.log("drop")
    }


    // left: e.clientX - 365,


    render() {
        return (
            <div className="MouseEvents_wapper" >
                <div className="MouseEvents_content"
                    onMouseMove={(e) => this.headingMove(e)}
                >
                    {this.state.datas.map((item, index) => {
                        return (
                            <div className="MouseEvents"
                                id={`${index}`}
                                style={{ top: 50 * index + "px" }}
                                key={index}
                                ref={this.headingRef}

                                onMouseDown={(e) => this.headingDown(e, index)}
                                onMouseUp={() => this.headingUp()}
                                onDragStart={(e) => this.dragStart(e, index)}
                                onDragEnter={(e) => this.dragEnter(e, index)}
                                onDragEnd={() => this.drop()}
                                draggable>
                                <h3>{item}</h3>
                            </div>
                        )
                    })}
                </div>
            </div>

        )
    }
}

export default MouseEvents;