import React from "react";
import "../Animation/Animation.css";

class TestingList extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            Numbers: [
                { num: 1 },
                { num: 2 },
                {
                    num: 3,
                    nums: [{ num: 1 }, { num: 2 }, { num: 3 }]
                },
                { num: 4 },
                { num: 5 }],
            // Numbers: [1, 2, 3, 4, 5, [11, 12, 13, 14]],
            styling: false,
            diffX: 0,
            diffY: 0,
            dragging: false,
            styles: {},
        };
        this.headingRef = React.createRef();
        this.headingHoverRef = React.createRef();
    }

    headingStart = (e, index) => {
        this.headingRef = index;
        console.log("position", this.headingRef);
        console.log(e.target.innerHTML);
        this.setState({
            value: index,
            styling: true,
        });
    };

    childheadingStart = (e, inx) => {
        console.log("childheadingStart inx", inx);
    }

    _dragStart = (e) => {
        this.setState({
            diffX: e.screenX - e.currentTarget.getBoundingClientRect().left,
            diffY: e.screenY - e.currentTarget.getBoundingClientRect().top,
            dragging: true,
        });
    };

    headingHover = (e, index) => {
        this.headingHoverRef = index;
        console.log("position", this.headingHoverRef);
        console.log(e.target.innerHTML);
    };

    childheadingHover = (e, inx) => {
        console.log("childheadingHover inx", inx);
    }

    _dragging = (e) => {
        if (this.state.dragging) {
            var left = e.screenX - this.state.diffX;
            var top = e.screenY - this.state.diffY;
            this.setState({
                styles: {
                    left: left,
                    top: top,
                },
            });
        }
    };

    headingEnd = () => {
        let data = [...this.state.Numbers];
        let copyheading = data[this.headingRef];
        data.splice(this.headingRef, 1);
        data.splice(this.headingHoverRef, 0, copyheading);

        this.headingRef = null;
        this.headingHoverRef = null;
        this.setState({
            Numbers: data,
            styling: false,
        });
    };

    childheadingEnd = (e) => {
        console.log("childheadingEnd")
    }
    _dragEnd = () => {
        this.setState({
            dragging: false,
        });
    };
    render() {
        return (
            <div className="container">
                {this.state.Numbers.map((num, index) => {
                    return (
                        <div
                            className={`siva ${index === index ? "styling" : "siva"}`}
                            key={index}
                            style={this.state.styles}
                            onDragStart={(e) => this.headingStart(e, index)}
                            onMouseDown={(e) => this._dragStart(e)}
                            onDragEnter={(e) => this.headingHover(e, index)}
                            onMouseMove={(e) => this._dragging(e)}
                            onDragEnd={(e) => this.headingEnd(e)}
                            onMouseUp={(e) => this._dragEnd(e)}
                            draggable="true"
                        >
                            <h1>{num.num}</h1>
                            {
                                num.nums ?
                                    num.nums.map((number, inx) => {
                                        return (
                                            <div
                                                className="sample"
                                                onDragStart={(e) => this.childheadingStart(e, inx)}
                                                onDragEnter={(e) => this.childheadingHover(e, inx)}
                                                onDragEnd={(e) => this.childheadingEnd(e)}
                                                draggable="true"
                                            >{number.num}</div>
                                        )
                                    })
                                    : ""
                            }
                        </div>
                    );
                })}
            </div>
        );
    }
}

export default TestingList;
