import React from "react";
import "./SortingAndSelecting.css";

class SortingAndSelecting extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
         
            SortingAndSelecting_Orginal_Data: [
                { name: "Cupcake", calories: 305, fat: 3.7, carbs: 67, protein: 4.3, },
                { name: "Donut", calories: 452, fat: 25.0, carbs: 51, protein: 4.9, },
                { name: "Eclair", calories: 262, fat: 16.0, carbs: 24, protein: 6.0, },
                { name: "Frozen yoghurt", calories: 159, fat: 6.0, carbs: 24, protein: 4.0, },
                { name: "Gingerbread", calories: 356, fat: 16.0, carbs: 49, protein: 3.9, },
                { name: 'Honeycomb', calories: 408, fat: 3.2, carbs: 87, protein: 6.5 },
                { name: 'AIce cream sandwich', calories: 237, fat: 9.0, carbs: 37, protein: 4.3 },
                { name: 'Jelly Bean', calories: 375, fat: 0.0, carbs: 94, protein: 0.0 },
                { name: 'AKitKat', calories: 518, fat: 26.0, carbs: 65, protein: 7.0 },
                { name: 'Lollipop', calories: 392, fat: 0.2, carbs: 98, protein: 0.0 },
                { name: 'Marshmallow', calories: 318, fat: 0, carbs: 81, protein: 2.0 },
                { name: 'Nougat', calories: 360, fat: 19.0, carbs: 9, protein: 37.0 },
                { name: 'Oreo', calories: 437, fat: 18.0, carbs: 63, protein: 4.0 },
                // copy 
                { name: "Cupcake", calories: 305, fat: 3.7, carbs: 67, protein: 4.3, },
                { name: "Donut", calories: 452, fat: 25.0, carbs: 51, protein: 4.9, },
                { name: "Eclair", calories: 262, fat: 16.0, carbs: 24, protein: 6.0, },
                { name: "Frozen yoghurt", calories: 159, fat: 6.0, carbs: 24, protein: 4.0, },
                { name: "Gingerbread", calories: 356, fat: 16.0, carbs: 49, protein: 3.9, },
                { name: 'Honeycomb', calories: 408, fat: 3.2, carbs: 87, protein: 6.5 },
                { name: 'AIce cream sandwich', calories: 237, fat: 9.0, carbs: 37, protein: 4.3 },
                { name: 'Jelly Bean', calories: 375, fat: 0.0, carbs: 94, protein: 0.0 },
                { name: 'AKitKat', calories: 518, fat: 26.0, carbs: 65, protein: 7.0 },
                { name: 'Lollipop', calories: 392, fat: 0.2, carbs: 98, protein: 0.0 },
                { name: 'Marshmallow', calories: 318, fat: 0, carbs: 81, protein: 2.0 },
                { name: 'Nougat', calories: 360, fat: 19.0, carbs: 9, protein: 37.0 },
                { name: 'Oreo', calories: 437, fat: 18.0, carbs: 63, protein: 4.0 },
            ],
            SortingAndSelecting_Data: [],
            head_bg_color: false,
            Asscending: false,
            Descending: false,
            sliceStart: 0,
            sliceEnd: 5,
            sliceEnd_5: true,
            sliceEnd_10: false,
            sliceEnd_25: false,
            data_position_start: 1,
            data_position_end: false,
            DensePadding: false

        }
    }

    componentDidMount() {
        this.setState({
            SortingAndSelecting_Data: this.state.SortingAndSelecting_Orginal_Data,
        })
    }

    Dessert = () => {
        let Sort_Dessert;
        let nameA = "";
        let nameB = "";
        let SortData = Object.assign([], this.state.SortingAndSelecting_Orginal_Data);
        console.table(SortData)
        if (this.state.Asscending === false && this.state.Descending === false) {
            Sort_Dessert = SortData.sort((a, b) => {
                nameA = a.name.toLowerCase()
                nameB = b.name.toLowerCase()
                if (nameA < nameB)
                    return -1
                if (nameA > nameB)
                    return 1
                return 0
            });
            this.setState({
                Asscending: true,
                Descending: false,

                Dessert_Ass: true,
                Dessert_Des: false,
                Dessert_Unsort: false,

            })

        }
        else if (this.state.Asscending === true) {
            Sort_Dessert = SortData.sort((a, b) => {
                nameA = a.name.toLowerCase()
                nameB = b.name.toLowerCase()
                if (nameA > nameB)
                    return -1
                if (nameA < nameB)
                    return 1
                return 0
            });
            this.setState({
                Asscending: false,
                Descending: true,
                Dessert_Ass: false,
                Dessert_Des: true,
                Dessert_Unsort: false,
            })
        }
        else {
            Sort_Dessert = SortData
            this.setState({
                Asscending: false,
                Descending: false,
                Dessert_Ass: false,
                Dessert_Des: false,
                Dessert_Unsort: true,
            })
        }
        this.setState({
            SortingAndSelecting_Data: Sort_Dessert,
            Dessert: true,
            Calories: false,
            Fat: false,
            Carbs: false,
            Protein: false,
        })
    }

    Calories = () => {
        let Sort_Calories;
        let SortData = Object.assign([], this.state.SortingAndSelecting_Orginal_Data);
        if (this.state.Asscending === false && this.state.Descending === false) {
            Sort_Calories = SortData.sort((a, b) => (a.calories > b.calories ? 1 : -1));

            this.setState({
                Asscending: true,
                Calories_Unsort: false,
                Calories_Ass: true,
                Calories_Dec: false,
            })
        } else if (this.state.Asscending === true) {
            Sort_Calories = SortData.sort((a, b) => (a.calories > b.calories ? -1 : 1));

            this.setState({
                Asscending: false,
                Descending: true,
                Calories_Unsort: false,
                Calories_Ass: false,
                Calories_Dec: true,
            })
        }
        else {
            Sort_Calories = SortData

            this.setState({
                Asscending: false,
                Descending: false,
                Calories_Unsort: true,
                Calories_Ass: false,
                Calories_Dec: false,
            })
        }

        this.setState({
            SortingAndSelecting_Data: Sort_Calories,
            Dessert: false,
            Calories: true,
            Fat: false,
            Carbs: false,
            Protein: false,
        })
    }

    Fat = () => {
        let Sort_Fat;
        let SortData = Object.assign([], this.state.SortingAndSelecting_Orginal_Data);
        if (this.state.Asscending === false && this.state.Descending === false) {
            Sort_Fat = SortData.sort((a, b) => (a.fat > b.fat ? 1 : -1));

            this.setState({
                Asscending: true,
                Fat_Unsort: false,
                Fat_Ass: true,
                Fat_Dec: false,
            })
        } else if (this.state.Asscending === true) {
            Sort_Fat = SortData.sort((a, b) => (a.fat > b.fat ? -1 : 1));

            this.setState({
                Asscending: false,
                Descending: true,
                Fat_Unsort: false,
                Fat_Ass: false,
                Fat_Dec: true,
            })
        }
        else {
            Sort_Fat = SortData

            this.setState({
                Asscending: false,
                Descending: false,
                Fat_Unsort: true,
                Fat_Ass: false,
                Fat_Dec: false,
            })
        }

        this.setState({
            SortingAndSelecting_Data: Sort_Fat,
            Dessert: false,
            Calories: false,
            Fat: true,
            Carbs: false,
            Protein: false,
        })
    }


    Carbs = () => {
        let Sort_Carbs;
        let SortData = Object.assign([], this.state.SortingAndSelecting_Orginal_Data);
        if (this.state.Asscending === false && this.state.Descending === false) {
            Sort_Carbs = SortData.sort((a, b) => (a.carbs > b.carbs ? 1 : -1));

            this.setState({
                Asscending: true,
                Carbs_Unsort: false,
                Carbs_Ass: true,
                Carbs_Dec: false,
            })
        } else if (this.state.Asscending === true) {
            Sort_Carbs = SortData.sort((a, b) => (a.carbs > b.carbs ? -1 : 1));

            this.setState({
                Asscending: false,
                Descending: true,
                Carbs_Unsort: false,
                Carbs_Ass: false,
                Carbs_Dec: true,
            })
        }
        else {
            Sort_Carbs = SortData

            this.setState({
                Asscending: false,
                Descending: false,
                Carbs_Unsort: true,
                Carbs_Ass: false,
                Carbs_Dec: false,
            })
        }

        this.setState({
            SortingAndSelecting_Data: Sort_Carbs,
            Dessert: false,
            Calories: false,
            Fat: false,
            Carbs: true,
            Protein: false,
        })
    }


    Protein = () => {
        let Sort_Protein;
        let SortData = Object.assign([], this.state.SortingAndSelecting_Orginal_Data);
        if (this.state.Asscending === false && this.state.Descending === false) {
            Sort_Protein = SortData.sort((a, b) => (a.protein > b.protein ? 1 : -1));

            this.setState({
                Asscending: true,
                Protein_Unsort: false,
                Protein_Ass: true,
                Protein_Dec: false,
            })
        } else if (this.state.Asscending === true) {
            Sort_Protein = SortData.sort((a, b) => (a.protein > b.protein ? -1 : 1));

            this.setState({
                Asscending: false,
                Descending: true,
                Protein_Unsort: false,
                Protein_Ass: false,
                Protein_Dec: true,
            })
        }
        else {
            Sort_Protein = SortData

            this.setState({
                Asscending: false,
                Descending: false,
                Protein_Unsort: true,
                Protein_Ass: false,
                Protein_Dec: false,
            })
        }

        this.setState({
            SortingAndSelecting_Data: Sort_Protein,
            Dessert: false,
            Calories: false,
            Fat: false,
            Carbs: false,
            Protein: true,
        })
    }

    handleChecked = (index) => {
        let data = [...this.state.SortingAndSelecting_Data];
        data.map((item, index2) => {
            if (index === index2) {
                item.checked = !item.checked
                // item.deleted = !item.deleted
            }
            return item
        })
        let head_bgcolor = data.filter((item) => {
            return item.checked
        })
        if (head_bgcolor.length > 0) {
            this.setState({
                head_bg_color: true,
                checked_dele: true,
            })
        } else if (head_bgcolor.length === 0) {
            this.setState({
                head_bg_color: false,
                checked_dele: false,
            })
        }
        this.setState({
            SortingAndSelecting_Data: data,
        })
    }

    AllClick = (e) => {
        let data = [...this.state.SortingAndSelecting_Data];
        let Allselected = e.target.checked;
        data = data.map((val) => {
            val.checked = Allselected;
            return val
        })
        let head_bgcolor = data.filter((item) => {
            return item.checked
        })
        if (head_bgcolor.length > 0) {
            this.setState({
                head_bg_color: true,
                checked_dele: true,
            })
        } else if (head_bgcolor.length === 0) {
            this.setState({
                head_bg_color: false,
                checked_dele: false,
            })
        }
        this.setState({
            SortingAndSelecting_Data: data,
        })
    }

    getSelected = () => {
        let data = [...this.state.SortingAndSelecting_Data];
        let totel_selected = data.filter((item) => {
            return item.checked
        })
        if (totel_selected.length === 0) {
            return <h3>Nutrition</h3>

        }
        else if (totel_selected.length === 1) {
            return <p> {totel_selected.length} row selected </p>
        }
        else {
            return <p> {totel_selected.length} rows selected </p>
        }
    }

    SortingAndSelecting_Map = (SliceMethod) => {
        return SliceMethod.map((item, index) => {
            return (
                <tr key={index} className={item.checked ? "tr_bg_color" : ""}>
                    <td className={`${this.state.DensePadding ? "td_padding_of" : "td_padding"}`}>
                        <input type="checkbox" checked={item.checked} onClick={() => this.handleChecked(index)} />
                    </td>
                    <td className={`${this.state.DensePadding ? "td_padding_of" : "td_padding"}`}>{item.name}</td>
                    <td className={`${this.state.DensePadding ? "td_padding_of" : "td_padding"}`}>{item.calories}</td>
                    <td className={`${this.state.DensePadding ? "td_padding_of" : "td_padding"}`}>{item.fat}</td>
                    <td className={`${this.state.DensePadding ? "td_padding_of" : "td_padding"}`}>{item.carbs}</td>
                    <td className={`${this.state.DensePadding ? "td_padding_of" : "td_padding"}`}>{item.protein}</td>
                </tr>
            )

        })
    }

    sliceNext = () => {
        // let start = this.state.sliceEnd === 0 ? 5 : this.state.sliceEnd === 10 ? 10 : 25;
        // let end = this.state.sliceEnd === 5 ? 5 : this.state.sliceEnd === 10 ? 10 : 25;

        if (this.state.SortingAndSelecting_Data.length > this.state.sliceEnd) {
            if (this.state.sliceEnd_5) {
                this.setState({
                    sliceStart: this.state.sliceStart + 5,
                    sliceEnd: this.state.sliceEnd + 5,
                    data_position_start: this.state.data_position_start + 5,
                    data_position_end: true,
                })
            } else if (this.state.sliceEnd_10) {
                this.setState({
                    sliceStart: this.state.sliceStart + 10,
                    sliceEnd: this.state.sliceEnd + 10
                })
            } else if (this.state.sliceEnd_25) {
                this.setState({
                    sliceStart: this.state.sliceStart + 25,
                    sliceEnd: this.state.sliceEnd + 25
                })
            }
        }
    }

    sliceBack = () => {
        if (this.state.sliceEnd === 5 && this.state.sliceEnd_5 === true) {
            this.setState({
                sliceStart: 0,
                sliceEnd: 5
            })
        }
        else if (this.state.sliceEnd_5 === true) {
            this.setState({
                sliceStart: this.state.sliceStart - 5,
                sliceEnd: this.state.sliceEnd - 5,
                data_position_start: this.state.data_position_start - 5,
            })
        }
        else if (this.state.sliceEnd === 10 && this.state.sliceEnd_10 === true) {
            this.setState({
                sliceStart: 0,
                sliceEnd: 10
            })
        }
        else if (this.state.sliceEnd_10 === true) {
            this.setState({
                sliceStart: this.state.sliceStart - 10,
                sliceEnd: this.state.sliceEnd - 10
            })
        }
        else if (this.state.sliceEnd === 25 && this.state.sliceEnd_25 === true) {
            this.setState({
                sliceStart: 0,
                sliceEnd: 25
            })
        }
        else if (this.state.sliceEnd_25 === true) {
            this.setState({
                sliceStart: this.state.sliceStart - 25,
                sliceEnd: this.state.sliceEnd - 25
            })
        }
        else {
            this.setState({
                sliceStart: 0,
                sliceBack: 5,
            })
        }
    }

    isDeleted = () => {
        let data = [...this.state.SortingAndSelecting_Data];
        let totel_selected = data.filter((item) => {
            return !item.checked
        })
        this.setState({
            SortingAndSelecting_Data: totel_selected,
            head_bg_color: false,
            checked_dele: false,
        })
    }

    render() {
        let SliceMethod = this.state.SortingAndSelecting_Data.slice(this.state.sliceStart, this.state.sliceEnd);
        console.table(this.state.SortingAndSelecting_Data);
        return (
            <React.Fragment>
                <h1>Sorting and selecting</h1>
                <div className="SortingAndSelecting_wrapper" >
                    <div className="SortingAndSelecting">
                        <div className="SortingAndSelecting_container">
                            <div className={`SortingAndSelecting_heading ${this.state.head_bg_color ? "head_bg_color" : ""}`}>
                                <div>
                                    {this.getSelected()}
                                </div>
                                <div title="filter">
                                    {
                                        this.state.checked_dele ?
                                            <i class="fas fa-trash" onClick={() => this.isDeleted()} ></i>
                                            :
                                            <i className="fas fa-filter"></i>
                                    }
                                </div>
                            </div>
                            <div className={`table_container 
                                         ${SliceMethod.length < 5 ? "sliceEnd_5"
                                        : SliceMethod.length === 10 ? "sliceEnd_10"
                                        : SliceMethod.length === 25 ? "sliceEnd_25" : ""
                                        //   : this.state.SortingAndSelecting_Data .length < 
                                        //     this.state.sliceEnd_5 ? "sliceEnd_5" :
                                        //     this.state.sliceEnd_10 ? "sliceEnd_10" :
                                        //     this.state.sliceEnd_25 ? "sliceEnd_25" : " "
                                } `}>
                                <table>
                                    <thead>
                                        <tr>
                                            <th className={`${this.state.DensePadding ? "th_padding_of" : "th_padding"}`}>
                                                <input type="checkbox" onClick={(e) => this.AllClick(e)} />
                                            </th>
                                            <th className={`${this.state.DensePadding ? "th_padding_of" : "th_padding"}`}>
                                                <div>
                                                    <div onClick={() => this.Dessert()}>Dessert (100g serving)</div>
                                                    <div>
                                                        <i className={`fas fa-arrow-up Dessert
                                                        ${this.state.Dessert_Ass && this.state.Dessert ? "Dark" : this.state.Dessert_Des && this.state.Dessert ? "rodate" : "Grey"} 
                                                       `} onClick={() => this.Dessert()}>
                                                        </i>
                                                    </div>
                                                </div>
                                            </th>
                                            <th className={`${this.state.DensePadding ? "th_padding_of" : "th_padding"}`}>
                                                <div>
                                                    <div><i className={`fas fa-arrow-up ${this.state.Calories_Ass && this.state.Calories ? "Dark" : this.state.Calories_Dec && this.state.Calories ? "rodate" : "Grey"} 
                                                       `} onClick={() => this.Calories()}></i></div>
                                                    <div>Calories</div>
                                                </div>
                                            </th>
                                            <th className={`${this.state.DensePadding ? "th_padding_of" : "th_padding"}`}>
                                                <div>
                                                    <div><i className={`fas fa-arrow-up ${this.state.Fat_Ass && this.state.Fat ? "Dark" : this.state.Fat_Dec && this.state.Fat ? "rodate" : "Grey"} 
                                                       `} onClick={() => this.Fat()}></i></div>
                                                    <div>Fat (g)</div>
                                                </div>
                                            </th>
                                            <th className={`${this.state.DensePadding ? "th_padding_of" : "th_padding"}`}>
                                                <div>
                                                    <div><i className={`fas fa-arrow-up ${this.state.Carbs_Ass && this.state.Carbs ? "Dark" : this.state.Carbs_Dec && this.state.Carbs ? "rodate" : "Grey"} 
                                                       `} onClick={() => this.Carbs()}></i></div>
                                                    <div>Carbs (g)</div>
                                                </div>
                                            </th>
                                            <th className={`${this.state.DensePadding ? "th_padding_of" : "th_padding"}`}>
                                                <div>
                                                    <div><i className={`fas fa-arrow-up ${this.state.Protein_Ass && this.state.Protein ? "Dark" : this.state.Protein_Dec && this.state.Protein ? "rodate" : "Grey"} 
                                                       `} onClick={() => this.Protein()}></i></div>
                                                    <div>Protein (g)</div>
                                                </div>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {this.SortingAndSelecting_Map(SliceMethod)}
                                    </tbody>
                                    <tfoot> </tfoot>
                                </table>
                            </div>
                            <div className="SortingAndSelecting_footer">
                                <div className="rows_per_page">
                                    <div className="per_page">
                                        <h3>Rows per page :</h3>
                                    </div>
                                    <div className="sort_page">
                                        <div>
                                            <h3 onClick={() => { this.setState({ isOpen: !this.state.isOpen }) }}>{this.state.sliceEnd_5 ? "5" : this.state.sliceEnd_10 ? "10" : this.state.sliceEnd_25 ? "25" : ""} <i class={`${this.state.isOpen ? "fas fa-angle-up" : "fas fa-angle-down"}`}></i> </h3>
                                            <span className={`${this.state.isOpen ? "span_open" : "span_close"}`}>
                                                <h3 className={`${this.state.isOpen ? "span_open" : "span_close"}`}
                                                    onClick={() => {
                                                        this.setState({
                                                            sliceStart: 0, sliceEnd: 5, isOpen: false,
                                                            sliceEnd_5: true, sliceEnd_10: false, sliceEnd_25: false
                                                        })
                                                    }}>
                                                    5
                                                </h3>
                                                <h3 className={`${this.state.isOpen ? "span_open" : "span_close"}`}
                                                    onClick={() => {
                                                        this.setState({
                                                            sliceStart: 0, sliceEnd: 10, isOpen: false,
                                                            sliceEnd_10: true, sliceEnd_5: false, sliceEnd_25: false
                                                        })
                                                    }}>10</h3>
                                                <h3 className={`${this.state.isOpen ? "span_open" : "span_close"}`}
                                                    onClick={() => {
                                                        this.setState({
                                                            sliceStart: 0, sliceEnd: 25, isOpen: false,
                                                            sliceEnd_25: true, sliceEnd_10: false, sliceEnd_5: false
                                                        })
                                                    }}>25</h3>
                                            </span>
                                        </div>
                                    </div>
                                    <div className="totel_length">
                                        <h3>{this.state.SortingAndSelecting_Data.length > 0 ? this.state.data_position_start : "0"}
                                            -
                                            {this.state.data_position_end ? this.state.sliceEnd - 5 + SliceMethod.length : SliceMethod.length}
                                            of
                                            {this.state.SortingAndSelecting_Data.length}</h3>
                                    </div>
                                    <div className="pages">
                                        <div className="icons_left" onClick={() => this.sliceBack()}>
                                            <i className={`fas fa-angle-left ${this.state.sliceEnd === 5 || this.state.sliceStart < 5 ? "grey" : ""}`} ></i></div>
                                        <div className="icons_right" onClick={() => this.sliceNext()}>
                                            <i className={`fas fa-angle-right ${this.state.SortingAndSelecting_Data.length > this.state.sliceEnd ? "" : "grey"}`}></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="Dense_padding">
                            <div className="Dense_padding_icons"
                                onClick={() => { this.setState({ DensePadding: !this.state.DensePadding }) }}>
                                <i className={`fas fa-toggle-${this.state.DensePadding ? "on" : "off"}`}></i>
                            </div >
                            <div className="Dense_padding_icons">
                                <h3 onClick={() => { this.setState({ DensePadding: !this.state.DensePadding }) }}>
                                    Densepadding
                                </h3>
                            </div>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}
export default SortingAndSelecting;

