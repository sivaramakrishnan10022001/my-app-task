import React from "react";
import "./DataTable.css";

class DataTable extends React.Component {
    constructor(props) {
        super(props);
        this.state = {

            DataTableData: [
                {
                    id: 1, firstname: "sivarama", lastname: "krishnan", age: 22, fullname: "sivaramakrishnan"
                },
                {
                    id: 2, firstname: "vel", lastname: "murugan", age: 27, fullname: "Velmurugan"
                },
                {
                    id: 3, firstname: "anbu", lastname: "raj", age: 11, fullname: "anbu raj"
                },
                {
                    id: 4, firstname: "sasi", lastname: "kumar", age: 19, fullname: "raj kumar"
                },
                {
                    id: 5, firstname: "raja", lastname: "pandi", age: 34, fullname: "raja pandi"
                },
                {
                    id: 6, firstname: "mani", lastname: 'kandan', age: 42, fullname: "manikandan"
                },
                {
                    id: 7, firstname: 'Ferrara', lastname: 'Clifford', age: 44, fullname: "Clifford Ferrara"
                },
                {
                    id: 8, firstname: 'Rossini', lastname: 'Frances', age: 36, fullname: "Frances Rossini"
                },
                {
                    id: 9, firstname: 'Harvey', lastname: 'Roxie', age: 65, fullname: "Roxie Harvey"
                },
                {
                    id: 10, firstname: "John", lastname: "Smith", age: 22, fullname: "John Smith"
                },
                {
                    id: 11, firstname: "Ted", lastname: "Masters", age: 27, fullname: "Ted Masters"
                },
                {
                    id: 12, firstname: "Fran", lastname: "Jones", age: 11, fullname: "Fran Jones"
                },
                {
                    id: 13, firstname: "Tallulah", lastname: "Smith", age: 19, fullname: "Tallulah Smith"
                },
                {
                    id: 14, firstname: "Vimal", lastname: "Kashiyani", age: 34, fullname: "Vimal Kashiyani"
                },
                {
                    id: 15, firstname: "Hardik", lastname: 'Savani', age: 100, fullname: "Hardik Savani"
                },
                {
                    id: 16, firstname: 'Harshad', lastname: 'Pathak', age: 32, fullname: "Harshad Pathak"
                },
                {
                    id: 17, firstname: 'Harsukh', lastname: 'Makawana', age: 65, fullname: "Harsukh Makawana"
                },
                {
                    id: 18, firstname: 'muthu', lastname: 'vel', age: 27, fullname: "Muthuvel"
                },
                {
                    id: 19, firstname: 'sv', lastname: 'vel', age: 27, fullname: "Muthuvel"
                },

            ],
            DataStore: [],
            newDataStore: [],
            newDataStore_true: false,
            onClickAnimation: false,
            mousehover_idShowContainer: false,
            mouseleave_idShowContainer: true,
            mousehover_firstnameShowContainer: false,
            mouseleave_firstnameShowContainer: true,
            mousehover_lastnameShowContainer: false,
            mouseleave_lastnameShowContainer: true,
            mousehover_ageShowContainer: false,
            mouseleave_ageShowContainer: true,
            mousehover_fullnameShowContainer: false,
            mouseleave_fullnameShowContainer: true,
            idHoverIcon: 0,
            firstnameHoverIcon: 0,
            lastnameHoverIcon: 0,
            ageHoverIcon: 0,
            fullnameHoverIcon: 0,
            id_unsort: true,
            firstname_unsort: true,
            // firstname_ascending: false,
            // firstname_descending: false,

            lastname_unsort: true,
            age_unsort: true,
            fullname_unsort: true,
            start: 0,
            end: 5,
            Count: 1,
            idHideClick: false,
            firstnameHideClick: false,
            lastnameHideClick: false,
            ageHideClick: false,
            fullnameHideClick: false,
            sortbyASC: false,
            sortbyDSC: false,
            Columns: "",
            Operators: "",
            inputValue: "",
            FILTER_TRUE: false,
            filterSearch: [],
            inputValues: "",
            filteredSearch: [],
            SliceMethod_length_Count: false,
        }
    }

    // ===================== componentDidMount ======================

    componentDidMount() {
        this.setState({
            DataStore: this.state.DataTableData,
            filterSearch: [
                { label: "Checkbox selection" },
                { label: "ID" },
                { label: "First name" },
                { label: "Last name" },
                { label: "Age" },
                { label: " Full name" },
            ],
        })
    }

    // ====================== id unsort , id ascending , id descending =========================

    idClick = () => {
        let sortedData;
        let dataList = Object.assign([], this.state.newDataStore_true ? this.state.newDataStore : this.state.DataTableData);
        if (this.state.sortbyASC === false && this.state.sortbyDSC === false) {

            sortedData = dataList.sort((a, b) => a.id > b.id ? 1 : -1)
            this.setState({
                sortbyDSC: false,
                sortbyASC: true,
                id_descending: false,
                id_ascending: true,
                id_unsort: false,
            })
            this.idLeaveIcon = () => {
                this.setState({
                    idHoverIcon: 1,
                    firstnameHoverIcon: 0,
                    lastnameHoverIcon: 0,
                    ageHoverIcon: 0,
                    fullnameHoverIcon: 0,
                })
            }
        }
        else if (this.state.sortbyASC === true) {
            sortedData = dataList.sort((a, b) => a.id > b.id ? -1 : 1)
            this.setState({
                sortbyASC: false,
                sortbyDSC: true,
                id_descending: true,
                id_unsort: false,
                id_ascending: false,
            })
            this.idLeaveIcon = () => {
                this.setState({
                    idHoverIcon: 1,
                    firstnameHoverIcon: 0,
                    lastnameHoverIcon: 0,
                    ageHoverIcon: 0,
                    fullnameHoverIcon: 0,
                })
            }
        }
        else {
            sortedData = dataList
            this.setState({
                sortbyDSC: false,
                sortbyASC: false,
                id_unsort: true,
                id_descending: false,
                id_ascending: false
            })
            this.idLeaveIcon = () => {
                this.setState({
                    idHoverIcon: 0,
                    firstnameHoverIcon: 0,
                    lastnameHoverIcon: 0,
                    ageHoverIcon: 0,
                    fullnameHoverIcon: 0,
                })
            }
        }
        this.firstnameUNSORT();
        this.lastnameUNSORT();
        this.ageUNSORT();
        this.fullnameUNSORT();

        if (this.state.newDataStore_true === true) {
            this.setState({
                newDataStore: sortedData,
            })
        }
        else {
            this.setState({
                DataStore: sortedData,
            })
        }
    }

    // =================== id unsort ====================

    idUNSORT = () => {
        let dataList = Object.assign([], this.state.newDataStore_true ? this.state.newDataStore : this.state.DataTableData);
        this.idLeaveIcon = () => {
            this.setState({
                idHoverIcon: 0,
                firstnameHoverIcon: 0,
                lastnameHoverIcon: 0,
                ageHoverIcon: 0,
                fullnameHoverIcon: 0,
            })
        }
        if (this.state.newDataStore_true) {
            this.setState({
                newDataStore: dataList,
                id_unsort: true,
                id_descending: false,
                id_ascending: false
            })
        }
        else {
            this.setState({
                DataStore: dataList,
                id_unsort: true,
                id_descending: false,
                id_ascending: false
            })
        }
    }

    // ===================== id ascending ================

    idASC = () => {
        let sortedData;
        let dataList = Object.assign([], this.state.newDataStore_true ? this.state.newDataStore : this.state.DataTableData);
        sortedData = dataList.sort((a, b) => a.id > b.id ? 1 : -1)
        this.idLeaveIcon = () => {
            this.setState({
                idHoverIcon: 1,
                firstnameHoverIcon: 0,
                lastnameHoverIcon: 0,
                ageHoverIcon: 0,
                fullnameHoverIcon: 0,
            })
        }
        this.firstnameUNSORT();
        this.lastnameUNSORT();
        this.ageUNSORT();
        this.fullnameUNSORT();

        if (this.state.newDataStore_true) {
            this.setState({
                newDataStore: sortedData,
                id_descending: false,
                id_unsort: false,
                id_ascending: true,
            })
        }
        else {
            this.setState({
                DataStore: sortedData,
                id_descending: false,
                id_unsort: false,
                id_ascending: true,
            })
        }
    }

    // ==================== id descending =================

    idDSC = () => {
        let sortedData;
        let dataList = Object.assign([], this.state.newDataStore_true ? this.state.newDataStore : this.state.DataTableData);
        sortedData = dataList.sort((a, b) => a.id > b.id ? -1 : 1)
        if (this.state.newDataStore_true) {
            this.setState({
                newDataStore: sortedData,
                id_descending: true,
                id_unsort: false,
                id_ascending: false
            })
        }
        this.setState({
            DataStore: sortedData,
            id_descending: true,
            id_unsort: false,
            id_ascending: false
        })
        this.idLeaveIcon = () => {
            this.setState({
                idHoverIcon: 1,
                firstnameHoverIcon: 0,
                lastnameHoverIcon: 0,
                ageHoverIcon: 0,
                fullnameHoverIcon: 0,
            })
        }
        this.firstnameUNSORT();
        this.lastnameUNSORT();
        this.ageUNSORT();
        this.fullnameUNSORT();
    }

    // =================== firstname unsort , firstname ascending , firstname descending =====================

    firstnameClick = () => {
        let sortedData;
        let nameA = ""
        let nameB = ""
        let dataList = Object.assign([], this.state.newDataStore_true === true ? this.state.newDataStore : this.state.DataTableData);
        if (this.state.sortbyASC === false && this.state.sortbyDSC === false) {
            sortedData = dataList.sort((a, b) => {
                nameA = a.firstname.toLowerCase()
                nameB = b.firstname.toLowerCase()
                if (nameA < nameB)
                    return -1
                if (nameA > nameB)
                    return 1
                return 0
            })

            this.setState({
                sortbyDSC: false,
                sortbyASC: true,
                firstname_unsort: false,
                firstname_ascending: true,
                firstname_descending: false
            })
            this.firstnameLeaveIcon = () => {
                this.setState({
                    idHoverIcon: 0,
                    firstnameHoverIcon: 1,
                    lastnameHoverIcon: 0,
                    ageHoverIcon: 0,
                    fullnameHoverIcon: 0,
                })
            }
        }
        else if (this.state.sortbyASC === true) {
            sortedData = dataList.sort((a, b) => {
                nameA = a.firstname.toLowerCase()
                nameB = b.firstname.toLowerCase()
                if (nameA > nameB)
                    return -1
                if (nameA < nameB)
                    return 1
                return 0
            })
            this.setState({
                sortbyDSC: true,
                sortbyASC: false,
                firstname_unsort: false,
                firstname_ascending: false,
                firstname_descending: true
            })
            this.firstnameLeaveIcon = () => {
                this.setState({
                    idHoverIcon: 0,
                    firstnameHoverIcon: 1,
                    lastnameHoverIcon: 0,
                    ageHoverIcon: 0,
                    fullnameHoverIcon: 0,
                })
            }
        }
        else {
            sortedData = dataList
            this.setState({
                sortbyDSC: false,
                sortbyASC: false,
                firstname_unsort: true,
                firstname_ascending: false,
                firstname_descending: false
            })
            this.firstnameLeaveIcon = () => {
                this.setState({
                    idHoverIcon: 0,
                    firstnameHoverIcon: 0,
                    lastnameHoverIcon: 0,
                    ageHoverIcon: 0,
                    fullnameHoverIcon: 0,
                })
            }
        }
        this.idUNSORT();
        this.lastnameUNSORT();
        this.ageUNSORT();
        this.fullnameUNSORT();

        if (this.state.newDataStore_true === true) {
            this.setState({
                newDataStore: sortedData,
            })
        }
        else {
            this.setState({
                DataStore: sortedData,
            })
        }
        console.log("bad", this.state.DataStore)
    }

    // ================== firstname unsort ===================

    firstnameUNSORT = () => {
        let dataList = Object.assign([], this.state.newDataStore_true ? this.state.newDataStore : this.state.DataTableData);
        this.firstnameLeaveIcon = () => {
            this.setState({
                idHoverIcon: 0,
                firstnameHoverIcon: 0,
                lastnameHoverIcon: 0,
                ageHoverIcon: 0,
                fullnameHoverIcon: 0,
            })
        }

        if (this.state.newDataStore_true) {
            this.setState({
                newDataStore: dataList,
                firstname_unsort: true,
                firstname_ascending: false,
                firstname_descending: false
            })
        }
        else {
            this.setState({
                DataStore: dataList,
                firstname_unsort: true,
                firstname_ascending: false,
                firstname_descending: false
            })
        }
    }

    // ================= firstname ascending ==================

    firstnameASC = () => {
        let sortedData;
        let nameA = ""
        let nameB = ""
        let dataList = Object.assign([], this.state.newDataStore_true ? this.state.newDataStore : this.state.DataTableData);
        sortedData = dataList.sort((a, b) => {
            nameA = a.firstname.toLowerCase()
            nameB = b.firstname.toLowerCase()
            if (nameA < nameB)
                return -1
            if (nameA > nameB)
                return 1
            return 0
        })
        this.firstnameLeaveIcon = () => {
            this.setState({
                idHoverIcon: 0,
                firstnameHoverIcon: 1,
                lastnameHoverIcon: 0,
                ageHoverIcon: 0,
                fullnameHoverIcon: 0,
            })
        }
        this.idUNSORT();
        this.lastnameUNSORT();
        this.ageUNSORT();
        this.fullnameUNSORT();

        if (this.state.newDataStore_true === true) {
            this.setState({
                newDataStore: sortedData,
                firstname_unsort: false,
                firstname_ascending: true,
                firstname_descending: false
            })
        }
        else {
            this.setState({
                DataStore: sortedData,
                firstname_unsort: false,
                firstname_ascending: true,
                firstname_descending: false
            })
        }


    }

    // ================= firstname descending ===================

    firstnameDSC = () => {
        let sortedData;
        let nameA = ""
        let nameB = ""
        let dataList = Object.assign([], this.state.newDataStore_true ? this.state.newDataStore : this.state.DataTableData);
        sortedData = dataList.sort((a, b) => {
            nameA = a.firstname.toLowerCase()
            nameB = b.firstname.toLowerCase()
            if (nameA > nameB)
                return -1
            if (nameA < nameB)
                return 1
            return 0
        })
        this.firstnameLeaveIcon = () => {
            this.setState({
                idHoverIcon: 0,
                firstnameHoverIcon: 1,
                lastnameHoverIcon: 0,
                ageHoverIcon: 0,
                fullnameHoverIcon: 0,
            })
        }
        this.idUNSORT();
        this.lastnameUNSORT();
        this.ageUNSORT();
        this.fullnameUNSORT();

        if (this.state.newDataStore_true === true) {
            this.setState({
                newDataStore: sortedData,
                firstname_unsort: false,
                firstname_ascending: false,
                firstname_descending: true
            })
        }
        else {
            this.setState({
                DataStore: sortedData,
                firstname_unsort: false,
                firstname_ascending: false,
                firstname_descending: true
            })
        }
    }

    // =================== lastname unsort , lastname ascending , lastname descending =====================

    lastnameClick = () => {
        let sortedData;
        let nameA = ""
        let nameB = ""
        let dataList = Object.assign([], this.state.newDataStore_true ? this.state.newDataStore : this.state.DataTableData);
        if (this.state.sortbyASC === false && this.state.sortbyDSC === false) {
            sortedData = dataList.sort((a, b) => {
                nameA = a.lastname.toLowerCase()
                nameB = b.lastname.toLowerCase()
                if (nameA < nameB)
                    return -1
                if (nameA > nameB)
                    return 1
                return 0
            })
            this.setState({
                sortbyASC: true,
                sortbyDSC: false,
                lastname_unsort: false,
                lastname_ascending: true,
                lastname_descending: false
            })
            this.lastnameLeaveIcon = () => {
                this.setState({
                    idHoverIcon: 0,
                    firstnameHoverIcon: 0,
                    lastnameHoverIcon: 1,
                    ageHoverIcon: 0,
                    fullnameHoverIcon: 0,
                })
            }
        }
        else if (this.state.sortbyASC === true) {
            sortedData = dataList.sort((a, b) => {
                nameA = a.lastname.toLowerCase()
                nameB = b.lastname.toLowerCase()
                if (nameA > nameB)
                    return -1
                if (nameA < nameB)
                    return 1
                return 0
            })
            this.setState({
                sortbyDSC: true,
                sortbyASC: false,
                lastname_unsort: false,
                lastname_ascending: false,
                lastname_descending: true
            })
            this.lastnameLeaveIcon = () => {
                this.setState({
                    idHoverIcon: 0,
                    firstnameHoverIcon: 0,
                    lastnameHoverIcon: 1,
                    ageHoverIcon: 0,
                    fullnameHoverIcon: 0,
                })
            }
        }
        else {
            sortedData = dataList
            this.setState({
                sortbyDSC: false,
                sortbyASC: false,
                lastname_unsort: true,
                lastname_ascending: false,
                lastname_descending: false
            })
            this.lastnameLeaveIcon = () => {
                this.setState({
                    idHoverIcon: 0,
                    firstnameHoverIcon: 0,
                    lastnameHoverIcon: 0,
                    ageHoverIcon: 0,
                    fullnameHoverIcon: 0,
                })
            }
        }
        this.idUNSORT();
        this.firstnameUNSORT();
        this.ageUNSORT();
        this.fullnameUNSORT();
        if (this.state.newDataStore_true) {
            this.setState({
                newDataStore: sortedData,
            })
        }
        else {
            this.setState({
                DataStore: sortedData,
            })
        }
    }

    // ========================= lastname unsort =============================    

    lastnameUNSORT = () => {
        let dataList = Object.assign([], this.state.newDataStore_true ? this.state.newDataStore : this.state.DataTableData);
        this.lastnameLeaveIcon = () => {
            this.setState({
                idHoverIcon: 0,
                firstnameHoverIcon: 0,
                lastnameHoverIcon: 0,
                ageHoverIcon: 0,
                fullnameHoverIcon: 0,
            })
        }
        if (this.state.newDataStore_true) {
            this.setState({
                newDataStore: dataList,
                lastname_unsort: true,
                lastname_ascending: false,
                lastname_descending: false
            })
        }
        else {
            this.setState({
                DataStore: dataList,
                lastname_unsort: true,
                lastname_ascending: false,
                lastname_descending: false
            })
        }
    }

    // ========================= lastname ascending =============================

    lastnameASC = () => {
        let sortedData;
        let nameA = ""
        let nameB = ""
        let dataList = Object.assign([], this.state.newDataStore_true ? this.state.newDataStore : this.state.DataTableData);
        sortedData = dataList.sort((a, b) => {
            nameA = a.lastname.toLowerCase()
            nameB = b.lastname.toLowerCase()
            if (nameA < nameB)
                return -1
            if (nameA > nameB)
                return 1
            return 0
        })
        this.lastnameLeaveIcon = () => {
            this.setState({
                idHoverIcon: 0,
                firstnameHoverIcon: 0,
                lastnameHoverIcon: 1,
                ageHoverIcon: 0,
                fullnameHoverIcon: 0,
            })
        }
        this.idUNSORT();
        this.firstnameUNSORT();
        this.ageUNSORT();
        this.fullnameUNSORT();
        if (this.state.newDataStore_true) {
            this.setState({
                newDataStore: sortedData,
                lastname_unsort: false,
                lastname_ascending: true,
                lastname_descending: false
            })
        }
        else {
            this.setState({
                DataStore: sortedData,
                lastname_unsort: false,
                lastname_ascending: true,
                lastname_descending: false
            })
        }
    }

    // ========================= lastname descending =============================

    lastnameDSC = () => {
        let sortedData;
        let nameA = ""
        let nameB = ""
        let dataList = Object.assign([], this.state.newDataStore_true ? this.state.newDataStore : this.state.DataTableData);
        sortedData = dataList.sort((a, b) => {
            nameA = a.lastname.toLowerCase()
            nameB = b.lastname.toLowerCase()
            if (nameA > nameB)
                return -1
            if (nameA < nameB)
                return 1
            return 0
        })
        this.lastnameLeaveIcon = () => {
            this.setState({
                idHoverIcon: 0,
                firstnameHoverIcon: 0,
                lastnameHoverIcon: 1,
                ageHoverIcon: 0,
                fullnameHoverIcon: 0,
            })
        }
        this.idUNSORT();
        this.firstnameUNSORT();
        this.ageUNSORT();
        this.fullnameUNSORT();

        if (this.state.newDataStore_true) {
            this.setState({
                newDataStore: sortedData,
                lastname_unsort: false,
                lastname_ascending: false,
                lastname_descending: true
            })
        }
        else {
            this.setState({
                DataStore: sortedData,
                lastname_unsort: false,
                lastname_ascending: false,
                lastname_descending: true
            })
        }
    }

    // =================== age unsort , age ascending , age descending =====================

    ageClick = () => {
        let sortedData;
        let dataList = Object.assign([], this.state.newDataStore_true ? this.state.newDataStore : this.state.DataTableData);
        if (this.state.sortbyASC === false && this.state.sortbyDSC === false) {
            sortedData = dataList.sort((a, b) => a.age > b.age ? 1 : -1)
            this.setState({
                sortbyASC: true,
                age_unsort: false,
                age_ascending: true,
                age_descending: false
            })
            this.ageLeaveIcon = () => {
                this.setState({
                    idHoverIcon: 0,
                    firstnameHoverIcon: 0,
                    lastnameHoverIcon: 0,
                    ageHoverIcon: 1,
                    fullnameHoverIcon: 0,
                })
            }
        }
        else if (this.state.sortbyASC === true) {
            sortedData = dataList.sort((a, b) => a.age > b.age ? -1 : 1)
            this.setState({
                sortbyDSC: true,
                sortbyASC: false,
                age_unsort: false,
                age_ascending: false,
                age_descending: true
            })
            this.ageLeaveIcon = () => {
                this.setState({
                    idHoverIcon: 0,
                    firstnameHoverIcon: 0,
                    lastnameHoverIcon: 0,
                    ageHoverIcon: 1,
                    fullnameHoverIcon: 0,
                })
            }
        }
        else {
            sortedData = dataList
            this.setState({
                sortbyDSC: false,
                sortbyASC: false,
                age_unsort: true,
                age_ascending: false,
                age_descending: false
            })
            this.ageLeaveIcon = () => {
                this.setState({
                    idHoverIcon: 0,
                    firstnameHoverIcon: 0,
                    lastnameHoverIcon: 0,
                    ageHoverIcon: 0,
                    fullnameHoverIcon: 0,
                })
            }
        }
        this.idUNSORT();
        this.firstnameUNSORT();
        this.lastnameUNSORT();
        this.fullnameUNSORT();
        if (this.state.newDataStore_true) {
            this.setState({
                newDataStore: sortedData,
            })
        }
        else {
            this.setState({
                DataStore: sortedData
            })
        }

    }

    // ========================= age unsort =============================

    ageUNSORT = () => {
        let dataList = Object.assign([], this.state.newDataStore_true ? this.state.newDataStore : this.state.DataTableData);
        this.ageLeaveIcon = () => {
            this.setState({
                idHoverIcon: 0,
                firstnameHoverIcon: 0,
                lastnameHoverIcon: 0,
                ageHoverIcon: 0,
                fullnameHoverIcon: 0,
            })
        }

        if (this.state.newDataStore_true) {
            this.setState({
                newDataStore: dataList,
                age_unsort: true,
                age_ascending: false,
                age_descending: false
            })
        }
        else {
            this.setState({
                DataStore: dataList,
                age_unsort: true,
                age_ascending: false,
                age_descending: false
            })
        }
    }

    // ========================= age ascending =============================

    ageASC = () => {
        let sortedData;
        let dataList = Object.assign([], this.state.newDataStore_true ? this.state.newDataStore : this.state.DataTableData);
        sortedData = dataList.sort((a, b) => a.age > b.age ? 1 : -1)
        this.ageLeaveIcon = () => {
            this.setState({
                idHoverIcon: 0,
                firstnameHoverIcon: 0,
                lastnameHoverIcon: 0,
                ageHoverIcon: 1,
                fullnameHoverIcon: 0,
            })
        }
        this.idUNSORT();
        this.firstnameUNSORT();
        this.lastnameUNSORT();
        this.fullnameUNSORT();

        if (this.state.newDataStore_true) {
            this.setState({
                newDataStore: sortedData,
                age_unsort: false,
                age_ascending: true,
                age_descending: false
            })
        }
        else {
            this.setState({
                DataStore: sortedData,
                age_unsort: false,
                age_ascending: true,
                age_descending: false
            })
        }
    }

    // ========================= age descending =============================

    ageDSC = () => {
        let sortedData;
        let dataList = Object.assign([], this.state.newDataStore_true ? this.state.newDataStore : this.state.DataTableData);
        sortedData = dataList.sort((a, b) => a.age > b.age ? -1 : 1)
        this.ageLeaveIcon = () => {
            this.setState({
                idHoverIcon: 0,
                firstnameHoverIcon: 0,
                lastnameHoverIcon: 0,
                ageHoverIcon: 1,
                fullnameHoverIcon: 0,
            })
        }
        this.idUNSORT();
        this.firstnameUNSORT();
        this.lastnameUNSORT();
        this.fullnameUNSORT();

        if (this.state.newDataStore_true) {
            this.setState({
                newDataStore: sortedData,
                age_unsort: false,
                age_ascending: false,
                age_descending: true
            })
        }
        else {
            this.setState({
                DataStore: sortedData,
                age_unsort: false,
                age_ascending: false,
                age_descending: true
            })
        }
    }

    // =================== fullname unsort , fullname ascending , fullname descending =====================

    fullnameClick = () => {
        let sortedData;
        let nameA = ""
        let nameB = ""
        let dataList = Object.assign([], this.state.newDataStore_true ? this.state.newDataStore : this.state.DataTableData);

        if (this.state.sortbyASC === false && this.state.sortbyDSC === false) {
            sortedData = dataList.sort((a, b) => {
                nameA = a.fullname.toLowerCase()
                nameB = b.fullname.toLowerCase()
                if (nameA < nameB)
                    return -1
                if (nameA > nameB)
                    return 1
                return 0
            })
            this.setState({
                sortbyASC: true,
                fullname_unsort: false,
                fullname_ascending: true,
                fullname_descending: false
            })
            this.fullnameLeaveIcon = () => {
                this.setState({
                    idHoverIcon: 0,
                    firstnameHoverIcon: 0,
                    lastnameHoverIcon: 0,
                    ageHoverIcon: 0,
                    fullnameHoverIcon: 1,
                })
            }
        }
        else if (this.state.sortbyASC === true) {
            sortedData = dataList.sort((a, b) => {
                nameA = a.fullname.toLowerCase()
                nameB = b.fullname.toLowerCase()
                if (nameA > nameB)
                    return -1
                if (nameA < nameB)
                    return 1
                return 0
            })
            this.setState({
                sortbyDSC: true,
                sortbyASC: false,
                fullname_unsort: false,
                fullname_ascending: false,
                fullname_descending: true
            })
            this.fullnameLeaveIcon = () => {
                this.setState({
                    idHoverIcon: 0,
                    firstnameHoverIcon: 0,
                    lastnameHoverIcon: 0,
                    ageHoverIcon: 0,
                    fullnameHoverIcon: 1,
                })
            }
        }
        else {
            sortedData = dataList
            this.setState({
                sortbyDSC: false,
                sortbyASC: false,
                fullname_unsort: true,
                fullname_ascending: false,
                fullname_descending: false
            })
            this.fullnameLeaveIcon = () => {
                this.setState({
                    idHoverIcon: 0,
                    firstnameHoverIcon: 0,
                    lastnameHoverIcon: 0,
                    ageHoverIcon: 0,
                    fullnameHoverIcon: 0,
                })
            }
        }
        this.idUNSORT();
        this.firstnameUNSORT();
        this.lastnameUNSORT();
        this.ageUNSORT();

        if (this.state.newDataStore_true) {
            this.setState({
                newDataStore: sortedData,
            })
        }
        else {
            this.setState({
                DataStore: sortedData,
            })
        }
    }

    // =========================  fullname unsort =============================

    fullnameUNSORT = () => {
        let dataList = Object.assign([], this.state.newDataStore_true ? this.state.newDataStore : this.state.DataTableData);
        this.fullnameLeaveIcon = () => {
            this.setState({
                idHoverIcon: 0,
                firstnameHoverIcon: 0,
                lastnameHoverIcon: 0,
                ageHoverIcon: 0,
                fullnameHoverIcon: 0,
            })
        }

        if (this.state.newDataStore_true) {
            this.setState({
                newDataStore: dataList,
                fullname_unsort: true,
                fullname_ascending: false,
                fullname_descending: false
            })
        }
        else {
            this.setState({
                DataStore: dataList,
                fullname_unsort: true,
                fullname_ascending: false,
                fullname_descending: false
            })
        }
    }

    // ========================= fullname ascending  =============================

    fullnameASC = () => {
        let sortedData;
        let nameA = ""
        let nameB = ""
        let dataList = Object.assign([], this.state.newDataStore_true ? this.state.newDataStore : this.state.DataTableData);
        sortedData = dataList.sort((a, b) => {
            nameA = a.fullname.toLowerCase()
            nameB = b.fullname.toLowerCase()
            if (nameA < nameB)
                return -1
            if (nameA > nameB)
                return 1
            return 0
        })
        this.fullnameLeaveIcon = () => {
            this.setState({
                idHoverIcon: 0,
                firstnameHoverIcon: 0,
                lastnameHoverIcon: 0,
                ageHoverIcon: 0,
                fullnameHoverIcon: 1,
            })
        }
        this.idUNSORT();
        this.firstnameUNSORT();
        this.lastnameUNSORT();
        this.ageUNSORT();

        if (this.state.newDataStore_true) {
            this.setState({
                newDataStore: sortedData,
                fullname_unsort: false,
                fullname_ascending: true,
                fullname_descending: false
            })
        }
        else {
            this.setState({
                DataStore: sortedData,
                fullname_unsort: false,
                fullname_ascending: true,
                fullname_descending: false
            })
        }
    }

    // ========================= fullname descending =============================

    fullnameDSC = () => {
        let sortedData;
        let nameA = ""
        let nameB = ""
        let dataList = Object.assign([], this.state.newDataStore_true ? this.state.newDataStore : this.state.DataTableData);
        sortedData = dataList.sort((a, b) => {
            nameA = a.fullname.toLowerCase()
            nameB = b.fullname.toLowerCase()
            if (nameA > nameB)
                return -1
            if (nameA < nameB)
                return 1
            return 0
        })
        this.fullnameLeaveIcon = () => {
            this.setState({
                idHoverIcon: 0,
                firstnameHoverIcon: 0,
                lastnameHoverIcon: 0,
                ageHoverIcon: 0,
                fullnameHoverIcon: 1,
            })
        }
        this.idUNSORT();
        this.firstnameUNSORT();
        this.lastnameUNSORT();
        this.ageUNSORT();

        if (this.state.newDataStore_true) {
            this.setState({
                newDataStore: sortedData,
                fullname_unsort: false,
                fullname_ascending: false,
                fullname_descending: true
            })
        }
        else {
            this.setState({
                DataStore: sortedData,
                fullname_unsort: false,
                fullname_ascending: false,
                fullname_descending: true
            })
        }
    }

    // =================   handleChecked   =================

    handleChecked = (selectedrow) => {
        let data = [...this.state.DataStore];
        data = data.map((item) => {
            if (item.id === selectedrow.id) {
                item.checked = !item.checked
            }
            return item
        })
        this.setState({
            DataStore: data
        })
    }

    // =================   getselectedrows   =================

    getselectedrows = () => {
        let data = [...this.state.DataStore];
        let selectedData = data.filter((item) => {
            return item.checked
        })
        if (selectedData.length === 0) {
            return ""
        }
        else if (selectedData.length === 1) {
            return selectedData.length + " row selected"
        } else {

            return selectedData.length + " rows selected"
        }
    }

    // =================   Allclick   =================

    Allclick = (e) => {
        let data = [...this.state.DataStore];
        let dataSelected = e.target.checked
        data = data.map((item) => {
            item.checked = dataSelected
            return item
        })
        this.setState({
            DataStore: data
        })
    }

    // ===================== idHoverIcon =====================

    idHoverIcon = () => {
        this.setState({
            idHoverIcon: 1
        })
    }

    // ================== firstnameHoverIcon =================

    firstnameHoverIcon = () => {
        this.setState({
            firstnameHoverIcon: 1
        })
    }

    // ================== lastnameHoverIcon =================

    lastnameHoverIcon = () => {
        this.setState({
            lastnameHoverIcon: 1
        })
    }

    // ================== ageHoverIcon =================

    ageHoverIcon = () => {
        this.setState({
            ageHoverIcon: 1
        })
    }

    // ================== fullnameHoverIcon =================

    fullnameHoverIcon = () => {
        this.setState({
            fullnameHoverIcon: 1
        })
    }

    // ================== idLeaveIcon =================

    idLeaveIcon = () => {
        this.setState({
            idHoverIcon: 0
        })
    }

    // ================== firstnameLeaveIcon =================

    firstnameLeaveIcon = () => {
        this.setState({
            firstnameHoverIcon: 0
        })
    }

    // ================== lastnameLeaveIcon =================

    lastnameLeaveIcon = () => {
        this.setState({
            lastnameHoverIcon: 0
        })
    }

    // ================== ageLeaveIcon =================

    ageLeaveIcon = () => {
        this.setState({
            ageHoverIcon: 0
        })
    }

    // ================== fullnameLeaveIcon =================

    fullnameLeaveIcon = () => {
        this.setState({
            fullnameHoverIcon: 0
        })
    }

    // ================== nextClick =================

    nextClick = () => {
        if (this.state.DataStore.length > this.state.end) {
            this.setState({
                start: this.state.start + 5,
                end: this.state.end + 5,
                Count: this.state.Count + 5,
                SliceMethod_length_Count: true,
            })
        }
    }

    // ==================  backClick  =================

    backClick = () => {
        if (this.state.end === 5) {
            this.setState({
                start: 0,
                end: 5
            })
        }
        else {
            this.setState({
                start: this.state.start - 5,
                end: this.state.end - 5,
                Count: this.state.Count - 5,
            })
        }
    }

    // ================== showContainer =================

    showContainer = () => {
        this.setState({
            showContainer: !this.state.showContainer
        })
    }

    // ================== idContainer =================

    idContainer = () => {
        this.setState({
            idContainer: !this.state.idContainer
        })
    }

    // ==================   idFILTER   =================

    idFILTER = () => {
        this.setState({
            idFILTER: !this.state.idFILTER,
            firstnameFILTER: false,
            lastnameFILTER: false,
            ageFILTER: false,
            fullnameFILTER: false,
            Columns: "ID",
            Operators: "contains",
        })
    }

    // ================== firstnameContainer =================

    firstnameContainer = () => {
        this.setState({
            firstnameContainer: !this.state.firstnameContainer
        })
    }

    // ================== firstnameFILTER =================

    firstnameFILTER = () => {
        this.setState({
            firstnameFILTER: !this.state.firstnameFILTER,
            idFILTER: false,
            lastnameFILTER: false,
            ageFILTER: false,
            fullnameFILTER: false,
            Columns: "Firstname",
            Operators: "contains"
        })
    }

    // ================== lastnameContainer =================

    lastnameContainer = () => {
        this.setState({
            lastnameContainer: !this.state.lastnameContainer
        })
    }

    // ================== lastnameFILTER =================

    lastnameFILTER = () => {
        this.setState({
            lastnameFILTER: !this.state.lastnameFILTER,
            idFILTER: false,
            firstnameFILTER: false,
            ageFILTER: false,
            fullnameFILTER: false,
            Columns: "Lastname",
            Operators: "contains"
        })
    }

    // ================== ageContainer =================

    ageContainer = () => {
        this.setState({
            ageContainer: !this.state.ageContainer,
        })
    }

    // ================== ageFILTER =================

    ageFILTER = () => {
        this.setState({
            ageFILTER: !this.state.ageFILTER,
            idFILTER: false,
            firstnameFILTER: false,
            lastnameFILTER: false,
            fullnameFILTER: false,
            Columns: "Age",
            Operators: "="
        })
    }

    // ================== fullnameContainer =================

    fullnameContainer = () => {
        this.setState({
            fullnameContainer: !this.state.fullnameContainer,
            onClickAnimation: true
        })
    }

    // ================== fullnameFILTER =================

    fullnameFILTER = () => {
        this.setState({
            fullnameFILTER: !this.state.fullnameFILTER,
            idFILTER: false,
            firstnameFILTER: false,
            lastnameFILTER: false,
            ageFILTER: false,
            Columns: "Fullname",
            Operators: "contains"
        })
    }

    // ================== idHideClick =================

    idHideClick = () => {
        this.setState({
            idHideClick: true,
            idShow: true
        })
    }

    // ================== firstnameHideClick =================

    firstnameHideClick = () => {
        this.setState({
            firstnameHideClick: true,
            firstnameShow: true
        })
    }

    // ================== lastnameHideClick =================

    lastnameHideClick = () => {
        this.setState({
            lastnameHideClick: true,
            lastnameShow: true
        })
    }

    // ================== ageHideClick =================

    ageHideClick = () => {
        this.setState({
            ageHideClick: true,
            ageShow: true
        })
    }

    // ================== fullnameHideClick =================

    fullnameHideClick = () => {
        this.setState({
            fullnameHideClick: true,
            fullnameShow: true
        })
    }

    // ==================   hideAllClick   =================

    hideAllClick = () => {
        this.setState({
            checkboxShow: true,
            idShow: true,
            firstnameShow: true,
            lastnameShow: true,
            ageShow: true,
            fullnameShow: true
        })
    }

    // ==================   showAllClick   =================

    showAllClick = () => {
        this.setState({
            checkboxShow: false,
            idShow: false,
            firstnameShow: false,
            lastnameShow: false,
            ageShow: false,
            fullnameShow: false
        })
    }

    FilterFunction = () => {
        let FilterData;
        // let localstore = Object.assign([], this.state.DataTableData);
        let localstore = Object.assign([], this.state.DataStore);

        FilterData = localstore.filter((fil) => {

            // ------------- id --------------

            if (this.state.inputValue === " ") {
                return fil
            }
            else if (this.state.Columns === "ID" && this.state.Operators === "contains") {
                return fil.id.toString().toLowerCase().includes(this.state.inputValue.toLowerCase())
            }
            else if (this.state.Columns === "ID" && this.state.Operators === "equals") {
                return fil.id.toString().toLowerCase() === (this.state.inputValue.toLowerCase())
            }
            else if (this.state.Columns === "ID" && this.state.Operators === "startwith") {
                return fil.id.toString().toLowerCase().startsWith(this.state.inputValue.toLowerCase())
            }
            else if (this.state.Columns === "ID" && this.state.Operators === "endswith") {
                return fil.id.toString().toLowerCase().endsWith(this.state.inputValue.toLowerCase())
            }
            else if (this.state.Columns === "ID" && this.state.Operators === "isempty") {
                return fil.id.toString() === null || fil.id === ""
            }
            else if (this.state.Columns === "ID" && this.state.Operators === "isnotempty") {
                return fil.id !== " "
            }

            // ----------- firstname------------

            if (this.state.Columns === "Firstname" && this.state.Operators === "contains") {
                return fil.firstname.toLowerCase().includes(this.state.inputValue.toLowerCase())
            }
            else if (this.state.Columns === "Firstname" && this.state.Operators === "equals") {
                return fil.firstname.toLowerCase() === (this.state.inputValue.toLowerCase())
            }
            else if (this.state.Columns === "Firstname" && this.state.Operators === "startwith") {
                return fil.firstname.toLowerCase().startsWith(this.state.inputValue.toLowerCase())
            } else if (this.state.Columns === "Firstname" && this.state.Operators === "endswith") {
                return fil.firstname.toLowerCase().endsWith(this.state.inputValue.toLowerCase())
            } else if (this.state.Columns === "Firstname" && this.state.Operators === "isempty") {
                return fil.firstname === null || fil.firstname === ""
            } else if (this.state.Columns === "Firstname" && this.state.Operators === "isnotempty") {
                return fil.firstname !== ''
            }

            // -----------------lastname ----------------

            else if (this.state.Columns === "Lastname" && this.state.Operators === "contains") {
                return fil.lastname.toLowerCase().includes(this.state.inputValue.toLowerCase())
            } else if (this.state.Columns === "Lastname" && this.state.Operators === "equals") {
                return fil.lastname.toLowerCase() === (this.state.inputValue.toLowerCase())
            } else if (this.state.Columns === "Lastname" && this.state.Operators === "startwith") {
                return fil.lastname.toLowerCase().startsWith(this.state.inputValue.toLowerCase())
            } else if (this.state.Columns === "Lastname" && this.state.Operators === "endswith") {
                return fil.lastname.toLowerCase().endsWith(this.state.inputValue.toLowerCase())
            } else if (this.state.Columns === "Lastname" && this.state.Operators === "isempty") {
                return fil.lastname === null || fil.lastname === ""
            } else if (this.state.Columns === "Lastname" && this.state.Operators === "isnotempty") {
                return fil.lastname !== ''
            }

            //  --------------- age--------------

            else if (this.state.Columns === "Age" && this.state.Operators === "=") {
                let filterAge = fil.age === parseInt(this.state.inputValue)
                if (this.state.inputValue !== '') {
                    return filterAge
                } else {
                    return fil.age
                }
            }
            else if (this.state.Columns === "Age" && this.state.Operators === "!=") {
                let filterAge = fil.age !== parseInt(this.state.inputValue)
                if (this.state.inputValue !== '') {
                    return filterAge
                } else {
                    return fil.age
                }
            }
            else if (this.state.Columns === "Age" && this.state.Operators === "<") {
                let filterAge = fil.age < parseInt(this.state.inputValue)
                if (this.state.inputValue !== '') {
                    return filterAge
                } else {
                    return fil.age
                }
            }
            else if (this.state.Columns === "Age" && this.state.Operators === "<=") {
                let filterAge = fil.age <= parseInt(this.state.inputValue);
                if (this.state.inputValue !== '') {
                    return filterAge
                } else {
                    return fil.age
                }
            }
            else if (this.state.Columns === "Age" && this.state.Operators === ">") {
                let filterAge = fil.age > parseInt(this.state.inputValue);
                if (this.state.inputValue !== '') {
                    return filterAge
                } else {
                    return fil.age
                }
            }
            else if (this.state.Columns === "Age" && this.state.Operators === ">=") {
                let filterAge = fil.age >= parseInt(this.state.inputValue);
                if (this.state.inputValue !== '') {
                    return filterAge
                } else {
                    return fil.age
                }
            }
            else if (this.state.Columns === "Age" && this.state.Operators === "isempty") {
                return fil.age == null;
            }
            else if (this.state.Columns === "Age" && this.state.Operators === "isnotempty") {
                return fil.age !== ''
            }

            // ------------------------ fullname --------------------------

            else if (this.state.Columns === "Fullname" && this.state.Operators === "contains") {
                return fil.fullname.toLowerCase().includes(this.state.inputValue.toLowerCase())
            }
            else if (this.state.Columns === "Fullname" && this.state.Operators === "equals") {
                return fil.fullname.toLowerCase() === (this.state.inputValue.toLowerCase())
            }
            else if (this.state.Columns === "Fullname" && this.state.Operators === "startwith") {
                return fil.fullname.toLowerCase().startsWith(this.state.inputValue.toLowerCase())
            }
            else if (this.state.Columns === "Fullname" && this.state.Operators === "endswith") {
                return fil.fullname.toLowerCase().endsWith(this.state.inputValue.toLowerCase())
            }
            else if (this.state.Columns === "Fullname" && this.state.Operators === "isempty") {
                return fil.fullname === null || fil.fullname === ""
            }
            else if (this.state.Columns === "Fullname" && this.state.Operators === "isnotempty") {
                return fil.fullname !== ''
            }
        })



        if (this.state.inputValue === "") {
            if (this.state.id_unsort) {
                this.idUNSORT();
            }
            else if (this.state.id_ascending) {
                this.idASC();
            }
            else if (this.state.id_descending) {
                this.idDSC();
            }
            else if (this.state.firstname_unsort) {
                this.firstnameUNSORT();
            }
            else if (this.state.firstname_ascending) {
                this.firstnameASC();
            }
            else if (this.state.firstname_descending) {
                this.firstnameDSC();
            }
            else if (this.state.lastname_unsort) {
                this.lastnameUNSORT();
            }
            else if (this.state.lastname_ascending) {
                this.lastnameASC();
            }
            else if (this.state.lastname_descending) {
                this.lastnameDSC();
            }
            else if (this.state.age_unsort) {
                this.ageUNSORT();
            }
            else if (this.state.age_ascending) {
                this.ageASC();
            }
            else if (this.state.age_descending) {
                this.ageDSC();
            }
            else if (this.state.fullname_unsort) {
                this.fullnameUNSORT();
            }
            else if (this.state.fullname_ascending) {
                this.fullnameASC();
            }
            else if (this.state.fullname_descending) {
                this.fullnameDSC();
            }
            else if (this.state.newDataStore_true === false) {
                this.setState({
                    newDataStore: [],
                })
            }
        }
        // else if (this.state.firstname_ascending) {

        //     this.setState({
        //         newDataStore_true: true,
        //         newDataStore: FilterData
        //     })
        //     this.firstnameASC();
        // }
        // else if (this.state.firstname_descending) {
        //     this.setState({
        //         newDataStore_true: true,
        //         newDataStore: FilterData
        //     })
        //     this.firstnameDSC();
        // }

        this.setState({
            newDataStore: FilterData,
            newDataStore_true: true,
            start: 0,
            end: 5,
            Count: 1,
        })
    }


    showColumnsFun = (i) => {
        let data = Object.assign([], this.state.filterSearch);
        data = data.map((v, index) => {
            if (index === i) {
                v.isOpen = !v.isOpen;
            }
            else {
                v.isOpen = false;
            }

            // ================== checkboxShow =================

            if (index === 0 && i === 0) {
                this.setState({
                    checkboxShow: !this.state.checkboxShow,
                })
            }

            // ==================   idShow     =================        

            else if (index === 1 && i === 1) {
                this.setState({
                    idShow: !this.state.idShow,
                    idHideClick: false
                })
            }

            // ================== firstnameShow =================

            else if (index === 2 && i === 2) {
                this.setState({
                    firstnameShow: !this.state.firstnameShow,
                    firstnameHideClick: false
                })
            }

            // ================== lastnameShow =================

            else if (index === 3 && i === 3) {
                this.setState({
                    lastnameShow: !this.state.lastnameShow,
                    lastnameHideClick: false
                })
            }

            // ==================  ageShow  =================

            else if (index === 4 && i === 4) {
                this.setState({
                    ageShow: !this.state.ageShow,
                    ageHideClick: false
                })
            }

            // ================== fullnameShow =================

            else if (index === 5 && i === 5) {
                this.setState({
                    fullnameShow: !this.state.fullnameShow,
                    fullnameHideClick: false
                })
            }
            return v;
        })
        this.setState({
            filterSearch: data
        })
    }

    searchFilter = () => {
        console.log("test", this.state.inputValues)
        let searchData = Object.assign([], this.state.filterSearch)
        let searchFilter = searchData.filter((item) => {
            console.log("u", item.label.toLowerCase().match(this.state.inputValues.toLowerCase()))
            let test = item.label.toLowerCase().match(this.state.inputValues.toLowerCase());
            console.log("test", test)
            return test;
        })
        this.setState({
            filteredSearch: searchFilter,
        })
        console.log("filteredSearch", this.state.filteredSearch)
    }

    FilterData_Remove = () => {
        let datas = [...this.state.DataTableData];


        this.setState({
            newDataStore_true: false,
            DataStore: datas,
            idFILTER: false,
            inputValue: "",
            Columns: "",
            Operators: "",
        })

        this.idUNSORT();
        this.lastnameUNSORT();
        this.ageUNSORT();
        this.fullnameUNSORT();
        this.firstnameUNSORT();

        console.table(this.state.DataStore, "kkkkkkkjjjjjjjj");
    }


    SliceMethodMap = () => {

        let SliceMethod = this.state.newDataStore_true === true ? this.state.newDataStore.slice(this.state.start, this.state.end) :
            this.state.newDataStore_true === false ? this.state.DataStore.slice(this.state.start, this.state.end) : '';

        return SliceMethod.map((item, index) => {
            return (
                <tr key={index} >
                    <td className={`width8 ${this.state.checkboxShow ? "checkboxsHideClick" : ""}`}>
                        <input
                            className="checkboxs"
                            onClick={() => this.handleChecked(item)}
                            type="checkbox"
                            checked={item.checked}
                        />
                    </td>
                    <td className={`width13 ${this.state.idHideClick ? "idHideClick" : this.state.idShow ? "idHideClick" : ""}`}>
                        {item.id}
                    </td>
                    <td className={`width20 ${this.state.firstnameHideClick ? "firstnameHideClick" : this.state.firstnameShow ? "firstnameHideClick" : ""}`}>
                        {item.firstname}
                    </td>
                    <td className={`width20 ${this.state.lastnameHideClick ? "lastnameHideClick" : this.state.lastnameShow ? "lastnameHideClick" : ""}`}>
                        {item.lastname}
                    </td>
                    <td className={`width15 ${this.state.ageHideClick ? "ageHideClick" : this.state.ageShow ? "ageHideClick" : ""}`}>
                        {item.age}
                    </td>
                    <td className={`width23 ${this.state.fullnameHideClick ? "fullnameHideClick" : this.state.fullnameShow ? "fullnameHideClick" : ""}`}>
                        {item.fullname}
                    </td>
                </tr>
            )

        })

    }
    //   =================================  render()  ==============================

    render() {
        const SliceMethod = this.state.newDataStore_true === true ? this.state.newDataStore.slice(this.state.start, this.state.end) : this.state.DataStore.slice(this.state.start, this.state.end);
        const SliceMethod_length = SliceMethod.length;
        // const SliceMethod_length_Count=this.state.SliceMethod_length_Count;
        console.log(this.state.Columns, "-", this.state.Operators, "-", this.state.inputValue);

        console.log(this.state.idHoverIcon, "lllllllll");

        console.log(this.state.firstname_unsort - this.state.firstname_ascending - this.state.firstname_descending, "isOKay==y")
        // console.table(this.state.DataStore);
        return (
            <React.Fragment>
                <h3>DataTable</h3>
                <div className="DataTableContainer">
                    <div className="filter_emptyspace">
                        {
                            this.state.idFILTER ?
                                <div className="FILTER">
                                    <div><i className="fas fa-times" onClick={() =>
                                        // { this.setState({ idFILTER: false, }, () => {

                                        this.FilterData_Remove()

                                        //  }) }
                                    }

                                    ></i></div>
                                    <div>
                                        <select defaultValue="ID" onChange={(e) => { this.setState({ Columns: e.target.value }, () => { this.FilterFunction() }) }} >
                                            <option value="ID " >ID</option>
                                            <option value="Firstname">First name</option>
                                            <option value="Lastname">Last name</option>
                                            <option value="Age">Age</option>
                                            <option value="Fullname">Full name</option>
                                        </select>
                                    </div>
                                    <div>
                                        {this.state.Columns === "Age" ?
                                            <select onChange={(e) => { this.setState({ Operators: e.target.value }, () => { this.FilterFunction() }) }}>
                                                <option value="=">=</option>
                                                <option value="!=">!=</option>
                                                <option value="<">  &lt;</option>
                                                <option value="<=" > &#8804; </option>
                                                <option value=">" > &gt; </option>
                                                <option value=">=" > &#8805; </option>
                                                <option value="isempty">is empty</option>
                                                <option value="isnotempty">is not empty</option>
                                            </select>
                                            :
                                            <select onChange={(e) => { this.setState({ Operators: e.target.value }, () => { this.FilterFunction() }) }}>
                                                <option value="contains">contains</option>
                                                <option value="equals">equals</option>
                                                <option value="startwith">start with</option>
                                                <option value="endswith">ends with</option>
                                                <option value="isempty">is empty</option>
                                                <option value="isnotempty">is not empty</option>
                                            </select>
                                        }
                                    </div>
                                    <div> <input type="text" value={this.state.inputValue} placeholder="Filter value" onChange={(e) => { e.preventDefault(); this.setState({ inputValue: e.target.value }, () => { this.FilterFunction() }) }} autoFocus /></div>
                                </div> : null
                        }
                        {
                            this.state.firstnameFILTER ?
                                <div className="FILTER">
                                    <div><i className="fas fa-times" onClick={() => { this.setState({ firstnameFILTER: false }, () => { this.FilterData_Remove() }) }}></i></div>
                                    <div>
                                        <select defaultValue="Firstname" onChange={(e) => { this.setState({ Columns: e.target.value }, () => { this.FilterFunction() }) }}>
                                            <option value="ID" >ID</option>
                                            <option value="Firstname" selected="Firstname">First name</option>
                                            <option value="Lastname">Last name</option>
                                            <option value="Age">Age</option>
                                            <option value="Fullname">Full name</option>
                                        </select>
                                    </div>
                                    <div>
                                        {
                                            this.state.Columns === "Age" ?
                                                <select onChange={(e) => { this.setState({ Operators: e.target.value }, () => { this.FilterFunction() }) }}>
                                                    <option value="=">=</option>
                                                    <option value="!=">!=</option>
                                                    <option value="<">  &lt;</option>
                                                    <option value="<=" > &#8804; </option>
                                                    <option value=">" > &gt; </option>
                                                    <option value=">=" > &#8805; </option>
                                                    <option value="isempty">is empty</option>
                                                    <option value="isnotempty">is not empty</option>
                                                </select>
                                                :
                                                <select onChange={(e) => { this.setState({ Operators: e.target.value }, () => { this.FilterFunction() }) }}>
                                                    <option value="contains">contains</option>
                                                    <option value="equals">equals</option>
                                                    <option value="startwith">start with</option>
                                                    <option value="endswith" >ends with</option>
                                                    <option value="isempty">is empty</option>
                                                    <option value="isnotempty">is not empty</option>
                                                </select>
                                        }
                                    </div>
                                    <div> <input type="text" value={this.state.inputValue} placeholder="Filter value"
                                        onChange={(e) => { e.preventDefault(); this.setState({ inputValue: e.target.value }, () => { this.FilterFunction() }) }} autoFocus />
                                    </div>
                                </div> : null
                        }
                        {
                            this.state.lastnameFILTER ?
                                <div className="FILTER">
                                    <div><i className="fas fa-times" onClick={() => { this.setState({ lastnameFILTER: false }, () => { this.FilterData_Remove() }) }}></i></div>
                                    <div>
                                        <select defaultValue="Lastname" onChange={(e) => { this.setState({ Columns: e.target.value }, () => { this.FilterFunction() }) }} >
                                            <option value="ID">ID</option>
                                            <option value="Firstname">First name</option>
                                            <option value="Lastname" selected="Lastname">Last name</option>
                                            <option value="Age">Age</option>
                                            <option value="Fullname">Full name</option>
                                        </select>
                                    </div>
                                    <div>
                                        {this.state.Columns === "Age" ?
                                            <select onChange={(e) => { this.setState({ Operators: e.target.value }, () => { this.FilterFunction() }) }}>
                                                <option value="=">=</option>
                                                <option value="!=">!=</option>
                                                <option value="<">  &lt;</option>
                                                <option value="<=" > &#8804; </option>
                                                <option value=">" > &gt; </option>
                                                <option value=">=" > &#8805; </option>
                                                <option value="isempty">is empty</option>
                                                <option value="isnotempty">is not empty</option>
                                            </select>
                                            :
                                            <select onChange={(e) => { this.setState({ Operators: e.target.value }, () => { this.FilterFunction() }) }}>
                                                <option value="contains">contains</option>
                                                <option value="equals">equals</option>
                                                <option value="startwith">start with</option>
                                                <option value="endswith" >ends with</option>
                                                <option value="isempty">is empty</option>
                                                <option value="isnotempty">is not empty</option>
                                            </select>
                                        }
                                    </div>
                                    <div> <input type="text" placeholder="Filter value" onChange={(e) => { e.preventDefault(); this.setState({ inputValue: e.target.value }, () => { this.FilterFunction() }) }} autoFocus />
                                    </div>
                                </div> : null
                        }
                        {
                            this.state.ageFILTER ?
                                <div className="FILTER">
                                    <div><i className="fas fa-times" onClick={() => { this.setState({ ageFILTER: false }, () => { this.FilterData_Remove() }) }}></i></div>
                                    <div>
                                        <select defaultValue="Age" onChange={(e) => { this.setState({ Columns: e.target.value }, () => { this.FilterFunction() }) }}>
                                            <option value="ID">ID</option>
                                            <option value="Firstname">First name</option>
                                            <option value="Lastname" >Last name</option>
                                            <option value="Age" selected="Age" >Age</option>
                                            <option value="Fullname">Full name </option>
                                        </select>
                                    </div>
                                    <div>
                                        {
                                            this.state.Columns === "Age" ?
                                                <select onChange={(e) => { this.setState({ Operators: e.target.value }, () => { this.FilterFunction() }) }}>
                                                    <option value="=">=</option>
                                                    <option value="!=">!=</option>
                                                    <option value="<">  &lt;</option>
                                                    <option value="<=" > &#8804; </option>
                                                    <option value=">" > &gt; </option>
                                                    <option value=">=" > &#8805; </option>
                                                    <option value="isempty">is empty</option>
                                                    <option value="isnotempty">is not empty</option>
                                                </select>
                                                :
                                                <select onChange={(e) => { this.setState({ Operators: e.target.value }, () => { this.FilterFunction() }) }}>
                                                    <option value="contains">contains</option>
                                                    <option value="equals">equals</option>
                                                    <option value="startwith">start with</option>
                                                    <option value="endswith" >ends with</option>
                                                    <option value="isempty">is empty</option>
                                                    <option value="isnotempty">is not empty</option>
                                                </select>
                                        }
                                    </div>
                                    <div> <input type="text" placeholder="Filter value" onChange={(e) => { e.preventDefault(); this.setState({ inputValue: e.target.value }, () => { this.FilterFunction() }) }} autoFocus />
                                    </div>
                                </div> : null
                        }
                        {
                            this.state.fullnameFILTER ?
                                <div className="FILTER">
                                    <div><i className="fas fa-times" onClick={() => { this.setState({ fullnameFILTER: false }, () => { this.FilterData_Remove() }) }}></i></div>
                                    <div>
                                        <select defaultValue="Fullname" onChange={(e) => { this.setState({ Columns: e.target.value }, () => { this.FilterFunction() }) }}>
                                            <option value="ID">ID</option>
                                            <option value="Firstname">First name</option>
                                            <option value="Lastname">Last name</option>
                                            <option value="Age">Age</option>
                                            <option value="Fullname" selected >Fullname</option>
                                        </select>
                                    </div>
                                    <div>
                                        {
                                            this.state.Columns === "Age" ?
                                                <select onChange={(e) => { this.setState({ Operators: e.target.value }, () => { this.FilterFunction() }) }}>
                                                    <option value="=">=</option>
                                                    <option value="!=">!=</option>
                                                    <option value="<">  &lt;</option>
                                                    <option value="<=" > &#8804; </option>
                                                    <option value=">" > &gt; </option>
                                                    <option value=">=" > &#8805; </option>
                                                    <option value="isempty">is empty</option>
                                                    <option value="isnotempty">is not empty</option>
                                                </select>
                                                :
                                                <select onChange={(e) => { this.setState({ Operators: e.target.value }, () => { this.FilterFunction() }) }}>
                                                    <option value="contains" selected>contains</option>
                                                    <option value="equals">equals</option>
                                                    <option value="startwith">start with</option>
                                                    <option value="endswith" >ends with</option>
                                                    <option value="isempty">is empty</option>
                                                    <option value="isnotempty">is not empty</option>
                                                </select>
                                        }
                                    </div>
                                    <div> <input type="text" value={this.state.inputValue} placeholder="Filter value" onChange={(e) => { e.preventDefault(); this.setState({ inputValue: e.target.value }, () => { this.FilterFunction() }) }} autoFocus /></div>
                                </div> : null
                        }
                    </div>
                    <div className="table_container">
                        <table >
                            <thead>
                                <tr >
                                    <th className={`width8 ${this.state.checkboxShow ? "checkboxsHideClick" : ""}`}>
                                        <input type="checkbox" onClick={(e) => this.Allclick(e)} />
                                    </th>
                                    <th className={` width13 ${this.state.idHideClick ? "idHideClick" : this.state.idShow ? "idHideClick" : ""}`}
                                        onMouseOver={() => this.idHoverIcon()}
                                        onMouseLeave={() => this.idLeaveIcon()} >
                                        <span className="idIcon">
                                            <span>ID</span>
                                            <span className="idIcon_i">
                                                <span
                                                    className={`${this.state.idHoverIcon ? "visable" : "hide"}`} onClick={() => this.idClick()} title="Sort">
                                                    <i style={this.state.id_unsort ? { color: 'grey', opacity: '0.8' } : { color: '' }}
                                                        className={`fas ${this.state.id_descending ? "fa-arrow-down" : this.state.id_ascending ? "fa-arrow-up" : this.state.id_unsort ? "fa-arrow-up" : null}`}></i>
                                                </span>&nbsp;&nbsp;
                                                <span title="Menu" >  <i className="fas fa-ellipsis-v" onClick={() => this.idContainer()} ></i> </span>
                                            </span>
                                        </span>
                                    </th>
                                    <th
                                        className={`width20 ${this.state.firstnameHideClick ? "firstnameHideClick" : this.state.firstnameShow ? "firstnameHideClick" : ""}`}
                                        onMouseOver={() => this.firstnameHoverIcon()}
                                        onMouseLeave={() => this.firstnameLeaveIcon()}>
                                        <span className="firstnameIcon">
                                            <span>   firstname</span>
                                            <span className="firstnameIcon_i">
                                                <span className={`${this.state.firstnameHoverIcon ? "visable" : "hide"}`} onClick={() => this.firstnameClick()} title="Sort">
                                                    <i style={this.state.firstname_unsort ? { color: 'grey', opacity: '0.8' } : { color: '' }}
                                                        className={`fas ${this.state.firstname_ascending ? "fa-arrow-up" : this.state.firstname_descending ? "fa-arrow-down" : this.state.firstname_unsort ? "fa-arrow-up" : null}`}></i>
                                                </span>&nbsp;&nbsp;
                                                <span title="Menu" className={` ${this.state.onClickAnimation ? "onClickAnimation" : ""}`}> <i className="fas fa-ellipsis-v" onClick={() => this.firstnameContainer()}></i></span>
                                            </span>
                                        </span>
                                    </th>
                                    <th className={`width20 ${this.state.lastnameHideClick ? "lastnameHideClick" : this.state.lastnameShow ? "lastnameHideClick" : ""}`}
                                        onMouseOver={() => this.lastnameHoverIcon()}
                                        onMouseLeave={() => this.lastnameLeaveIcon()}>
                                        <span className="lastnameIcon">
                                            <span>   lastname</span>

                                            <span className="lastnameIcon_i" >
                                                <span className={`${this.state.lastnameHoverIcon ? "visable" : "hide"}`} onClick={() => this.lastnameClick()} title="Sort">
                                                    <i style={this.state.lastname_unsort ? { color: 'grey', opacity: '0.8' } : { color: '' }}
                                                        className={`fas ${this.state.lastname_ascending ? "fa-arrow-up" : this.state.lastname_descending ? "fa-arrow-down" : this.state.lastname_unsort ? "fa-arrow-up" : null}`}></i>
                                                </span>&nbsp;&nbsp;
                                                <span title="Menu"> <i className="fas fa-ellipsis-v" onClick={() => this.lastnameContainer()}></i></span>
                                            </span>
                                        </span>
                                    </th>
                                    <th className={`width15 ${this.state.ageHideClick ? "ageHideClick " : this.state.ageShow ? "ageHideClick" : ""}`}
                                        onMouseOver={() => this.ageHoverIcon()}
                                        onMouseLeave={() => this.ageLeaveIcon()}>
                                        <span className="ageIcon">
                                            <span>   age</span>
                                            <span className="ageIcon_i" >
                                                <span className={`${this.state.ageHoverIcon ? "visable" : "hide"}`} onClick={() => this.ageClick()} title="Sort">
                                                    <i style={this.state.age_unsort ? { color: 'grey', opacity: '0.8' } : { color: '' }}
                                                        className={`fas ${this.state.age_descending ? "fa-arrow-down" : this.state.age_ascending ? "fa-arrow-up" : this.state.age_unsort ? "fa-arrow-up" : null}`}></i>
                                                </span>&nbsp;&nbsp;
                                                <span title="Menu"> <i className="fas fa-ellipsis-v" onClick={() => this.ageContainer()}></i></span>
                                            </span>
                                        </span>
                                    </th>
                                    <th className={`width23 ${this.state.fullnameHideClick ? "fullnameHideClick" : this.state.fullnameShow ? "fullnameHideClick" : ""}`}
                                        onMouseOver={() => this.fullnameHoverIcon()}
                                        onMouseLeave={() => this.fullnameLeaveIcon()}>
                                        <span className="fullnameIcon">
                                            <span> fullname</span>
                                            <span className="fullnameIcon_i">
                                                <span className={`${this.state.fullnameHoverIcon ? "visable" : "hide"}`} onClick={() => this.fullnameClick()} title="Sort">
                                                    <i style={this.state.fullname_unsort ? { color: 'grey', opacity: '0.8' } : { color: '' }}
                                                        className={`fas ${this.state.fullname_ascending ? "fa-arrow-up" : this.state.fullname_descending ? "fa-arrow-down" : this.state.fullname_unsort ? "fa-arrow-up" : null}`}></i>
                                                </span>&nbsp;&nbsp;&nbsp;&nbsp;
                                                <span title="Menu"> <i className="fas fa-ellipsis-v" onClick={() => this.fullnameContainer()}></i></span>
                                            </span>
                                        </span>
                                    </th>
                                </tr>
                            </thead>

                            {/* ==================== tabledata get using  -map ========================= */}

                            <tbody>
                                {
                                    this.SliceMethodMap()
                                }
                            </tbody>
                            <tfoot></tfoot>
                        </table>
                    </div>

                    {/* ================================= idContainer ======================================== */}

                    {this.state.idContainer ?
                        <div className="idContainer">
                            <ul>
                                <li className={`${this.state.id_unsort ? "id_unsort_disable" : ""}`}
                                    onClick={() => {
                                        this.setState({ idContainer: false })
                                        this.idUNSORT()
                                    }}>Unsort</li>
                                <li className={`${this.state.id_ascending ? "id_ascending_disable" : ""}`}
                                    onClick={() => {
                                        this.setState({ idContainer: false })
                                        this.idASC()
                                    }}>
                                    Sort by ASC
                                </li>
                                <li className={`${this.state.id_descending ? "id_descending_disable" : ""}`}
                                    onClick={() => {
                                        this.setState({ idContainer: false })
                                        this.idDSC()

                                    }}>Sort by DESC
                                </li>
                                <li onClick={() => {
                                    this.setState({ idContainer: false })
                                    this.idFILTER()
                                }}>Filter</li>
                                <li onClick={() => {
                                    this.setState({ idContainer: false })
                                    this.idHideClick()
                                }}>Hide</li>
                                <li className="mousehover_idShowContainer"
                                    onMouseOver={() => { this.setState({ mousehover_idShowContainer: true, mouseleave_idShowContainer: true }) }}
                                    onMouseLeave={() => { this.setState({ mouseleave_idShowContainer: false }) }}
                                    onClick={() => this.idShowContainer()}>
                                    <span style={{ display: "flex", alignItems: "center", justifyContent: "space-between", paddingRight: "7px" }}>
                                        <span>Show columns</span>
                                        <span><i class="fas fa-caret-right" style={{ fontSize: "15px" }}></i></span>
                                    </span>
                                    {this.state.mousehover_idShowContainer && this.state.mouseleave_idShowContainer ?
                                        <div className="idShowContainer"
                                            onMouseOver={() => {
                                                this.setState({
                                                    mousehover_idShowContainer: true,
                                                    mouseleave_idShowContainer: true
                                                })
                                            }}
                                            onMouseLeave={() => { this.setState({ mouseleave_idShowContainer: false }) }} >
                                            <div className="input">
                                                <input type="text" value={this.state.inputValues} placeholder="Find column" onChange={(e) => {
                                                    e.preventDefault();
                                                    this.setState({ inputValues: e.target.value }, () => this.searchFilter());
                                                }} />
                                            </div>
                                            <div className="showColumns">
                                                <ul>
                                                    {
                                                        this.state.filteredSearch.length > 0 ? this.state.filteredSearch.map((v, i) => {
                                                            return (
                                                                <li key={i} onClick={(e) => this.showColumnsFun(i)} >
                                                                    <i className={v.isOpen ? "fas fa-toggle-off" : "fas fa-toggle-on"}></i>
                                                                    {v.label}
                                                                </li>
                                                            )
                                                        })
                                                            : this.state.filterSearch.map((v, i) => {
                                                                return (
                                                                    <li key={i} onClick={(e) => this.showColumnsFun(i)} >
                                                                        <i className={v.isOpen ? "fas fa-toggle-off" : "fas fa-toggle-on"}></i>
                                                                        {v.label}
                                                                    </li>
                                                                )
                                                            })
                                                    }
                                                </ul>
                                            </div>
                                            <div className="button">
                                                <div>
                                                    <button onClick={() => this.hideAllClick()}>HIDE ALL</button>
                                                </div>
                                                <div>
                                                    <button onClick={() => this.showAllClick()}>SHOW ALL</button>
                                                </div>
                                            </div>
                                        </div> : null
                                    }
                                </li>
                            </ul>
                        </div> : null
                    }

                    {/* ============================ firstnameContainer ================================= */}

                    {this.state.firstnameContainer ?
                        <div className="firstnameContainer">
                            <ul>
                                <li className={`${this.state.firstname_unsort ? "firstname_unsort_disable" : ""}`}
                                    onClick={() => {
                                        this.setState({ firstnameContainer: false })
                                        this.firstnameUNSORT()
                                    }}>Unsort</li>
                                <li className={`${this.state.firstname_ascending ? "firstname_ascending_disable" : ""}`}
                                    onClick={() => {
                                        this.setState({ firstnameContainer: false })
                                        this.firstnameASC()
                                    }}>Sort by ASC</li>
                                <li className={`${this.state.firstname_descending ? "firstname_descending_disable" : ""}`}
                                    onClick={() => {
                                        this.setState({ firstnameContainer: false })
                                        this.firstnameDSC()
                                    }}>Sort by DESC</li>
                                <li onClick={() => {
                                    this.setState({ firstnameContainer: false })
                                    this.firstnameFILTER()
                                }}>Filter</li>
                                <li onClick={() => {
                                    this.setState({ firstnameContainer: false })
                                    this.firstnameHideClick()
                                }}>Hide</li>
                                <li className="mousehover_firstnameShowContainer"
                                    onMouseOver={() => { this.setState({ mousehover_firstnameShowContainer: true, mouseleave_firstnameShowContainer: true }) }}
                                    onMouseLeave={() => { this.setState({ mouseleave_firstnameShowContainer: false }) }}
                                    onClick={() => { this.firstnameshowContainer() }}>
                                    <span style={{ display: "flex", alignItems: "center", justifyContent: "space-between", paddingRight: "7px" }}>
                                        <span>Show columns</span>
                                        <span><i class="fas fa-caret-right" style={{ fontSize: "15px" }}></i></span>
                                    </span>
                                    {this.state.mousehover_firstnameShowContainer && this.state.mouseleave_firstnameShowContainer ?
                                        <div className="firstnameShowColumns"
                                            onMouseOver={() => { this.setState({ mousehover_firstnameShowContainer: true, mouseleave_firstnameShowContainer: true }) }}
                                            onMouseLeave={() => { this.setState({ mouseleave_firstnameShowContainer: false }) }}>
                                            <div className="input">
                                                <input type="text" value={this.state.inputValues} placeholder="Find column" onChange={(e) => {
                                                    e.preventDefault();
                                                    this.setState({ inputValues: e.target.value }, () => this.searchFilter());
                                                }} />
                                            </div>
                                            <div className="showColumns">
                                                <ul>
                                                    {
                                                        this.state.filteredSearch.length > 0 ? this.state.filteredSearch.map((v, i) => {
                                                            return (
                                                                <li key={i} onClick={(e) => this.showColumnsFun(i)} >
                                                                    <i className={v.isOpen ? "fas fa-toggle-off" : "fas fa-toggle-on"}></i>
                                                                    {v.label}
                                                                </li>
                                                            )
                                                        })
                                                            : this.state.filterSearch.map((v, i) => {
                                                                return (
                                                                    <li key={i} onClick={(e) => this.showColumnsFun(i)} >
                                                                        <i className={v.isOpen ? "fas fa-toggle-off" : "fas fa-toggle-on"}></i>
                                                                        {v.label}
                                                                    </li>
                                                                )
                                                            })
                                                    }
                                                </ul>
                                            </div>
                                            <div className="button">
                                                <div>
                                                    <button onClick={() => this.hideAllClick()}>HIDE ALL</button>
                                                </div>
                                                <div>
                                                    <button onClick={() => this.showAllClick()}>SHOW ALL</button>
                                                </div>
                                            </div>
                                        </div> : null
                                    }
                                </li>
                            </ul>
                        </div> : null
                    }

                    {/* ========================= lastnameContainer ========================= */}

                    {this.state.lastnameContainer ?
                        <div className="lastnameContainer">
                            <ul>
                                <li className={`${this.state.lastname_unsort ? "lastname_unsort_disable" : ""}`}
                                    onClick={() => {
                                        this.setState({ lastnameContainer: false })
                                        this.lastnameUNSORT()
                                    }}>Unsort</li>
                                <li className={`${this.state.lastname_ascending ? "lastname_ascending_disable" : ""}`}
                                    onClick={() => {
                                        this.setState({ lastnameContainer: false })
                                        this.lastnameASC()
                                    }}>Sort by ASC</li>
                                <li className={`${this.state.lastname_descending ? "lastname_descending_disable" : ""}`}
                                    onClick={() => {
                                        this.setState({ lastnameContainer: false })
                                        this.lastnameClick()
                                    }}>Sort by DESC</li>
                                <li onClick={() => {
                                    this.setState({ lastnameContainer: false })
                                    this.lastnameFILTER()
                                }}>Filter</li>
                                <li onClick={() => {
                                    this.setState({ lastnameContainer: false })
                                    this.lastnameHideClick()
                                }}>Hide</li>
                                <li
                                    className="mousehover_lastnameShowContainer"
                                    onMouseOver={() => { this.setState({ mousehover_lastnameShowContainer: true, mouseleave_lastnameShowContainer: true }) }}
                                    onMouseLeave={() => { this.setState({ mouseleave_lastnameShowContainer: false }) }}
                                    onClick={() => this.lastnameshowContainer()}>
                                    <span style={{ display: "flex", alignItems: "center", justifyContent: "space-between", paddingRight: "7px" }}>
                                        <span>Show columns</span>
                                        <span><i class="fas fa-caret-right" style={{ fontSize: "15px" }}></i></span>
                                    </span>
                                    {
                                        this.state.mousehover_lastnameShowContainer && this.state.mouseleave_lastnameShowContainer ?
                                            <div className="lastnameShowColumns"
                                                onMouseOver={() => { this.setState({ mousehover_lastnameShowContainer: true, mouseleave_lastnameShowContainer: true }) }}
                                                onMouseLeave={() => { this.setState({ mouseleave_lastnameShowContainer: false }) }}>
                                                <div className="input">
                                                    <input type="text" value={this.state.inputValues} placeholder="Find column" onChange={(e) => {
                                                        e.preventDefault();
                                                        this.setState({ inputValues: e.target.value }, () => this.searchFilter());
                                                    }} />
                                                </div>
                                                <div className="showColumns">
                                                    <ul>
                                                        {
                                                            this.state.filteredSearch.length > 0 ? this.state.filteredSearch.map((v, i) => {
                                                                return (
                                                                    <li key={i} onClick={(e) => this.showColumnsFun(i)} >
                                                                        <i className={v.isOpen ? "fas fa-toggle-off" : "fas fa-toggle-on"}></i>
                                                                        {v.label}
                                                                    </li>
                                                                )
                                                            })
                                                                : this.state.filterSearch.map((v, i) => {
                                                                    return (
                                                                        <li key={i} onClick={(e) => this.showColumnsFun(i)} >
                                                                            <i className={v.isOpen ? "fas fa-toggle-off" : "fas fa-toggle-on"}></i>
                                                                            {v.label}
                                                                        </li>
                                                                    )
                                                                })
                                                        }
                                                    </ul>
                                                </div>
                                                <div className="button">
                                                    <div>
                                                        <button onClick={() => this.hideAllClick()}>HIDE ALL</button>
                                                    </div>
                                                    <div>
                                                        <button onClick={() => this.showAllClick()}>SHOW ALL</button>
                                                    </div>
                                                </div>
                                            </div> : null
                                    }
                                </li>
                            </ul>
                        </div> : null
                    }

                    {/* ========================== agecontainer =============================== */}

                    {this.state.ageContainer ?
                        <div className="ageContainer">
                            <ul>
                                <li className={`${this.state.age_unsort ? "age_unsort_disable" : ""}`}
                                    onClick={() => {
                                        this.setState({ ageContainer: false })
                                        this.ageUNSORT()
                                    }}>Unsort</li>
                                <li className={`${this.state.age_ascending ? "age_ascending_disable" : ""}`}
                                    onClick={() => {
                                        this.setState({ ageContainer: false })
                                        this.ageASC()
                                    }}>Sort by ASC</li>
                                <li className={`${this.state.age_descending ? "age_descending_disable" : ""}`}
                                    onClick={() => {
                                        this.setState({ ageContainer: false })
                                        this.ageDSC()
                                    }}>Sort by DESC</li>
                                <li onClick={() => {
                                    this.setState({ ageContainer: false })
                                    this.ageFILTER()
                                }}>Filter</li>
                                <li onClick={() => {
                                    this.setState({ ageContainer: false })
                                    this.ageHideClick()
                                }}>Hide</li>
                                <li
                                    className="mousehover_ageShowContainer"
                                    onMouseOver={() => { this.setState({ mousehover_ageShowContainer: true, mouseleave_ageShowContainer: true }) }}
                                    onMouseLeave={() => { this.setState({ mouseleave_ageShowContainer: false }) }}
                                    onClick={() => this.ageshowContainer()}>
                                    <span style={{ display: "flex", alignItems: "center", justifyContent: "start" }}>
                                        <span><i class="fas fa-caret-left" style={{ fontSize: "15px" }}></i></span>
                                        <span style={{ paddingLeft: "17px" }}>Show columns</span>
                                    </span>
                                    {
                                        this.state.mousehover_ageShowContainer && this.state.mouseleave_ageShowContainer ?
                                            <div className="ageshowContainer"
                                                onMouseOver={() => { this.setState({ mousehover_ageShowContainer: true, mouseleave_ageShowContainer: true }) }}
                                                onMouseLeave={() => { this.setState({ mouseleave_ageShowContainer: false }) }}>
                                                <div className="input">
                                                    <input type="text" value={this.state.inputValues} placeholder="Find column" onChange={(e) => {
                                                        e.preventDefault();
                                                        this.setState({ inputValues: e.target.value }, () => this.searchFilter());
                                                    }} />
                                                </div>
                                                <div className="showColumns">
                                                    <ul>
                                                        {
                                                            this.state.filteredSearch.length > 0 ? this.state.filteredSearch.map((v, i) => {
                                                                return (
                                                                    <li key={i} onClick={(e) => this.showColumnsFun(i)} >
                                                                        <i className={v.isOpen ? "fas fa-toggle-off" : "fas fa-toggle-on"}></i>
                                                                        {v.label}
                                                                    </li>
                                                                )
                                                            })
                                                                : this.state.filterSearch.map((v, i) => {
                                                                    return (
                                                                        <li key={i} onClick={(e) => this.showColumnsFun(i)} >
                                                                            <i className={v.isOpen ? "fas fa-toggle-off" : "fas fa-toggle-on"}></i>
                                                                            {v.label}
                                                                        </li>
                                                                    )
                                                                })
                                                        }
                                                    </ul>
                                                </div>
                                                <div className="button">
                                                    <div>
                                                        <button onClick={() => this.hideAllClick()}>HIDE ALL</button>
                                                    </div>
                                                    <div>
                                                        <button onClick={() => this.showAllClick()}>SHOW ALL</button>
                                                    </div>
                                                </div>
                                            </div> : null
                                    }
                                </li>
                            </ul>
                        </div> : null
                    }

                    {/* ============================== fullnameContainer ================================== */}

                    {this.state.fullnameContainer ?
                        <div className="fullnameContainer">
                            <ul>
                                <li className={`${this.state.fullname_unsort ? "fullname_unsort_disable" : ""}`}
                                    onClick={() => {
                                        this.setState({ fullnameContainer: false })
                                        this.fullnameUNSORT()
                                    }}>Unsort</li>
                                <li className={`${this.state.fullname_ascending ? "fullname_ascending_disable" : ""}`}
                                    onClick={() => {
                                        this.setState({ fullnameContainer: false })
                                        this.fullnameASC()
                                    }}>Sort by ASC</li>
                                <li className={`${this.state.fullname_descending ? "fullname_descending_disable" : ""}`}
                                    onClick={() => {
                                        this.setState({ fullnameContainer: false })
                                        this.fullnameDSC()
                                    }}>Sort by DESC</li>
                                <li onClick={() => {
                                    this.setState({ fullnameContainer: false })
                                    this.fullnameFILTER()
                                }}>Filter</li>
                                <li onClick={() => {
                                    this.setState({ fullnameContainer: false })
                                    this.fullnameHideClick()
                                }}>Hide</li>
                                <li
                                    className="mousehover_fullnameShowContainer"
                                    onMouseOver={() => { this.setState({ mousehover_fullnameShowContainer: true, mouseleave_fullnameShowContainer: true }) }}
                                    onMouseLeave={() => { this.setState({ mouseleave_fullnameShowContainer: false }) }}
                                    onClick={() => this.fullnameshowContainer()}>
                                    <span style={{ display: "flex", alignItems: "center", justifyContent: "start" }}>
                                        <span><i class="fas fa-caret-left" style={{ fontSize: "15px" }}></i></span>
                                        <span style={{ paddingLeft: "17px" }}>Show columns</span>
                                    </span>
                                    {
                                        this.state.mousehover_fullnameShowContainer && this.state.mouseleave_fullnameShowContainer ?
                                            <div className="fullnameshowContainer"
                                                onMouseOver={() => { this.setState({ mousehover_fullnameShowContainer: true, mouseleave_fullnameShowContainer: true }) }}
                                                onMouseLeave={() => { this.setState({ mouseleave_fullnameShowContainer: false }) }}>
                                                <div className="input">
                                                    <input type="text" value={this.state.inputValues} placeholder="Find column" onChange={(e) => {
                                                        e.preventDefault();
                                                        this.setState({ inputValues: e.target.value }, () => this.searchFilter());
                                                    }} />
                                                </div>
                                                <div className="showColumns">
                                                    <ul>
                                                        {
                                                            this.state.filteredSearch.length > 0 ? this.state.filteredSearch.map((v, i) => {
                                                                return (
                                                                    <li key={i} onClick={(e) => this.showColumnsFun(i)} >
                                                                        <i className={v.isOpen ? "fas fa-toggle-off" : "fas fa-toggle-on"}></i>
                                                                        {v.label}
                                                                    </li>
                                                                )
                                                            })
                                                                : this.state.filterSearch.map((v, i) => {
                                                                    return (
                                                                        <li key={i} onClick={(e) => this.showColumnsFun(i)} >
                                                                            <i className={v.isOpen ? "fas fa-toggle-off" : "fas fa-toggle-on"}></i>
                                                                            {v.label}
                                                                        </li>
                                                                    )
                                                                })
                                                        }
                                                    </ul>
                                                </div>
                                                <div className="button">
                                                    <div>
                                                        <button onClick={() => this.hideAllClick()}>HIDE ALL</button>
                                                    </div>
                                                    <div>
                                                        <button onClick={() => this.showAllClick()}>SHOW ALL</button>
                                                    </div>
                                                </div>
                                            </div> : null
                                    }
                                </li>
                            </ul>
                        </div> : null
                    }

                    {/* ====================== footer============================= */}

                    <div className="footerDataTable">
                        <div>
                            <h3>{this.getselectedrows()}</h3>
                        </div>
                        <div className="footerRight">
                            <div>
                                {SliceMethod.length > 0 ? this.state.Count : "0"}
                                - {this.state.SliceMethod_length_Count ? this.state.end - 5 + SliceMethod_length : SliceMethod_length}
                                <span> of </span>
                                <span> {this.state.DataStore.length} </span>
                            </div>
                            <div className="icons" title={`${this.state.DataStore.length < this.state.end ? "Go to pervious page" : ""}`}>
                                <i className={`fas fa-chevron-left   ${this.state.end === 5 ? "grey" : ""}`}
                                    onClick={() => this.backClick()}>
                                </i>
                            </div>
                            <div className="icons" title={`${this.state.DataStore.length > this.state.end ? "Go to next page" : ""}`}>
                                <i className={`fas fa-chevron-right  ${this.state.DataStore.length > this.state.end ? "" : "grey"} `}
                                    onClick={() => this.nextClick()}>
                                </i>
                            </div>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}
export default DataTable;



