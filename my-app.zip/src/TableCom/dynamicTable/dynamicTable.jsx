import React from "react";
import "./dynamicTable.css";

class DynamicTable extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            dynamicTable_heading: this.props.heading,
            dynamicTable_data: this.props.data,
            sorting: "unsort",
            // filterData: [],
            sortColumns: "",
            sortData: [],
            left: '',
            top: 50,
            hoverIcon: '',
            hideData: '',
            filterColumns: '',
            filterColumns_key: '',
            FilterOperators: '',
            FilterOperatorskey: '',
            hideColumn: this.props.hideColumns,
            hideColumns: [],
            checkboxs: this.props.checkbox,
            Filter_Column: false,
            filterLogic: this.props.filterLogic,
            filterNumberLogic: this.props.filterNumberLogic,
            type: null,
            hideColumnchecked: this.props.hideColumnchecked,
            start: 0,
            end: 5,
            Count: 1,
        }
    }

    componentWillMount() {
        let datastore = Object.assign([], this.state.dynamicTable_data);
        let hideColumn = Object.assign([], this.state.hideColumn);
        this.setState({
            sortData: datastore,
            hideColumns: hideColumn
        })
    }

    handleClick = (key) => {
        let data = Object.assign([], this.state.filterDatas ? this.state.sortData : this.state.dynamicTable_data);
        let newdata = data[0];
        let newdatas = newdata[key]
        let input_type = typeof (newdatas);
        let sortedData;
        let nameA;
        let nameB;
        if (input_type === "string") {
            if (this.state.sorting === "unsort" && this.state.sortColumns === "") {
                sortedData = data.sort((a, b) => {
                    nameA = a[key].toLowerCase()
                    nameB = b[key].toLowerCase()
                    if (nameA < nameB)
                        return -1
                    if (nameA > nameB)
                        return 1
                    return 0
                })
                this.setState({
                    sorting: "ascending",
                    sortColumns: key,
                })
            }
            else if (this.state.sorting === "ascending" && this.state.sortColumns === key) {
                sortedData = data.sort((a, b) => {
                    nameA = a[key].toLowerCase()
                    nameB = b[key].toLowerCase()
                    if (nameA > nameB)
                        return -1
                    if (nameA < nameB)
                        return 1
                    return 0
                })
                this.setState({
                    sorting: "descending",
                })
            }
            else if (this.state.sortColumns !== key) {
                sortedData = data.sort((a, b) => {
                    nameA = a[key].toLowerCase()
                    nameB = b[key].toLowerCase()
                    if (nameA < nameB)
                        return -1
                    if (nameA > nameB)
                        return 1
                    return 0
                })
                this.setState({
                    sorting: "ascending",
                    sortColumns: key,
                })
            }
            else {
                sortedData = data
                this.setState({
                    sortColumns: "",
                    sorting: "unsort",
                })
            }
        }
        else if (input_type === "number") {
            if (this.state.sorting === "unsort" && this.state.sortColumns === "") {
                sortedData = data.sort((a, b) => a[key] > b[key] ? 1 : -1)
                this.setState({
                    sorting: "ascending",
                    sortColumns: key,
                })
            }
            else if (this.state.sorting === "ascending" && this.state.sortColumns === key) {
                sortedData = data.sort((a, b) => a[key] > b[key] ? -1 : 1)
                this.setState({
                    sorting: "descending"
                })
            }
            else if (this.state.sortColumns !== key) {
                sortedData = data.sort((a, b) => a[key] > b[key] ? 1 : -1)
                this.setState({
                    sorting: "ascending",
                    sortColumns: key,
                })
            }
            else {
                sortedData = data
                this.setState({
                    sortColumns: "",
                    sorting: "unsort",
                })
            }
        }
        this.setState({
            sortData: sortedData,
        })
    }

    AllChecked = (e) => {
        let data = [...this.state.sortData];
        let AllSelected = e.target.checked;
        data = data.map((item) => {
            item.checked = AllSelected
            return item
        })
        this.setState({
            sortData: data
        })
    }

    checkboxClick = (item) => {
        let data = Object.assign([], this.state.sortData);
        data = data.map((value) => {
            if (item.id === value.id) {
                value.checked = !value.checked
            }
            return value
        })
        this.setState({
            sortData: data
        })
    }

    getselectedrows = () => {
        let data = [...this.state.sortData];
        let selecter_checkbox = data.filter((item) => {
            return item.checked
        })
        if (selecter_checkbox.length === 0) {
            return " "
        }
        else if (selecter_checkbox.length === 1) {
            return <h3>{selecter_checkbox.length + " row selected"}</h3>
        }
        else {
            return <h3>{selecter_checkbox.length + " rows selected"}</h3>
        }
    }

    hoverIcon = (key) => {
        if (this.state.hoverIcon === '') {
            this.setState({
                hoverIcon: key
            })
        }
    }

    hoverLeave = () => {
        this.setState({
            hoverIcon: ''
        })
    }

    showcolumnsOver = () => {
        this.setState({
            showcolumns: true,
        })
    }

    showcolumns_leave = () => {
        this.setState({
            showcolumns: false
        })
    }

    showWhereClicked = (e, key) => {
        console.log(`you have clicked X:${e.clientX} Y:${e.clientY}`);
        let key_data = this.state.dynamicTable_heading[key];
        let datas = Object.assign([], this.state.dynamicTable_data);
        let newdata = datas[0];
        let newdatas = newdata[key]
        let input_type = typeof (newdatas);
        console.log(key, "menu key")
        this.setState({
            left: e.clientX - 365,
            // top: e.clientY ,
            showPopup: !this.state.showPopup,
            hideData: key,
            filterColumns: key_data,
            filterColumns_key: key,
            type: input_type,
        })
    }

    sortbyUnsort = () => {
        let key = this.state.hideData;
        let data = Object.assign([], this.state.filterDatas ? this.state.sortData : this.state.dynamicTable_data);
        let newdata = data[0];
        let newdatas = newdata[key]
        let input_type = typeof (newdatas);
        let sortedData;
        let nameA;
        let nameB;
        sortedData = data
        this.setState({
            sortColumns: key,
            sorting: "unsort",
            sortData: sortedData,
            showPopup: false,
        })
    }

    sortbyAss = () => {
        let key = this.state.hideData;
        let data = Object.assign([], this.state.filterDatas ? this.state.sortData : this.state.dynamicTable_data);
        let newdata = data[0];
        let newdatas = newdata[key]
        let input_type = typeof (newdatas);
        let sortedData;
        let nameA;
        let nameB;
        if (input_type === "string") {
            sortedData = data.sort((a, b) => {
                nameA = a[key].toLowerCase()
                nameB = b[key].toLowerCase()
                if (nameA < nameB)
                    return -1
                if (nameA > nameB)
                    return 1
                return 0
            })
            this.setState({
                sorting: "ascending",
                sortColumns: key,
            })
        }
        else if (input_type === "number") {
            sortedData = data.sort((a, b) => a[key] > b[key] ? 1 : -1)
            this.setState({
                sorting: "ascending",
                sortColumns: key,
            })
        }
        this.setState({
            sortData: sortedData,
            showPopup: false,
        })
    }

    sortbyDesc = () => {
        let key = this.state.hideData;
        let data = Object.assign([], this.state.filterDatas ? this.state.sortData : this.state.dynamicTable_data);
        let newdata = data[0];
        let newdatas = newdata[key]
        let input_type = typeof (newdatas);
        let sortedData;
        let nameA;
        let nameB;
        if (input_type === "string") {
            sortedData = data.sort((a, b) => {
                nameA = a[key].toLowerCase()
                nameB = b[key].toLowerCase()
                if (nameA > nameB)
                    return -1
                if (nameA < nameB)
                    return 1
                return 0
            })
            this.setState({
                sorting: "descending",
                sortColumns: key
            })
        }
        else if (input_type === "number") {
            sortedData = data.sort((a, b) => a[key] > b[key] ? -1 : 1)
            this.setState({
                sorting: "descending",
                sortColumns: key
            })
        }
        this.setState({
            sortData: sortedData,
            showPopup: false,
        })
    }

    showfilter = () => {
        if (this.state.type === "string") {
            this.setState({
                showfilter: !this.state.showfilter,
                FilterOperators: "Contains",
                showPopup: false,
            })
        } else if (this.state.type === "number") {
            this.setState({
                showfilter: !this.state.showfilter,
                FilterOperators: "=",
                showPopup: false,
            })
        }
    }

    hideClick = () => {
        let keys = this.state.hideData
        this.state.hideColumnchecked[keys] = false
        this.setState({
            showPopup: false,
        })
    }

    hideColumnsFilter = (e) => {
        let inputvals = e.target.value;
        let hideFilterProps = this.props.hideColumns
        let hideFilter = Object.assign([], this.state.hideColumns);
        let newObj = {};
        if (inputvals === '') {
            this.setState({
                hideColumns: hideFilterProps
            })
        } else {
            hideFilter = Object.keys(hideFilter).map((key) => {
                if (hideFilter[key].toString().toLowerCase().includes(inputvals.toLowerCase())) {
                    newObj[key] = hideFilter[key]
                }
            })
            this.setState({
                hideColumns: newObj
            })
        }
    }

    ischeckedClick = (keys) => {
        if (this.state.hideColumnchecked[keys]) {
            this.state.hideColumnchecked[keys] = false
        }
        else {
            this.state.hideColumnchecked[keys] = true
        }

        if (keys === "checkbox") {
            this.setState({
                checkboxs: !this.state.checkboxs
            })
        }
    }

    Filter_Column = () => {
        this.setState({
            Filter_Column: !this.state.Filter_Column
        })
    }

    Filter_Operator = () => {
        this.setState({
            Filter_Operator: !this.state.Filter_Operator
        })
    }

    FilterColumnClick = (key) => {
        let data = this.state.dynamicTable_heading[key];
        let datas = Object.assign([], this.state.dynamicTable_data);
        let newdata = datas[0];
        let newdatas = newdata[key]
        let input_type = typeof (newdatas);
        if (input_type === "string") {
            this.setState({
                FilterOperators: "Contains",
            })
        } else if (input_type === "number") {
            this.setState({
                FilterOperators: "=",
            })
        }
        this.setState({
            filterColumns: data,
            filterColumns_key: key,
            type: input_type,
        })
    }

    FilterLogicClick = (e, key) => {
        console.log(e.target.value, "value***")
        let data = this.state.filterLogic[key];
        let numberData = this.state.filterNumberLogic[key];
        if (this.state.type === "number") {
            this.setState({
                FilterOperators: numberData,
                FilterOperatorskey: key
            })
        } else {
            this.setState({
                FilterOperators: data,
            })
        }
    }

    FilterClose = () => {
        this.setState({
            showfilter: false,
            Filter_Operator: false,
            Filter_Column: false,
        })
    }

    FilterInput = (e) => {
        let inputValue = e.target.value;
        let filtering = Object.assign([], this.state.dynamicTable_data);
        filtering = filtering.filter((item) => {
            if (this.state.type === "string") {
                if (inputValue === '') {
                    return item
                }
                else if (this.state.filterColumns_key && this.state.FilterOperators === 'Contains') {

                    return item[this.state.filterColumns_key].toString().toLowerCase().includes(inputValue.toLowerCase())
                }
                else if (this.state.filterColumns_key && this.state.FilterOperators === 'equals') {

                    return item[this.state.filterColumns_key].toString().toLowerCase() === (inputValue.toLowerCase())
                }
                else if (this.state.filterColumns_key && this.state.FilterOperators === 'starts with') {

                    return item[this.state.filterColumns_key].toString().toLowerCase().startsWith(inputValue.toLowerCase())
                }
                else if (this.state.filterColumns_key && this.state.FilterOperators === 'ends with') {

                    return item[this.state.filterColumns_key].toString().toLowerCase().endsWith(inputValue.toLowerCase())
                }
                else if (this.state.filterColumns_key && this.state.FilterOperators === 'is empty') {

                    return item[this.state.filterColumns_key].toString() === null || item[this.state.filterColumns_key] === ''
                }
                else if (this.state.filterColumns_key && this.state.FilterOperators === 'is not empty') {
                    return item[this.state.filterColumns_key] !== ''
                }
            }
            else {
                if (inputValue === '') {
                    return item
                }
                else if (this.state.filterColumns_key && this.state.FilterOperators === '=') {
                    return item[this.state.filterColumns_key] === parseInt(inputValue)
                }
                else if (this.state.filterColumns_key && this.state.FilterOperators === '!=') {
                    return item[this.state.filterColumns_key] !== parseInt(inputValue)
                }
                else if (this.state.filterColumns_key && this.state.FilterOperators === '>') {
                    return item[this.state.filterColumns_key] > parseInt(inputValue)
                }
                else if (this.state.filterColumns_key && this.state.FilterOperators === '>=') {
                    return item[this.state.filterColumns_key] >= parseInt(inputValue)
                }
                else if (this.state.filterColumns_key && this.state.FilterOperators === '<') {
                    return item[this.state.filterColumns_key] < parseInt(inputValue)
                }
                else if (this.state.filterColumns_key && this.state.FilterOperators === '<=') {
                    return item[this.state.filterColumns_key] <= parseInt(inputValue)
                }
                else if (this.state.filterColumns_key && this.state.FilterOperators === 'is empty') {
                    return item[this.state.filterColumns_key] === null || item[this.state.filterColumns_key] === ''
                }
                else if (this.state.filterColumns_key && this.state.FilterOperators === 'is not empty') {
                    return item[this.state.filterColumns_key] !== ''
                }
            }
        })
        let data = filtering;
        let sortedData = data;
        let nameA;
        let nameB;
        if (this.state.type === "string") {
            if (this.state.sorting === "ascending") {
                sortedData = data.sort((a, b) => {
                    nameA = a[this.state.filterColumns_key].toLowerCase()
                    nameB = b[this.state.filterColumns_key].toLowerCase()
                    if (nameA < nameB)
                        return -1
                    if (nameA > nameB)
                        return 1
                    return 0
                })
            }
            else if (this.state.sorting === "descending") {
                sortedData = data.sort((a, b) => {
                    nameA = a[this.state.filterColumns_key].toLowerCase()
                    nameB = b[this.state.filterColumns_key].toLowerCase()
                    if (nameA > nameB)
                        return -1
                    if (nameA < nameB)
                        return 1
                    return 0
                })
            }
        }
        this.setState({
            filterDatas: true,
            filterData: data,
            sortData: data,
            start: 0,
            end: 5,
            Count: 1,
        })
    }

    nextClick = () => {
        if (this.state.dynamicTable_data.length > this.state.end) {
            this.setState({
                start: this.state.start + 5,
                end: this.state.end + 5,
                Count: this.state.Count + 5,
                SliceMethod_length_Count: true,
            })
        }
    }

    backClick = () => {
        if (this.state.end === 5) {
            this.setState({
                start: 0,
                end: 5
            })
        }
        else {
            this.setState({
                start: this.state.start - 5,
                end: this.state.end - 5,
                Count: this.state.Count - 5,
            })
        }
    }

    render() {
        let SliceMethod = this.state.sortData.slice(this.state.start, this.state.end);
        console.log(this.state.sortData.length, "****@")
        return (
            <div className="dynamicTable_wapper">
                <div className="dynamicTable_container">
                    <div className="dynamicTable_filter">
                        {this.state.showfilter ?
                            <div className="FILTER">
                                <div >
                                    <svg viewBox="0 0 24 24" style={{ fill: "black", height: "1rem", width: "1rem", cursor: "pointer" }}
                                        onClick={() => this.FilterClose()}>
                                        <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"></path>
                                    </svg>
                                </div>
                                <div className="Filter_Columns"  >
                                    <div className="Filter_Column" onClick={() => this.Filter_Column()}>
                                        <div className="column_data"><p>{this.state.filterColumns}</p> </div>
                                        <div className={`${this.state.Filter_Column ? "ColumnOpen" : "ColumnOff"}`}>
                                            <ul>
                                                {Object.keys(this.state.dynamicTable_heading).map((key, inx) => {
                                                    return (
                                                        <li key={inx} onClick={() => this.FilterColumnClick(key)}>{this.state.dynamicTable_heading[key]}</li>
                                                    );
                                                })}
                                            </ul>
                                        </div>
                                        <div className="icon">
                                            <svg className="svgIcon" viewBox="0 0 24 24" >
                                                <path d="M7 10l5 5 5-5z"></path>
                                            </svg>
                                        </div>
                                    </div>
                                    <div className="Operators" onClick={() => this.Filter_Operator()} >
                                        <div className="column_data"> <p>{this.state.FilterOperators}</p> </div>
                                        <div className={`${this.state.Filter_Operator ? "OperatorOpen" : "OperatorOff"}`}>
                                            <ul>
                                                {Object.keys(this.state.type === "string" ? this.state.filterLogic : this.state.filterNumberLogic).map((key, inx) => {
                                                    console.log(this.state.filterNumberLogic, "(**)")
                                                    return <li key={inx} onClick={(e) => this.FilterLogicClick(e, key)}>
                                                        {this.state.type === "string" ? this.state.filterLogic[key] : this.state.filterNumberLogic[key]}</li>
                                                })}
                                            </ul>
                                        </div>
                                        <div className="icon">
                                            <svg className="svgIcon" viewBox="0 0 24 24" >
                                                <path d="M7 10l5 5 5-5z"></path>
                                            </svg>
                                        </div>
                                    </div>
                                    <div className="input_value">
                                        <input type="text" onChange={(e) => this.FilterInput(e)} autoFocus />
                                    </div>
                                </div>
                            </div>
                            : null}
                    </div>
                    <div className="dynamicTable">
                        <table >
                            <thead>
                                <tr>
                                    {this.state.checkboxs === true ?
                                        <th>
                                            <span className="checkbox"> <input type="checkbox" onClick={(e) => this.AllChecked(e)} /> </span>
                                        </th> : null
                                    }
                                    {
                                        Object.keys(this.state.dynamicTable_heading).map((key, key_index) => {
                                            return (
                                                <th key={key_index}
                                                    className={`${this.state.hideColumnchecked[key] === false ? "falseDeleted" : "trueDeleted"}`}
                                                    onMouseOver={() => this.hoverIcon(key)}
                                                    onMouseLeave={() => this.hoverLeave()} >
                                                    <span>
                                                        <span> {this.state.dynamicTable_heading[key]}</span>
                                                        <span>
                                                            <svg className={`svgSort
                                                                ${this.state.sortColumns === key && this.state.sorting === "ascending" ? "ascending"
                                                                    : this.state.sortColumns === key && this.state.sorting === "descending" ? "descending"
                                                                        : this.state.hoverIcon === key ? "unsort" : "svgSort"}`}
                                                                viewBox="0 0 24 24" onClick={() => this.handleClick(key)}>
                                                                <path d="M4 12l1.41 1.41L11 7.83V20h2V7.83l5.58 5.59L20 12l-8-8-8 8z"></path>
                                                            </svg>
                                                            <svg className="svgMenu" viewBox="0 0 24 24" onClick={(e) => this.showWhereClicked(e, key)} >
                                                                <path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"></path>
                                                            </svg>
                                                        </span>
                                                    </span>
                                                </th>
                                            )
                                        })
                                    }
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    SliceMethod.map((item, index) => {
                                        return (
                                            <tr key={index}>
                                                {this.state.checkboxs === true ?
                                                    <td><input type="checkbox" onClick={() => this.checkboxClick(item)} checked={item.checked} /></td>
                                                    : null}
                                                {Object.keys(item).map((key, key_inx) => {
                                                    return (
                                                        <td
                                                            key={key_inx}
                                                            className={`${this.state.hideColumnchecked[key] === false ? "falsekey" : "truekey"}`}
                                                        >{item[key]}</td>
                                                    );
                                                })}
                                            </tr>
                                        );
                                    })
                                }
                            </tbody>
                        </table>
                        {this.state.showPopup ?
                            <div className="showPopup" style={{ left: this.state.left + "px", top: this.state.top + "px", }} >
                                <ul>
                                    <li className={`${this.state.sorting === "unsort" || this.state.sortColumns !== this.state.hideData ? "disable" : ""}`} onClick={() => this.sortbyUnsort()}>Unsort</li>
                                    <li className={`${this.state.sorting === "ascending" && this.state.sortColumns === this.state.hideData ? "disable" : ""}`} onClick={() => this.sortbyAss()}>Sort by Ass</li>
                                    <li className={`${this.state.sorting === "descending" && this.state.sortColumns === this.state.hideData ? "disable" : ""}`} onClick={() => this.sortbyDesc()}>Sort by Desc</li>
                                    <li onClick={() => this.showfilter()}>Filter</li>
                                    <li onClick={() => this.hideClick()}>Hide</li>
                                    <li onMouseOver={() => this.showcolumnsOver()} onMouseLeave={() => this.showcolumns_leave()}>
                                        <span>Show columns</span>
                                        {this.state.showcolumns ?
                                            <div className="showcolumns">
                                                <input type="text" placeholder="Findcolumn" onChange={(e) => this.hideColumnsFilter(e)} />
                                                <ul>
                                                    {Object.keys(this.state.hideColumns).map((keys, index) => {
                                                        let data;
                                                        if (this.state.hideColumnchecked[keys]) { data = true } else { data = false }
                                                        return (
                                                            <li key={index} onClick={() => this.ischeckedClick(keys)} >
                                                                <input type="checkbox" checked={data} />
                                                                {data}
                                                                {this.state.hideColumns[keys]}
                                                            </li>);
                                                    })}
                                                </ul>
                                            </div>
                                            : null}
                                    </li>
                                </ul>
                            </div>
                            : null}
                    </div>
                    <div className="dynamicTable_footer">
                        <div className="dynamicTable_select_rows">
                            {this.getselectedrows()}
                        </div>
                        <div className="dynamicTable_totel_page">
                            <div className="totels_pages">
                                <span>{SliceMethod.length > 0 ? this.state.Count : "0"}</span>-
                                <span> {this.state.SliceMethod_length_Count ? this.state.end - 5 + SliceMethod.length : SliceMethod.length}</span>-
                                <span>{this.state.dynamicTable_data.length}</span>
                            </div>
                            <div className="icons">
                                <svg className={` ${this.state.end === 5 ? "grey" : ""}`} viewBox="0 0 24 24" onClick={() => this.backClick()}>
                                    <path d="M15.41 16.09l-4.58-4.59 4.58-4.59L14 5.5l-6 6 6 6z"></path>
                                </svg>
                                <svg className={` ${ this.state.dynamicTable_data.length > this.state.end ? "" : "grey"} ${this.state.sortData.length <= 5 ? "grey" : ""} `} viewBox="0 0 24 24" onClick={() => this.nextClick()}>
                                    <path d="M8.59 16.34l4.58-4.59-4.58-4.59L10 5.75l6 6-6 6z"></path>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default DynamicTable;



