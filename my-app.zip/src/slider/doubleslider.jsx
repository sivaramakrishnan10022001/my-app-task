import React from "react";
import "./doubleslider.css";


class DoubleSlider extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            avg: (this.props.min + this.props.max) / 2,
            selectedValue: 100,
            //  avg: 0,
            minVal: 0,
            maxVal: 0,
        }
    }

    componentDidMount() {
        this.setState({
            minVal: this.state.avg,
            maxVal: this.state.avg
        })
        // let minval = this.props.value.split('-')[0];
        // let maxval = this.props.value.split('-')[1];
        // this.setState({
        //     avg:maxval,
        //     minVal: minval,
        //     maxVal: maxval
        // })
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevState.minVal !== this.state.minVal) {
            this.setState({
                avg: (this.state.maxVal + this.state.minVal) / 2,
            })
        } else if (prevState.maxVal !== this.state.maxVal) {
            this.setState({
                avg: (this.state.maxVal + this.state.minVal) / 2,
            })
        }
    }

    render() {
        const { minVal, maxVal, avg } = this.state;
        const { min, max } = this.props;
        const thumbsize = 14;
        const width = 300;

        const minWidth = thumbsize + ((avg - min) / (max - min)) * (width - 2 * thumbsize);
        const minPercent = ((minVal - min) / (avg - min)) * 100;
        const maxPercent = ((maxVal - avg) / (max - avg)) * 100;

        // const minWidth = this.state.minVal;
        // const minPercent =  ((minVal - min) / (avg - min)) * 100;
        // const maxPercent =  ((maxVal - avg) / (max - avg)) * 100;

        const styles = {
            min: {
                width: minWidth,
                left: 0,
                "--minRangePercent": `${minPercent}%`
            },
            max: {
                width: thumbsize + ((max - avg) / (max - min)) * (width - 2 * thumbsize),
                left: minWidth,
                "--maxRangePercent": `${maxPercent}%`
            }
        };

        // const styles = {
        //     min: {
        //         width: minWidth,
        //         left: 0,
        //         "--minRangePercent": `${minPercent}%`
        //     },
        //     max: {
        //         width: this.state.maxVal,
        //         left: minWidth,
        //         "--maxRangePercent": `${maxPercent}%`
        //     }
        // };

        return (
            <>
                <div className={"doubleslider-wapper " + this.props.className}>
                    <div
                        className="min-max-slider"
                        data-legendnum="2"
                        data-rangemin={min}
                        data-rangemax={max}
                        data-thumbsize={thumbsize}
                        data-rangewidth={width}
                    >
                        <span className="stepper">
                            {new Array(parseInt(this.props.max / this.props.stepSize)).fill("|").map((row, key) => {
                                if (this.props.requireStepMarks) {
                                    if (this.state.selectedValue > key * this.props.stepSize) {
                                        return (
                                            <span className="marks-before" key={key}
                                                style={{ left: `${100 * (key * this.props.stepSize) / this.props.max}%` }}>
                                            </span>
                                        )
                                    } else {
                                        return (
                                            <span className="marks-after" key={key}
                                                style={{ left: `${100 * (key * this.props.stepSize) / this.props.max}%` }}>
                                            </span>
                                        )
                                    }
                                }
                            })}
                        </span>

                        <input
                            id="min"
                            className="min"
                            style={styles.min}
                            name="min"
                            type="range"
                            step={this.props.stepSize}
                            min={min}
                            max={avg}
                            value={minVal}
                            onChange={(e) => this.setState({ minVal: Number(e.target.value) })}
                        />
                        <input
                            id="max"
                            className="max"
                            style={styles.max}
                            name="max"
                            type="range"
                            step={this.props.stepSize}
                            min={avg}
                            max={max}
                            value={maxVal}
                            onChange={(e) => this.setState({ maxVal: Number(e.target.value) })}
                        />

                    </div>
                </div>
                <span className="span">{this.state.minVal}-{this.state.maxVal}</span>
            </>
        )
    }
}

export default DoubleSlider;



