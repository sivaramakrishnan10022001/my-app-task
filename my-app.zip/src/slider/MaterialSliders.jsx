
import React from 'react';
import "./materialsliders.css";


export class MSlider extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedValue: 100,

        }
    }

    // =================================================

    componentDidMount() {
        console.log("here");
    }

    // ==================================================


    // ==================================================

    render() {
        return (
            <span className="m-slider">
                <span className="active" style={{ left: "0%", width: `${(100 * (this.state.selectedValue) / this.props.max) + 1}%` }}></span>
                <span className="background"></span>

                {new Array(parseInt(this.props.max / this.props.stepSize)).fill("|").map((row, key) => {
                    if (this.props.requireStepMarks) {
                        if (this.state.selectedValue > key * this.props.stepSize) {
                            return <span className="marks-before" key={key}
                                style={{ left: `${100 * (key * this.props.stepSize) / this.props.max}%` }}>
                            </span>
                        } else {
                            return <span className="marks-after" key={key}
                                style={{ left: `${100 * (key * this.props.stepSize) / this.props.max}%` }}>
                            </span>
                        }
                    }
                })}

                <input type="range" min={this.props.min} max={this.props.max}
                    step={this.props.stepSize} value={this.state.selectedValue}
                    onChange={(e) => { this.setState({ selectedValue: e.target.value }) }} />
                <span className="thumb" style={{ left: `${(100 * (this.state.selectedValue) / this.props.max) - 2}%` }}></span>
                {this.props.showValue ? <span>{this.state.selectedValue}</span> : ""}
            </span>
        )
    }
}

export class MRangeSlider extends React.Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    // ====================================================

    componentDidMount() {
        this.setState({
            leftThumbValue: this.props.leftRange,
            rightThumbValue: this.props.rightRange,
            rangeDifference: 100 - this.props.rightRange,
        })
    }

    // ====================================================

    setData(position, e) {
        console.log(position, e, "position and e")
        console.log(e.target.min, "  e")

        var value;
        var difference;
        if (position === "right") {
            difference = this.state.rangeDifference - 1;
            console.log(difference, "difference right")
        } else if (position === "left") {
            difference = this.state.rangeDifference + 1;
            console.log(difference, "difference left")

        }
        value = (100 / (parseInt(this.props.max) - parseInt(this.props.min))) * parseInt(e.target.value)
            - (100 / (parseInt(this.props.max) - parseInt(this.props.min))) * parseInt(this.props.min);
        console.log(e.target.value, "e.target.value==")

        if (position === "right") {
            console.log(value, "value right")
            this.setState({
                rightThumbValue: value,
                rangeDifference: difference,
            })
        } else if (position === "left") {
            console.log(value, "value left")

            this.setState({
                leftThumbValue: value,
                rightThumbValue: this.state.rightThumbValue,
            })
        }
    }

    render() {
        return (

            <div className="slider-range">
                <div className="container">
                    <div className="inverse-left" style={{ width: `${this.state.leftThumbValue}%` }}></div>
                    <div className="inverse-right" style={{ width: `${102 - this.state.rightThumbValue}%` }}></div>
                    <div className="range"
                        style={{
                            left: `${this.state.leftThumbValue}%`,
                            right: `${100 - this.state.rightThumbValue}%`,
                        }}>
                    </div>

                    <span className="thumb left" style={{ left: `${this.state.leftThumbValue}%` }}></span>
                    <span className="thumb right" style={{ left: `${this.state.rightThumbValue}%` }}></span>
                </div>

                {new Array(parseInt(this.props.max / this.props.stepSize)).fill("|").map((row, key) => {
                    if (this.props.requireStepMarks) {
                        if (this.state.selectedValue > key * this.props.stepSize) {
                            return <span className="marks-before" key={key}
                                style={{ left: `${100 * (key * this.props.stepSize) / this.props.max}%` }}>
                            </span>
                        } else {
                            return <span className="marks-after" key={key}
                                style={{ left: `${100 * (key * this.props.stepSize) / this.props.max}%` }}>
                            </span>
                        }
                    }
                })}

                <input type="range" onInput={this.setData.bind(this, "left")} className="range"
                    min={this.props.min} max={this.props.max} step={this.props.stepSize} value="25" />
                <input type="range" onInput={this.setData.bind(this, "right")} className="range"
                    min={this.props.min} max={this.props.max} step={this.props.stepSize} value="75" />


            </div>


        )
    }
}

