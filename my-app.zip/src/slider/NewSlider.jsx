import React from "react";
import "./NewSlider.css";

class NewSlider extends React.Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    componentDidMount() {

    }

    setLeftValue = (inputLeft, inputRight, thumbLeft, range) => {
        console.log("setLeftValue-")

        var _this = inputLeft;
        // _this.min = parseInt(_this.min);
        // _this.max = parseInt(_this.max);
        _this = Math.min(parseInt(_this.value), parseInt(inputRight.value) - 1);
        var percent = ((_this.value - _this.min) / (_this.max - _this.min)) * 100;
        thumbLeft.style.left = percent + "%";
        range.style.left = percent + "%";
    }

    setRightValue = (inputLeft, inputRight, thumbRight, range) => {
        console.log("setRightValue-")
        var _this = inputRight;
        // _this.min = parseInt(_this.min);
        // _this.max = parseInt(_this.max);
        _this = Math.max(parseInt(_this.value), parseInt(inputLeft.value) + 1);
        var percent = ((_this.value - _this.min) / (_this.max - _this.min)) * 100;
        thumbRight.style.right = (100 - percent) + "%";
        range.style.right = (100 - percent) + "%";
    }

    InputData = () => {
        console.log("InputData-")
        let inputLeft = document.getElementById("input-left");
        let inputRight = document.getElementById("input-right");
        let thumbLeft = document.querySelector(" .thumb.left");
        let thumbRight = document.querySelector(" .thumb.right");
        let range = document.querySelector(" .range");

       
        inputLeft.addEventListener("mouseover", () => {
            thumbLeft.classList.add("hover");
        });
        inputLeft.addEventListener("mouseout", () => {
            thumbLeft.classList.remove("hover");
        });
        inputLeft.addEventListener("mousedown", () => {
            thumbLeft.classList.add("active");
        });
        inputLeft.addEventListener("mouseup", () => {
            thumbLeft.classList.remove("active");
        });
        inputRight.addEventListener("mouseover", () => {
            thumbRight.classList.add("hover");
        });
        inputRight.addEventListener("mouseout", () => {
            thumbRight.classList.remove("hover");
        });
        inputRight.addEventListener("mousedown", () => {
            thumbRight.classList.add("active");
        });
        inputRight.addEventListener("mouseup", () => {
            thumbRight.classList.remove("active");
        });
        inputLeft.addEventListener("input", this.setLeftValue());
        inputRight.addEventListener("input", this.setRightValue());

        this.setLeftValue(inputLeft, inputRight, thumbLeft, range);
        this.setRightValue(inputLeft, inputRight, thumbRight, range);
    }

    render() {

        return (
            <div className="new_middle">
                <div className="multi-range-slider">
                    <input type="range"
                        onInput={() => this.InputData()}
                        id="input-left"
                        min={this.props.min}
                        max={this.props.max}
                        value="25"
                    />

                    <input type="range"
                        onInput={() => this.InputData()}
                        id="input-right"
                        min={this.props.min}
                        max={this.props.max}
                        value="75"
                    />

                    <div className="slider">
                        <div className="track"></div>
                        <div className="range"></div>
                        <div className="thumb left"></div>
                        <div className="thumb right"></div>
                    </div>
                </div>
            </div>
        )
    }
}

export default NewSlider;