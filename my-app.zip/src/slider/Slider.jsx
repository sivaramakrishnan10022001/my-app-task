import React from 'react';
import "./Slider.css";

class Slider extends React.Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    setData = () => {
        var inputLeft = document.getElementById("input-left");
        var inputRight = document.getElementById("input-right");

        var thumbLeft = document.querySelector(".slider > .thumb.left");
        var thumbRight = document.querySelector(".slider > .thumb.right");
        var range = document.querySelector(".slider > .range");

        inputLeft.addEventListener("input", this.setLeftValue);
        inputRight.addEventListener("input", this.setRightValue);

        inputLeft.addEventListener("mouseover", () => {
            thumbLeft.classList.add("hover");
        });
        inputLeft.addEventListener("mouseout", () => {
            thumbLeft.classList.remove("hover");
        });
        inputLeft.addEventListener("mousedown", () => {
            thumbLeft.classList.add("active");
        });
        inputLeft.addEventListener("mouseup", () => {
            thumbLeft.classList.remove("active");
        });
        inputRight.addEventListener("mouseover", () => {
            thumbRight.classList.add("hover");
        });
        inputRight.addEventListener("mouseout", () => {
            thumbRight.classList.remove("hover");
        });
        inputRight.addEventListener("mousedown", () => {
            thumbRight.classList.add("active");
        });
        inputRight.addEventListener("mouseup", () => {
            thumbRight.classList.remove("active");
        });
        this.setLeftValue(inputLeft, inputRight, thumbLeft, range);
        this.setRightValue(inputLeft, inputRight, thumbRight, range);
    }

    setLeftValue = (inputLeft, inputRight, thumbLeft, range) => {
        var _this = inputLeft,
            min = parseInt(_this.min),
            max = parseInt(_this.max);

        _this.value = Math.min(parseInt(_this.value), parseInt(inputRight.value) - 1);
        var percent = ((_this.value - min) / (max - min)) * 100;
        thumbLeft.style.left = percent + "%";
        range.style.left = percent + "%";
    }

    setRightValue(inputLeft, inputRight, thumbRight, range) {
        var _this = inputRight,
            min = parseInt(_this.min),
            max = parseInt(_this.max);

        _this.value = Math.max(parseInt(_this.value), parseInt(inputLeft.value) + 1);

        var percent = ((_this.value - min) / (max - min)) * 100;

        thumbRight.style.right = (100 - percent) + "%";
        range.style.right = (100 - percent) + "%";
    }

    render() {
        return (
            <div className="middle">
                <div className="multi-range-slider">
                    <input type="range" onInput={this.setData.bind()} id="input-left" min={this.props.min} max={this.props.max} />
                    <input type="range" onInput={this.setData.bind()} id="input-right" min={this.props.min} max={this.props.max} />

                    <div className="slider">
                        <div className="track"></div>
                        <div className="range"></div>
                        <div className="thumb left"></div>
                        <div className="thumb right"></div>
                    </div>
                    {new Array(parseInt(this.props.max / this.props.stepSize)).fill("|").map((row, key) => {
                        if (this.props.requireStepMarks) {
                            if (this.state.selectedValue > key * this.props.stepSize) {
                                return (
                                    <span className='marks'>
                                        <span className="marks-before" key={key}
                                            style={{ left: `${100 * (key * this.props.stepSize) / this.props.max}%` }}>
                                        </span>
                                    </span>
                                )
                            } else {
                                return (
                                    <span className='marks'>
                                        <span className="marks-after" key={key}
                                            style={{ left: `${100 * (key * this.props.stepSize) / this.props.max}%` }}>
                                        </span>
                                    </span>
                                )
                            }
                        }
                    })}
                </div>
            </div>
        )
    }
}

export default Slider;