import React from "react";
import "./loadingButton.css";
import "./loadingAnimation.css";

class LoadingButton extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            Loading: false
        }
    }

    // =========================================================

    handleClick = () => {
        this.setState({
            Loading: true
        })
        console.log("onclick2", this.state.Loading);
        setTimeout(() => {
            this.setState({
                Loading: false
            })
            console.log("2000", this.state.Loading);
        }, 4000);
        console.log("onclick2", this.state.Loading);
    }

    // ================================================================================

    render() {
  
        let LoadingOne = <div className="lds-ring">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
        let LoadingTwo = <div className="lds-ellipsis">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
        // let LoadingThree = <div className="lds-roller">
        //     <div></div>
        //     <div></div>
        //     <div></div>
        //     <div></div>
        //     <div></div>
        //     <div></div>
        //     <div></div>
        //     <div></div>
        // </div>
        let LoadingFour = <div className="lds-dual-ring"></div>

        // ==================== return ===========================

        return (
            <div className="loading_container">
                <div className="loading_toggle"> {this.state.Loading ? <i className="fas fa-toggle-on"></i> : <i onClick={() => this.handleClick()} className="fas fa-toggle-off"></i>}
                    <h3 onClick={() => this.handleClick()}>Loading</h3>
                </div>
                <div className="loadingButton">
                    <button className={this.state.Loading ? "Btn_disabled_true" : "Btn_disabled"}
                    >
                        {this.state.Loading ? LoadingFour : "disabled"}
                    </button>
                    <button className={this.state.Loading ? "Btn_fetch_true" : "Btn_fetch"}
                        onClick={() => this.handleClick()}>
                        {this.state.Loading ? "loading" : "fetch data"}
                        {this.state.Loading ? LoadingTwo : null}
                    </button>
                    <button className={this.state.Loading ? "Btn_share_true" : "Btn_share"}
                        onClick={() => this.handleClick()}>share
                        {this.state.Loading ? LoadingOne : <i className="fas fa-share-alt"></i>}
                    </button>
                    <button className={this.state.Loading ? "Btn_save_true" : "Btn_save"} onClick={() => this.handleClick()}>
                        {this.state.Loading ? LoadingOne : <i className="fas fa-save"></i>} save
                    </button>
                </div>
            </div>
        );
    }
}
export default LoadingButton; 