import React from "react";
import HorizontalAccordian from "../HorizontalAccordian/horizontalAccordian";
import "./accordian.css";


class Accordian extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      listData: this.props.listData,

      horizontalAccordian_listDATA: [
        {
          heading: "iphone",
          description:
            "The iPhone is a smartphone made by Apple that combines a computer, iPod, digital camera and cellular phone into one device with a touchscreen interface. ... The first-generation iPhone came preloaded with a suite of Apple software, including iTunes, the Safari web browser and iPhoto."
        },
        {
          heading: "windows",
          description:
            "an opening especially in the wall of a building for admission of light and air that is usually closed by casements or sashes containing transparent material (such as glass) and capable of being opened and shut. b : windowpane. c : a space behind a window of a retail store containing displayed."
        },
        {
          heading: "macbook",
          description:
            "The MacBook is Apple's third laptop computer family, introduced in 2006. Prior laptops were the PowerBook and iBook. In 2015, new MacBooks featured Apple's Retina Display and higher resolutions, as well as the Force Touch trackpad that senses different pressure levels."
        },
        {
          heading: "android phone",
          description:
            "An Android phone is a powerful, high-tech smartphone that runs on the Android operating system (OS) developed by Google and is used by a variety of mobile phone manufacturers. Pick an Android mobile phone and you can choose from hundreds of great applications and multitask with ease."
        },
        {
          heading: "android phone",
          description:
            "An Android phone is a powerful, high-tech smartphone that runs on the Android operating system (OS) developed by Google and is used by a variety of mobile phone manufacturers. Pick an Android mobile phone and you can choose from hundreds of great applications and multitask with ease."
        },
        {
          heading: "android phone",
          description:
            "An Android phone is a powerful, high-tech smartphone that runs on the Android operating system (OS) developed by Google and is used by a variety of mobile phone manufacturers. Pick an Android mobile phone and you can choose from hundreds of great applications and multitask with ease."
        },
      ]
    };
  }

  // =================================================

  handClick = (key) => {
    let data = Object.assign([], this.state.listData);

    data = data.map((item, index) => {
      if (index === key) {
        item.isOpen = !item.isOpen;
      }
      else {
        item.isOpen = false;
      }
      return item;
    })
    this.setState({
      listData: data
    })
  }

  // ====================================================

  render() {
    return (
      <React.Fragment >
        <div className="accordian_container">
          <div className="accordian_container_shadow">
            {this.state.listData.map((item, index) => {
              return (
                <div key={index} className="accordian">
                  <div className={`heading ${item.isOpen ? "active" : ""}`}
                    onClick={() => this.handClick(index)}>
                    <div className="title">
                      {item.img}
                      <h3>{item.heading}</h3>
                    </div>
                    <div className="icon">
                      {
                        item.isOpen ?
                          <svg
                            className={` ${item.isOpen ? "rotate" : "arrow"}`}
                            xmlns="http://www.w3.org/2000/svg" width="5" height="8"
                            color="white" viewBox="0 0 5 8">
                            <g transform="translate(0)"><g transform="translate(0 0)">
                              <path d="M56.306,7.855a.3.3,0,0,0,.453.072l4.354-3.641a.389.389,0,0,0,0-.58L56.759.072a.3.3,0,0,0-.453.072.394.394,0,0,0,.065.507L60.38,4,56.371,7.354A.386.386,0,0,0,56.306,7.855Z" transform="translate(-56.242 0)" /></g></g>
                          </svg>
                          :
                          <svg className="arrow"
                            xmlns="http://www.w3.org/2000/svg" width="5" height="8" viewBox="0 0 5 8">
                            <g transform="translate(0)"><g transform="translate(0 0)">
                              <path d="M56.306,7.855a.3.3,0,0,0,.453.072l4.354-3.641a.389.389,0,0,0,0-.58L56.759.072a.3.3,0,0,0-.453.072.394.394,0,0,0,.065.507L60.38,4,56.371,7.354A.386.386,0,0,0,56.306,7.855Z" transform="translate(-56.242 0)" /></g></g>
                          </svg>
                      }
                    </div>
                  </div>
                  <div className={item.isOpen ? "visible" : "hidden"}>
                    <div className="list">
                      <ul>
                        {
                          item.skills ? item.skills.map((list, index) => {
                            return <li key={index}>{list}</li>
                          })
                            : null
                        }
                      </ul>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <HorizontalAccordian horizontalAccordian_listDATA={this.state.horizontalAccordian_listDATA} />
      </React.Fragment>
    );
  }
}

export default Accordian;