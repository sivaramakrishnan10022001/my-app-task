import './Accordians.css';
import Accordian from './accordian';
import React from 'react';


class Accordians extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      listContent: [
        {
          heading: "Web design",
          img: <img src="https://img.icons8.com/ios/50/000000/web-design.png" />,
          skills: [
            "javascript",
            "Reactjs",
            "Nodejs"
          ]
        },
        {
          heading: "Coding",
          img: <img src="https://img.icons8.com/ios/50/000000/laptop-coding.png" />,
          skills: [
            "html",
            "css",
            "javascript"
          ]
        },
        {
          heading: "Devices",
          img: <img src="https://img.icons8.com/ios/50/000000/multiple-devices.png" />,
          skills: [
            "html",
            "css",
            "javascript"
          ]
        },
        {
          heading: "Global",
          img: <img src="https://img.icons8.com/ios/50/000000/global-warming.png" />,
          skills: [
            "html",
            "css",
            "javascript"
          ]
        }
      ]
    };
  }

  // =================================================

  render() {
    return (
      <div className="Accordians">
        <Accordian listData={this.state.listContent} />

      </div>
    );
  }
}

export default Accordians;