
import React from 'react';
import './AccordianFirstTask.css';
import AccordianFirst  from './AccordianFirst';

class AccordianFirstTask extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      listContent: [
        {
          heading: "iphone",
          description:
            "The iPhone is a smartphone made by Apple that combines a computer, iPod, digital camera and cellular phone into one device with a touchscreen interface. ... The first-generation iPhone came preloaded with a suite of Apple software, including iTunes, the Safari web browser and iPhoto."
        },
        {
          heading: "windows",
          description:
            "an opening especially in the wall of a building for admission of light and air that is usually closed by casements or sashes containing transparent material (such as glass) and capable of being opened and shut. b : windowpane. c : a space behind a window of a retail store containing displayed."
        },
        {
          heading: "macbook",
          description:
            "The MacBook is Apple's third laptop computer family, introduced in 2006. Prior laptops were the PowerBook and iBook. In 2015, new MacBooks featured Apple's Retina Display and higher resolutions, as well as the Force Touch trackpad that senses different pressure levels."
        },
        {
          heading: "android phone",
          description:
            "An Android phone is a powerful, high-tech smartphone that runs on the Android operating system (OS) developed by Google and is used by a variety of mobile phone manufacturers. Pick an Android mobile phone and you can choose from hundreds of great applications and multitask with ease."
        }
      ]
    };
  }

  // =================================================

  render() {
    return (
      <div className="AccordianFirstTask">
        <AccordianFirst listData={this.state.listContent} />
      </div>
    );
  }
}

export default AccordianFirstTask;